// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c57344_i64 = arith.constant 57344 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c40960_i64 = arith.constant 40960 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.index_cast %arg15 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg12 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_2 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_2, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_1, %c32768_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_3 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_4 = memref.cast %subview_3 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_4 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_5 = memref.reinterpret_cast %arg11 to offset: [%26], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = memref.load %reinterpret_cast_5[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg16, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg16, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_6 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_6[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.subi %49, %47 : i32
      %55 = arith.remsi %54, %c2_i32 : i32
      %56 = arith.subi %49, %55 : i32
      %57 = arith.extsi %53 : i32 to i64
      %58 = arith.muli %57, %c192_i64 : i64
      scf.for %arg17 = %47 to %56 step %c2_i32  : i32 {
        %59 = arith.index_cast %arg17 : i32 to index
        %60 = arith.index_cast %47 : i32 to index
        %61 = arith.index_cast %56 : i32 to index
        %62 = arith.index_cast %c2_i32 : i32 to index
        %63 = arith.index_cast %arg16 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg15 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg12 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg17 : i32 to index
        %74 = arith.index_cast %47 : i32 to index
        %75 = arith.index_cast %56 : i32 to index
        %76 = arith.index_cast %c2_i32 : i32 to index
        %77 = arith.index_cast %arg16 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg15 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg12 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %87 = arith.select %86, %c3_i64, %c4_i64 : i64
        %88 = hivm.hir.pointer_cast(%c8192_i64, %c40960_i64) : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg17, %c64_i32 : i32
        %90 = arith.subi %arg17, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [128, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %88 : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c128 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> into memref<16384xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<16384xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c0_i64_1) : memref<8x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<8x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_0, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x128xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg17 = %56 to %49 step %c1_i32  : i32 {
        %59 = arith.index_cast %arg17 : i32 to index
        %60 = arith.index_cast %56 : i32 to index
        %61 = arith.index_cast %49 : i32 to index
        %62 = arith.index_cast %c1_i32 : i32 to index
        %63 = arith.index_cast %arg16 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg15 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg12 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg17 : i32 to index
        %74 = arith.index_cast %56 : i32 to index
        %75 = arith.index_cast %49 : i32 to index
        %76 = arith.index_cast %c1_i32 : i32 to index
        %77 = arith.index_cast %arg16 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg15 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg12 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %87 = arith.select %86, %c3_i64, %c4_i64 : i64
        %88 = hivm.hir.pointer_cast(%c24576_i64, %c57344_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg17, %c64_i32 : i32
        %90 = arith.subi %arg17, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %88 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c64 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

[NOTE] Ub overflow detected; automatically set enable-code-motion to false and retrying compilation.
// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c57344_i64 = arith.constant 57344 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c40960_i64 = arith.constant 40960 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.index_cast %arg15 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg12 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_2 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_2, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_1, %c32768_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_3 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_4 = memref.cast %subview_3 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_4 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_5 = memref.reinterpret_cast %arg11 to offset: [%26], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = memref.load %reinterpret_cast_5[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %34 to %41 step %c1_i32  : i32 {
      %42 = arith.muli %arg16, %c3_i32 : i32
      %43 = arith.maxsi %17, %42 : i32
      %44 = arith.addi %17, %33 : i32
      %45 = arith.addi %42, %c3_i32 : i32
      %46 = arith.minsi %44, %45 : i32
      %47 = arith.muli %15, %c688_i32 : i32
      %48 = arith.index_cast %47 : i32 to index
      %49 = arith.minsi %arg16, %c42_i32 : i32
      %50 = arith.index_cast %49 : i32 to index
      %51 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%48, %50]
      %reinterpret_cast_6 = memref.reinterpret_cast %arg8 to offset: [%51], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %52 = memref.load %reinterpret_cast_6[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = arith.subi %46, %43 : i32
      %54 = arith.remsi %53, %c2_i32 : i32
      %55 = arith.subi %46, %54 : i32
      scf.for %arg17 = %43 to %55 step %c2_i32  : i32 {
        %56 = arith.index_cast %arg17 : i32 to index
        %57 = arith.index_cast %43 : i32 to index
        %58 = arith.index_cast %55 : i32 to index
        %59 = arith.index_cast %c2_i32 : i32 to index
        %60 = arith.index_cast %arg16 : i32 to index
        %61 = arith.index_cast %34 : i32 to index
        %62 = arith.index_cast %41 : i32 to index
        %63 = arith.index_cast %c1_i32 : i32 to index
        %64 = arith.index_cast %arg15 : i32 to index
        %65 = arith.index_cast %6 : i32 to index
        %66 = arith.index_cast %c128_i32 : i32 to index
        %67 = arith.index_cast %arg12 : i32 to index
        %68 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%56, %57, %58, %59, %60, %61, %62, %63, %64, %65, %67]
        %69 = arith.index_cast %68 : index to i64
        %70 = arith.index_cast %arg17 : i32 to index
        %71 = arith.index_cast %43 : i32 to index
        %72 = arith.index_cast %55 : i32 to index
        %73 = arith.index_cast %c2_i32 : i32 to index
        %74 = arith.index_cast %arg16 : i32 to index
        %75 = arith.index_cast %34 : i32 to index
        %76 = arith.index_cast %41 : i32 to index
        %77 = arith.index_cast %c1_i32 : i32 to index
        %78 = arith.index_cast %arg15 : i32 to index
        %79 = arith.index_cast %6 : i32 to index
        %80 = arith.index_cast %c128_i32 : i32 to index
        %81 = arith.index_cast %arg12 : i32 to index
        %82 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%70, %71, %72, %73, %74, %75, %76, %77, %78, %79, %81]
        %83 = arith.index_cast %82 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %84 = arith.select %83, %c3_i64, %c4_i64 : i64
        %85 = hivm.hir.pointer_cast(%c8192_i64, %c40960_i64) : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %85 {hivm.multi_buffer = 2 : i32} : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        %86 = arith.muli %arg17, %c64_i32 : i32
        %87 = arith.extsi %52 : i32 to i64
        %88 = arith.muli %87, %c192_i64 : i64
        %89 = arith.subi %arg17, %42 : i32
        %90 = arith.muli %89, %c64_i32 : i32
        %91 = arith.extsi %90 : i32 to i64
        %92 = arith.addi %88, %91 : i64
        %93 = arith.index_cast %92 : i64 to index
        %94 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%93]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%94], sizes: [128, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %85 : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %95 = arith.index_cast %86 : i32 to index
        %96 = affine.max affine_map<()[s0] -> (8192, s0)>()[%95]
        %97 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%96, %95]
        %98 = arith.index_cast %27 : i32 to index
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%95, %98]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%99, %95]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%97, %95, %100]
        %102 = arith.cmpi slt, %101, %c128 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %85[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %85 [[0, 1, 2, 3]] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> into memref<16384xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<16384xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %84]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c0_i64_1) : memref<8x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<8x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_0, %c-1_i64, %84, %69, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x128xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg17 = %55 to %46 step %c1_i32  : i32 {
        %56 = arith.index_cast %arg17 : i32 to index
        %57 = arith.index_cast %55 : i32 to index
        %58 = arith.index_cast %46 : i32 to index
        %59 = arith.index_cast %c1_i32 : i32 to index
        %60 = arith.index_cast %arg16 : i32 to index
        %61 = arith.index_cast %34 : i32 to index
        %62 = arith.index_cast %41 : i32 to index
        %63 = arith.index_cast %c1_i32 : i32 to index
        %64 = arith.index_cast %arg15 : i32 to index
        %65 = arith.index_cast %6 : i32 to index
        %66 = arith.index_cast %c128_i32 : i32 to index
        %67 = arith.index_cast %arg12 : i32 to index
        %68 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%56, %57, %58, %59, %60, %61, %62, %63, %64, %65, %67]
        %69 = arith.index_cast %68 : index to i64
        %70 = arith.index_cast %arg17 : i32 to index
        %71 = arith.index_cast %55 : i32 to index
        %72 = arith.index_cast %46 : i32 to index
        %73 = arith.index_cast %c1_i32 : i32 to index
        %74 = arith.index_cast %arg16 : i32 to index
        %75 = arith.index_cast %34 : i32 to index
        %76 = arith.index_cast %41 : i32 to index
        %77 = arith.index_cast %c1_i32 : i32 to index
        %78 = arith.index_cast %arg15 : i32 to index
        %79 = arith.index_cast %6 : i32 to index
        %80 = arith.index_cast %c128_i32 : i32 to index
        %81 = arith.index_cast %arg12 : i32 to index
        %82 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%70, %71, %72, %73, %74, %75, %76, %77, %78, %79, %81]
        %83 = arith.index_cast %82 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %84 = arith.select %83, %c3_i64, %c4_i64 : i64
        %85 = hivm.hir.pointer_cast(%c24576_i64, %c57344_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %85 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %86 = arith.muli %arg17, %c64_i32 : i32
        %87 = arith.subi %arg17, %42 : i32
        %88 = arith.muli %87, %c64_i32 : i32
        %89 = arith.extsi %52 : i32 to i64
        %90 = arith.muli %89, %c192_i64 : i64
        %91 = arith.extsi %88 : i32 to i64
        %92 = arith.addi %90, %91 : i64
        %93 = arith.index_cast %92 : i64 to index
        %94 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%93]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%94], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %85 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %95 = arith.index_cast %86 : i32 to index
        %96 = affine.max affine_map<()[s0] -> (8192, s0)>()[%95]
        %97 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%96, %95]
        %98 = arith.index_cast %27 : i32 to index
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%95, %98]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%99, %95]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%97, %95, %100]
        %102 = arith.cmpi slt, %101, %c64 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %85[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %85 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %84]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %84, %69, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

[NOTE] Ub overflow detected; automatically set enable-auto-multi-buffer to false and retrying compilation.
// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c2_i64 = arith.constant 2 : i64
  %c2_i64_0 = arith.constant 2 : i64
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c0_i64_2 = arith.constant 0 : i64
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.divsi %arg15, %c16_i32 : i32
    %8 = arith.remsi %arg15, %c16_i32 : i32
    %9 = arith.muli %8, %c8_i32 : i32
    %10 = arith.muli %7, %c64_i32 : i32
    %11 = arith.index_cast %10 : i32 to index
    %12 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%11]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%12], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %13 = hivm.hir.pointer_cast(%c0_i64_2) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %cast = memref.cast %13 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %14 = affine.max affine_map<()[s0] -> (512, s0)>()[%11]
    %15 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%14, %11]
    %16 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%15, %11]
    %17 = arith.cmpi slt, %16, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%16, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %18 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%15, %11]
    %subview_3 = memref.subview %13[0, 0, 0, 0] [4, %18, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_4 = memref.cast %subview_3 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %17 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
      %collapse_shape = memref.collapse_shape %13 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_4 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %19 = arith.index_cast %7 : i32 to index
    %reinterpret_cast_5 = memref.reinterpret_cast %arg11 to offset: [%19], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %20 = memref.load %reinterpret_cast_5[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %21 = arith.minsi %20, %c8192_i32 : i32
    %22 = arith.addi %21, %c63_i32 : i32
    %23 = arith.divsi %22, %c64_i32 : i32
    %24 = arith.subi %23, %9 : i32
    %25 = arith.maxsi %24, %c0_i32 : i32
    %26 = arith.minsi %25, %c8_i32 : i32
    %27 = arith.divsi %9, %c3_i32 : i32
    %28 = arith.cmpi sgt, %26, %c0_i32 : i32
    %29 = arith.remsi %9, %c3_i32 : i32
    %30 = arith.addi %29, %26 : i32
    %31 = arith.addi %30, %c2_i32 : i32
    %32 = arith.divsi %31, %c3_i32 : i32
    %33 = arith.select %28, %32, %c0_i32 : i32
    %34 = arith.addi %27, %33 : i32
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %27 to %34 step %c1_i32  : i32 {
      %35 = arith.muli %arg16, %c3_i32 : i32
      %36 = arith.maxsi %9, %35 : i32
      %37 = arith.addi %9, %26 : i32
      %38 = arith.addi %35, %c3_i32 : i32
      %39 = arith.minsi %37, %38 : i32
      %40 = arith.muli %7, %c688_i32 : i32
      %41 = arith.index_cast %40 : i32 to index
      %42 = arith.minsi %arg16, %c42_i32 : i32
      %43 = arith.index_cast %42 : i32 to index
      %44 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%41, %43]
      %reinterpret_cast_6 = memref.reinterpret_cast %arg8 to offset: [%44], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %45 = memref.load %reinterpret_cast_6[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %46 = arith.subi %39, %36 : i32
      %47 = arith.remsi %46, %c2_i32 : i32
      %48 = arith.subi %39, %47 : i32
      scf.for %arg17 = %36 to %48 step %c2_i32  : i32 {
        %49 = arith.index_cast %arg17 : i32 to index
        %50 = arith.index_cast %36 : i32 to index
        %51 = arith.index_cast %48 : i32 to index
        %52 = arith.index_cast %c2_i32 : i32 to index
        %53 = arith.index_cast %arg16 : i32 to index
        %54 = arith.index_cast %27 : i32 to index
        %55 = arith.index_cast %34 : i32 to index
        %56 = arith.index_cast %c1_i32 : i32 to index
        %57 = arith.index_cast %arg15 : i32 to index
        %58 = arith.index_cast %6 : i32 to index
        %59 = arith.index_cast %c128_i32 : i32 to index
        %60 = arith.index_cast %arg12 : i32 to index
        %61 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%49, %50, %51, %52, %53, %54, %55, %56, %57, %58, %60]
        %62 = arith.index_cast %61 : index to i64
        %63 = arith.muli %arg17, %c64_i32 : i32
        %64 = arith.extsi %45 : i32 to i64
        %65 = arith.muli %64, %c192_i64 : i64
        %66 = arith.subi %arg17, %35 : i32
        %67 = arith.muli %66, %c64_i32 : i32
        %68 = arith.extsi %67 : i32 to i64
        %69 = arith.addi %65, %68 : i64
        %70 = arith.index_cast %69 : i64 to index
        %71 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%70]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%71], sizes: [128, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %72 = hivm.hir.pointer_cast(%c8192_i64) : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        %cast_8 = memref.cast %72 : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %73 = arith.index_cast %63 : i32 to index
        %74 = affine.max affine_map<()[s0] -> (8192, s0)>()[%73]
        %75 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%74, %73]
        %76 = arith.index_cast %20 : i32 to index
        %77 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%73, %76]
        %78 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%77, %73]
        %79 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%75, %73, %78]
        %80 = arith.cmpi slt, %79, %c128 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%79, 128] [1, 1] : memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %81 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%79]
        %subview_10 = memref.subview %72[0, 0, 0, 0] [4, %81, 16, 32] [1, 1, 1, 1] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %80 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
          %collapse_shape = memref.collapse_shape %72 [[0, 1, 2, 3]] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> into memref<16384xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<16384xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %82 = hivm.hir.pointer_cast(%c0_i64_2) : memref<8x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %82 : memref<8x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %16, %c128, %79 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_1, %c-1_i64, %c2_i64_0, %62, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %83 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%83 : memref<64x128xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %83 : memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg17 = %48 to %39 step %c1_i32  : i32 {
        %49 = arith.index_cast %arg17 : i32 to index
        %50 = arith.index_cast %48 : i32 to index
        %51 = arith.index_cast %39 : i32 to index
        %52 = arith.index_cast %c1_i32 : i32 to index
        %53 = arith.index_cast %arg16 : i32 to index
        %54 = arith.index_cast %27 : i32 to index
        %55 = arith.index_cast %34 : i32 to index
        %56 = arith.index_cast %c1_i32 : i32 to index
        %57 = arith.index_cast %arg15 : i32 to index
        %58 = arith.index_cast %6 : i32 to index
        %59 = arith.index_cast %c128_i32 : i32 to index
        %60 = arith.index_cast %arg12 : i32 to index
        %61 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%49, %50, %51, %52, %53, %54, %55, %56, %57, %58, %60]
        %62 = arith.index_cast %61 : index to i64
        %63 = arith.muli %arg17, %c64_i32 : i32
        %64 = arith.subi %arg17, %35 : i32
        %65 = arith.muli %64, %c64_i32 : i32
        %66 = arith.extsi %45 : i32 to i64
        %67 = arith.muli %66, %c192_i64 : i64
        %68 = arith.extsi %65 : i32 to i64
        %69 = arith.addi %67, %68 : i64
        %70 = arith.index_cast %69 : i64 to index
        %71 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%70]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%71], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %72 = hivm.hir.pointer_cast(%c24576_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %cast_8 = memref.cast %72 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %73 = arith.index_cast %63 : i32 to index
        %74 = affine.max affine_map<()[s0] -> (8192, s0)>()[%73]
        %75 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%74, %73]
        %76 = arith.index_cast %20 : i32 to index
        %77 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%73, %76]
        %78 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%77, %73]
        %79 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%75, %73, %78]
        %80 = arith.cmpi slt, %79, %c64 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%79, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %81 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%79]
        %subview_10 = memref.subview %72[0, 0, 0, 0] [4, %81, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %80 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
          %collapse_shape = memref.collapse_shape %72 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %82 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %82 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %16, %c128, %79 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %c2_i64, %62, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %83 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%83 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %83 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

[NOTE] Due to Ub overflow, automatically set enable-code-motion to false, set enable-auto-multi-buffer to false; compilation still failed.
loc("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":5:0): error: Failed to run BiShengHIR pipeline

loc("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":5:0): error: ub overflow, requires 8474624 bits while 1572864 bits available! (possible reason: tiling basic block is too large or block number is more than what user expect due to multi-buffer feature is enabled and some ops need extra local buffer.)
loc("query_scale"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":20:30)): error: cannot align 0 axis for %42 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("weights"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":21:26)): error: cannot align 0 axis for %48 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("query_scale"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":20:30)): error: cannot align 0 axis for %42 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("weights"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":21:26)): error: cannot align 0 axis for %48 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("query_scale"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":20:30)): error: cannot align 0 axis for %42 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("weights"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":21:26)): error: cannot align 0 axis for %48 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("query_scale"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":20:30)): error: cannot align 0 axis for %42 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
loc("weights"("/tmp/qsa-ascend910b-int8-score-tile-handoff.WY44tPfi/generated-prefixes/int8_budget_exact_paired_n128.py":21:26)): error: cannot align 0 axis for %48 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {hivm.stride_align_dims = array<i32: 0, 1>, hivm.stride_align_value_in_byte = array<i32: 32, 32>} : () -> memref<16x4xf16, #hivm.address_space<ub>>
[ERROR] Failed to run BiShengIR pipeline
