// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_direct_page_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c64_i32 = arith.constant 64 : i32
  %c154_i32 = arith.constant 154 : i32
  %c3_i32 = arith.constant 3 : i32
  %c8_i32 = arith.constant 8 : i32
  %c58_i32 = arith.constant 58 : i32
  %c406_i32 = arith.constant 406 : i32
  %c10_i32 = arith.constant 10 : i32
  %c2480_i32 = arith.constant 2480 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c4_i32 = arith.constant 4 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 6
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg14 = %6 to %c406_i32 step %arg11  : i32 {
    %7 = arith.index_cast %arg14 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c406_i32 : i32 to index
    %10 = arith.index_cast %arg11 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_1 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_1, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_0, %c16384_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg14, %c58_i32 : i32
    %16 = arith.remsi %arg14, %c58_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (448, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_2 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_3 = memref.cast %subview_2 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_3 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    %27 = memref.load %26[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 6
    annotation.mark %27 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%27 : i32] : i32
    %28 = arith.divsi %17, %c3_i32 : i32
    %29 = arith.remsi %17, %c3_i32 : i32
    %30 = arith.addi %29, %c10_i32 : i32
    %31 = arith.divsi %30, %c3_i32 : i32
    %32 = arith.addi %28, %31 : i32
    %33 = arith.addi %17, %c8_i32 : i32
    %34 = arith.muli %15, %c2480_i32 : i32
    %35 = arith.index_cast %34 : i32 to index
    %36 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg15 = %28 to %32 step %c1_i32  : i32 {
      %37 = arith.muli %arg15, %c3_i32 : i32
      %38 = arith.maxsi %17, %37 : i32
      %39 = arith.addi %37, %c3_i32 : i32
      %40 = arith.minsi %33, %39 : i32
      %41 = arith.minsi %arg15, %c154_i32 : i32
      %42 = arith.index_cast %41 : i32 to index
      %43 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%35, %42]
      %reinterpret_cast_4 = memref.reinterpret_cast %arg8 to offset: [%43], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %44 = memref.load %reinterpret_cast_4[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %45 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<4x64x64xi32, #hivm.address_space<gm>>
      %46 = arith.index_cast %40 : i32 to index
      %47 = arith.extsi %44 : i32 to i64
      %48 = arith.muli %47, %c192_i64 : i64
      scf.for %arg16 = %38 to %40 step %c4_i32  : i32 {
        %49 = arith.index_cast %arg16 : i32 to index
        %50 = affine.min affine_map<(d0, d1) -> (4, d0 - d1)>(%46, %49)
        scf.for %arg17 = %c0 to %50 step %c1 {
          %51 = arith.index_cast %arg16 : i32 to index
          %52 = arith.index_cast %38 : i32 to index
          %53 = arith.index_cast %40 : i32 to index
          %54 = arith.index_cast %c4_i32 : i32 to index
          %55 = arith.index_cast %arg15 : i32 to index
          %56 = arith.index_cast %28 : i32 to index
          %57 = arith.index_cast %32 : i32 to index
          %58 = arith.index_cast %c1_i32 : i32 to index
          %59 = arith.index_cast %arg14 : i32 to index
          %60 = arith.index_cast %6 : i32 to index
          %61 = arith.index_cast %c406_i32 : i32 to index
          %62 = arith.index_cast %arg11 : i32 to index
          %63 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12] -> (s0 + ((s2 - s3) floordiv s5) * s1 + ((s6 - s7) floordiv s9) * (s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) + ((s10 - s11) floordiv s12) * ((s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) * ((-s7 + s8 + s9 - 1) floordiv s9)))>()[%arg17, %50, %51, %52, %53, %54, %55, %56, %57, %58, %59, %60, %62]
          %64 = arith.index_cast %63 : index to i64
          %65 = arith.index_cast %arg16 : i32 to index
          %66 = arith.index_cast %38 : i32 to index
          %67 = arith.index_cast %40 : i32 to index
          %68 = arith.index_cast %c4_i32 : i32 to index
          %69 = arith.index_cast %arg15 : i32 to index
          %70 = arith.index_cast %28 : i32 to index
          %71 = arith.index_cast %32 : i32 to index
          %72 = arith.index_cast %c1_i32 : i32 to index
          %73 = arith.index_cast %arg14 : i32 to index
          %74 = arith.index_cast %6 : i32 to index
          %75 = arith.index_cast %c406_i32 : i32 to index
          %76 = arith.index_cast %arg11 : i32 to index
          %77 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12] -> ((s0 + ((s2 - s3) floordiv s5) * s1 + ((s6 - s7) floordiv s9) * (s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) + ((s10 - s11) floordiv s12) * ((s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) * ((-s7 + s8 + s9 - 1) floordiv s9))) mod 2)>()[%arg17, %50, %65, %66, %67, %68, %69, %70, %71, %72, %73, %74, %76]
          %78 = arith.index_cast %77 : index to i1
          %c3_i64 = arith.constant 3 : i64
          %c4_i64 = arith.constant 4 : i64
          %79 = arith.select %78, %c3_i64, %c4_i64 : i64
          %80 = hivm.hir.pointer_cast(%c8192_i64, %c24576_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
          annotation.mark %80 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
          %81 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%arg17]
          %82 = arith.index_cast %81 : index to i64
          %83 = affine.apply affine_map<(d0)[s0] -> (d0 + s0)>(%arg17)[%49]
          %84 = arith.index_cast %83 : index to i32
          %85 = arith.muli %84, %c64_i32 : i32
          %86 = arith.subi %84, %37 : i32
          %87 = arith.muli %86, %c64_i32 : i32
          %88 = arith.extsi %87 : i32 to i64
          %89 = arith.addi %48, %88 : i64
          %90 = arith.index_cast %89 : i64 to index
          %91 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%90]
          %reinterpret_cast_5 = memref.reinterpret_cast %arg4 to offset: [%91], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %cast_6 = memref.cast %80 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
          %92 = arith.index_cast %85 : i32 to index
          %93 = affine.max affine_map<()[s0] -> (29696, s0)>()[%92]
          %94 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%93, %92]
          %95 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%92, %36]
          %96 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%95, %92]
          %97 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%94, %92, %96]
          %98 = arith.cmpi slt, %97, %c64 : index
          %subview_7 = memref.subview %reinterpret_cast_5[0, 0] [%97, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %99 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%97]
          %subview_8 = memref.subview %80[0, 0, 0, 0] [4, %99, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
          %cast_9 = memref.cast %subview_8 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
          scf.if %98 {
            hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
            %collapse_shape_12 = memref.collapse_shape %80 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
            hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
            hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape_12 : memref<8192xi8, #hivm.address_space<cbuf>>)
            hivm.hir.pipe_barrier[<PIPE_MTE2>]
          } {hivm.unlikely_condition}
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %79]
          hivm.hir.nd2nz {dst_continuous} ins(%subview_7 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_9 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
          hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
          %100 = hivm.hir.pointer_cast(%c0_i64_0) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
          %cast_10 = memref.cast %100 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
          hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
          %c-1_i64 = arith.constant -1 : i64
          hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_6, %true, %23, %c128, %97 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_10 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %79, %64, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
          hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
          %subview_11 = memref.subview %45[%arg17, 0, 0] [1, 64, 64] [1, 1, 1] : memref<4x64x64xi32, #hivm.address_space<gm>> to memref<1x64x64xi32, strided<[4096, 64, 1], offset: ?>, #hivm.address_space<gm>>
          %collapse_shape = memref.collapse_shape %subview_11 [[0, 1], [2]] : memref<1x64x64xi32, strided<[4096, 64, 1], offset: ?>, #hivm.address_space<gm>> into memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>>
          hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = %82
          hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
          hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_10 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%collapse_shape : memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>>)
          hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
          hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 5
        } {hivm.loop_core_type = #hivm.tcore_type<CUBE>, multibuffer_unroll_factor = 4 : i32}
      }
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 4
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_direct_page_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c110304_i64 = arith.constant 110304 : i64
  %c16864_i64 = arith.constant 16864 : i64
  %c138976_i64 = arith.constant 138976 : i64
  %c155872_i64 = arith.constant 155872 : i64
  %c139488_i64 = arith.constant 139488 : i64
  %c123104_i64 = arith.constant 123104 : i64
  %c122592_i64 = arith.constant 122592 : i64
  %c480_i64 = arith.constant 480 : i64
  %c106336_i64 = arith.constant 106336 : i64
  %c114912_i64 = arith.constant 114912 : i64
  %c110816_i64 = arith.constant 110816 : i64
  %c106720_i64 = arith.constant 106720 : i64
  %c106464_i64 = arith.constant 106464 : i64
  %c352_i64 = arith.constant 352 : i64
  %c106208_i64 = arith.constant 106208 : i64
  %c104160_i64 = arith.constant 104160 : i64
  %c103648_i64 = arith.constant 103648 : i64
  %c38112_i64 = arith.constant 38112 : i64
  %c320_i64 = arith.constant 320 : i64
  %c256_i64 = arith.constant 256 : i64
  %c37856_i64 = arith.constant 37856 : i64
  %c128_i64 = arith.constant 128 : i64
  %c37600_i64 = arith.constant 37600 : i64
  %c0_i64 = arith.constant 0 : i64
  %c37344_i64 = arith.constant 37344 : i64
  %c20960_i64 = arith.constant 20960 : i64
  %c0_i32 = arith.constant 0 : i32
  %c192_i64 = arith.constant 192 : i64
  %c64_i32 = arith.constant 64 : i32
  %c154_i32 = arith.constant 154 : i32
  %c3_i32 = arith.constant 3 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8_i32 = arith.constant 8 : i32
  %c58_i32 = arith.constant 58 : i32
  %cst = arith.constant 0.000000e+00 : f32
  %c29696_i32 = arith.constant 29696 : i32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c406_i32 = arith.constant 406 : i32
  %c10_i32 = arith.constant 10 : i32
  %c2480_i32 = arith.constant 2480 : i32
  %c64 = arith.constant 64 : index
  %cst_1 = arith.constant 0.000000e+00 : f16
  %c16 = arith.constant 16 : index
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %c1_i32 = arith.constant 1 : i32
  %c4_i32 = arith.constant 4 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  %7 = hivm.hir.pointer_cast(%c20960_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %7 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c37344_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%8 : memref<64xi32, #hivm.address_space<ub>>)
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 4
  %9 = hivm.hir.get_sub_block_idx -> i64
  %10 = arith.index_cast %9 : i64 to index
  %11 = arith.cmpi eq, %10, %c0 : index
  %12 = hivm.hir.pointer_cast(%c20960_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %12 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_2 : memref<4096xi1, #hivm.address_space<ub>>)
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  scf.for %arg14 = %6 to %c406_i32 step %arg11  : i32 {
    %13 = arith.divsi %arg14, %c58_i32 : i32
    %14 = arith.remsi %arg14, %c58_i32 : i32
    %15 = arith.muli %14, %c8_i32 : i32
    %16 = arith.muli %13, %c16_i32 : i32
    %17 = arith.muli %13, %c64_i32 : i32
    %18 = arith.index_cast %17 : i32 to index
    %19 = affine.max affine_map<()[s0] -> (448, s0)>()[%18]
    %20 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%19, %18]
    %21 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%20, %18]
    %22 = arith.cmpi slt, %21, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%18], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %23 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_3 = memref.collapse_shape %23 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%21] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_4 = memref.subview %collapse_shape_3[0] [%21] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %22 {
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_3 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_4 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %24 = hivm.hir.pointer_cast(%c37600_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_5 = memref.collapse_shape %24 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_3 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_5 : memref<64xf32, #hivm.address_space<ub>>)
    %reinterpret_cast_6 = memref.reinterpret_cast %arg7 to offset: [%18], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %25 = hivm.hir.pointer_cast(%c128_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %25 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_8 = memref.subview %reinterpret_cast_6[0] [%21] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_9 = memref.subview %collapse_shape_7[0] [%21] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %22 {
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview_8 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_9 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %26 = hivm.hir.pointer_cast(%c37856_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_10 = memref.collapse_shape %26 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_10 : memref<64xf32, #hivm.address_space<ub>>)
    %27 = arith.index_cast %16 : i32 to index
    %reinterpret_cast_11 = memref.reinterpret_cast %arg9 to offset: [%27], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = hivm.hir.pointer_cast(%c256_i64) : memref<16xi32, #hivm.address_space<ub>>
    %29 = affine.max affine_map<()[s0] -> (112, s0)>()[%27]
    %30 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%29, %27]
    %31 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%30, %27]
    %32 = arith.cmpi slt, %31, %c16 : index
    %subview_12 = memref.subview %reinterpret_cast_11[0] [%31] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_13 = memref.subview %28[0] [%31] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %32 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%28 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.load ins(%subview_12 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_13 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %33 = hivm.hir.pointer_cast(%c320_i64) : memref<1xi32, #hivm.address_space<ub>>
    %34 = hivm.hir.pointer_cast(%c38112_i64) : memref<32xi32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vreduce <max> ins(%28 : memref<16xi32, #hivm.address_space<ub>>) outs(%33 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%34 : memref<32xi32, #hivm.address_space<ub>>) reduce_dims = [0]
    hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    %35 = memref.load %33[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
    hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    %36 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 6
    scf.if %11 {
      hivm.hir.store ins(%33 : memref<1xi32, #hivm.address_space<ub>>) outs(%36 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
    }
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    annotation.mark %36 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
    %37 = arith.divsi %15, %c3_i32 : i32
    %38 = arith.remsi %15, %c3_i32 : i32
    %39 = arith.addi %38, %c10_i32 : i32
    %40 = arith.divsi %39, %c3_i32 : i32
    %41 = arith.addi %37, %40 : i32
    %42 = arith.addi %15, %c8_i32 : i32
    %43 = arith.muli %13, %c2480_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %35 : i32 to index
    %expand_shape = memref.expand_shape %28 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    %expand_shape_14 = memref.expand_shape %24 [[0], [1, 2]] output_shape [16, 4, 1] {vector_producer_to_fuse_0} : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_15 = memref.expand_shape %26 [[0], [1, 2]] output_shape [16, 4, 1] {vector_producer_to_fuse_0} : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %46 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%30, %27]
    scf.for %arg15 = %37 to %41 step %c1_i32  : i32 {
      %47 = arith.muli %arg15, %c3_i32 : i32
      %48 = arith.maxsi %15, %47 : i32
      %49 = arith.addi %47, %c3_i32 : i32
      %50 = arith.minsi %42, %49 : i32
      %51 = arith.minsi %arg15, %c154_i32 : i32
      %52 = arith.index_cast %51 : i32 to index
      %53 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %52]
      %reinterpret_cast_16 = memref.reinterpret_cast %arg8 to offset: [%53], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = memref.load %reinterpret_cast_16[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %55 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<4x64x64xi32, #hivm.address_space<gm>>
      %56 = arith.index_cast %50 : i32 to index
      %57 = arith.extsi %54 : i32 to i64
      %58 = arith.muli %57, %c192_i64 : i64
      scf.for %arg16 = %48 to %50 step %c4_i32  : i32 {
        %59 = arith.index_cast %arg16 : i32 to index
        %60 = affine.min affine_map<(d0, d1) -> (4, d0 - d1)>(%56, %59)
        %61 = hivm.hir.pointer_cast(%c38112_i64) : memref<4x16x4x64xf32, #hivm.address_space<ub>>
        %62 = hivm.hir.pointer_cast(%c103648_i64) : memref<4x16x64xi1, #hivm.address_space<ub>>
        %63 = hivm.hir.pointer_cast(%c104160_i64) : memref<4x16x4x64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        scf.for %arg17 = %c0 to %60 step %c1 {
          %64 = affine.apply affine_map<(d0)[s0] -> (d0 + s0)>(%arg17)[%59]
          %65 = arith.index_cast %64 : index to i32
          %66 = arith.muli %65, %c64_i32 : i32
          %67 = hivm.hir.pointer_cast(%c106208_i64) : memref<64xi32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vadd ins(%8, %66 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%67 : memref<64xi32, #hivm.address_space<ub>>)
          %68 = arith.subi %65, %47 : i32
          %69 = arith.muli %68, %c64_i32 : i32
          %70 = arith.extsi %69 : i32 to i64
          %71 = arith.addi %58, %70 : i64
          %72 = arith.index_cast %71 : i64 to index
          %73 = arith.index_cast %66 : i32 to index
          %74 = affine.max affine_map<()[s0] -> (29696, s0)>()[%73]
          %75 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%74, %73]
          %76 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%73, %45]
          %77 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%76, %73]
          %78 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%75, %73, %77]
          %79 = arith.cmpi slt, %78, %c64 : index
          %reinterpret_cast_17 = memref.reinterpret_cast %arg6 to offset: [%72], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
          %80 = hivm.hir.pointer_cast(%c352_i64) : memref<64xf16, #hivm.address_space<ub>>
          %subview_18 = memref.subview %reinterpret_cast_17[0] [%78] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
          %subview_19 = memref.subview %80[0] [%78] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
          scf.if %79 {
            hivm.hir.vbrc ins(%cst_1 : f16) outs(%80 : memref<64xf16, #hivm.address_space<ub>>)
            hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          } {hivm.unlikely_condition}
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.load ins(%subview_18 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_19 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
          hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          %81 = hivm.hir.pointer_cast(%c106464_i64) : memref<64xf32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.vcast ins(%80 : memref<64xf16, #hivm.address_space<ub>>) outs(%81 : memref<64xf32, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          %subview_20 = memref.subview %61[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xf32, #hivm.address_space<ub>> to memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %82 = hivm.hir.pointer_cast(%c106720_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
          %expand_shape_21 = memref.expand_shape %81 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
          %collapse_shape_22 = memref.collapse_shape %82 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vbrc ins(%expand_shape_21 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_22 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
          %collapse_shape_23 = memref.collapse_shape %82 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
          %collapse_shape_24 = memref.collapse_shape %subview_20 [[0], [1, 2]] : memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<16x256xf32, strided<[256, 1], offset: ?>, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vbrc ins(%collapse_shape_23 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_24 : memref<16x256xf32, strided<[256, 1], offset: ?>, #hivm.address_space<ub>>) broadcast_dims = [0]
          %subview_25 = memref.subview %63[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xi1, #hivm.address_space<ub>> to memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_26 = memref.collapse_shape %subview_25 [[0, 1, 2]] : memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          hivm.hir.vnot ins(%collapse_shape_2 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_26 : memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>)
          %expand_shape_27 = memref.expand_shape %67 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
          %83 = hivm.hir.pointer_cast(%c106464_i64) : memref<1x64xi32, #hivm.address_space<ub>>
          %collapse_shape_28 = memref.collapse_shape %83 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
          hivm.hir.vmax ins(%67, %c29696_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_28 : memref<64xi32, #hivm.address_space<ub>>)
          %84 = hivm.hir.pointer_cast(%c106464_i64) : memref<1x64xi1, #hivm.address_space<ub>>
          %collapse_shape_29 = memref.collapse_shape %84 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp ins(%collapse_shape_28, %67 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<64xi1, #hivm.address_space<ub>>)
          %85 = hivm.hir.pointer_cast(%c106464_i64) : memref<1x64xi1, #hivm.address_space<ub>>
          %collapse_shape_30 = memref.collapse_shape %85 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot ins(%collapse_shape_29 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<64xi1, #hivm.address_space<ub>>)
          %86 = hivm.hir.pointer_cast(%c106720_i64) : memref<16x64xi32, #hivm.address_space<ub>>
          hivm.hir.vbrc ins(%expand_shape_27 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%86 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
          %87 = hivm.hir.pointer_cast(%c110816_i64) : memref<16x64xi32, #hivm.address_space<ub>>
          %88 = hivm.hir.pointer_cast(%c114912_i64) : memref<128xi32, #hivm.address_space<ub>>
          hivm.hir.vmax ins(%expand_shape_27, %expand_shape : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%87 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%88 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
          %89 = hivm.hir.pointer_cast(%c110816_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_31 = memref.collapse_shape %87 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
          %collapse_shape_32 = memref.collapse_shape %86 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
          %collapse_shape_33 = memref.collapse_shape %89 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp ins(%collapse_shape_31, %collapse_shape_32 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_33 : memref<1024xi1, #hivm.address_space<ub>>)
          %90 = hivm.hir.pointer_cast(%c110816_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_34 = memref.collapse_shape %90 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot ins(%collapse_shape_33 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<1024xi1, #hivm.address_space<ub>>)
          %91 = hivm.hir.pointer_cast(%c106208_i64) : memref<1x64xf16, #hivm.address_space<ub>>
          %collapse_shape_35 = memref.collapse_shape %91 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
          %92 = hivm.hir.pointer_cast(%c106336_i64) : memref<48xf16, #hivm.address_space<ub>>
          hivm.hir.vcast ins(%collapse_shape_30 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%92 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
          %93 = hivm.hir.pointer_cast(%c106336_i64) : memref<16x64xf16, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vbrc ins(%91 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%93 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
          %94 = hivm.hir.pointer_cast(%c106336_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_36 = memref.collapse_shape %93 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
          %collapse_shape_37 = memref.collapse_shape %94 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp ins(%collapse_shape_36, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_37 : memref<1024xi1, #hivm.address_space<ub>>)
          %95 = hivm.hir.pointer_cast(%c106336_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_38 = memref.collapse_shape %95 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot ins(%collapse_shape_37 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<1024xi1, #hivm.address_space<ub>>)
          %subview_39 = memref.subview %62[%arg17, 0, 0] [1, 16, 64] [1, 1, 1] : memref<4x16x64xi1, #hivm.address_space<ub>> to memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_40 = memref.collapse_shape %subview_39 [[0, 1]] : memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>> into memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vand ins(%collapse_shape_38, %collapse_shape_34 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>)
        } {hivm.loop_core_type = #hivm.tcore_type<VECTOR>, multibuffer_unroll_factor = 4 : i32}
        scf.for %arg17 = %c0 to %60 step %c1 {
          %64 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%arg17]
          %65 = arith.index_cast %64 : index to i64
          %66 = affine.apply affine_map<(d0)[s0] -> (d0 + s0)>(%arg17)[%59]
          %67 = arith.index_cast %66 : index to i32
          %68 = arith.muli %67, %c64_i32 : i32
          %69 = arith.index_cast %68 : i32 to index
          %70 = affine.max affine_map<()[s0] -> (29696, s0)>()[%69]
          %71 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%70, %69]
          %subview_17 = memref.subview %55[%arg17, 0, 0] [1, 64, 64] [1, 1, 1] : memref<4x64x64xi32, #hivm.address_space<gm>> to memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>>
          %expand_shape_18 = memref.expand_shape %subview_17 [[0, 1], [2]] output_shape [16, 4, 64] {vector_producer_to_fuse_0} : memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>> into memref<16x4x64xi32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<gm>>
          hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 5
          %72 = hivm.hir.pointer_cast(%c480_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
          %collapse_shape_19 = memref.collapse_shape %expand_shape_18 [[0, 1, 2]] : memref<16x4x64xi32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<gm>> into memref<4096xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
          %collapse_shape_20 = memref.collapse_shape %72 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.load ins(%collapse_shape_19 : memref<4096xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%collapse_shape_20 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load", vector_producer_to_fuse_0} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
          hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = %65
          %73 = hivm.hir.pointer_cast(%c480_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_21 = memref.collapse_shape %73 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.vcast {vector_producer_to_fuse_0} ins(%collapse_shape_20 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_21 : memref<4096xf32, #hivm.address_space<ub>>)
          %74 = hivm.hir.pointer_cast(%c480_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_22 = memref.collapse_shape %73 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %collapse_shape_23 = memref.collapse_shape %expand_shape_14 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
          %collapse_shape_24 = memref.collapse_shape %74 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %75 = hivm.hir.pointer_cast(%c106208_i64) : memref<512xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vmul {vector_producer_to_fuse_0} ins(%collapse_shape_22, %collapse_shape_23 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_24 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%75 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
          %subview_25 = memref.subview %61[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xf32, #hivm.address_space<ub>> to memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %76 = hivm.hir.pointer_cast(%c106208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_26 = memref.collapse_shape %74 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          %collapse_shape_27 = memref.collapse_shape %subview_25 [[0, 1, 2]] : memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<4096xf32, strided<[1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_28 = memref.collapse_shape %76 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vmul {vector_producer_to_fuse_0} ins(%collapse_shape_26, %collapse_shape_27 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, strided<[1], offset: ?>, #hivm.address_space<ub>>) outs(%collapse_shape_28 : memref<4096xf32, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          %77 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
          %collapse_shape_29 = memref.collapse_shape %77 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp {vector_producer_to_fuse_0} ins(%collapse_shape_28, %collapse_shape_28 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<4096xi1, #hivm.address_space<ub>>)
          %78 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
          %collapse_shape_30 = memref.collapse_shape %78 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot {vector_producer_to_fuse_0} ins(%collapse_shape_29 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<4096xi1, #hivm.address_space<ub>>)
          %79 = hivm.hir.pointer_cast(%c123104_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_31 = memref.collapse_shape %79 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.vmax {vector_producer_to_fuse_0} ins(%collapse_shape_28, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_31 : memref<4096xf32, #hivm.address_space<ub>>)
          %80 = hivm.hir.pointer_cast(%c139488_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_32 = memref.collapse_shape %80 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          %81 = hivm.hir.pointer_cast(%c155872_i64) : memref<16xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vsel {vector_producer_to_fuse_0} ins(%collapse_shape_30, %cst, %collapse_shape_31 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%81 : memref<16xf32, #hivm.address_space<ub>>)
          %subview_33 = memref.subview %63[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xi1, #hivm.address_space<ub>> to memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %82 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_34 = memref.collapse_shape %subview_33 [[0, 1, 2]] : memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_35 = memref.collapse_shape %82 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          %83 = hivm.hir.pointer_cast(%c138976_i64) : memref<8xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vsel {vector_producer_to_fuse_0} ins(%collapse_shape_34, %collapse_shape_28, %collapse_shape_32 : memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%83 : memref<8xf32, #hivm.address_space<ub>>)
          %84 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_36 = memref.collapse_shape %82 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %collapse_shape_37 = memref.collapse_shape %expand_shape_15 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
          %collapse_shape_38 = memref.collapse_shape %84 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %85 = hivm.hir.pointer_cast(%c106208_i64) : memref<512xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vmul {vector_producer_to_fuse_0} ins(%collapse_shape_36, %collapse_shape_37 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%85 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
          %86 = hivm.hir.pointer_cast(%c106208_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
          %87 = hivm.hir.pointer_cast(%c138976_i64) : memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vreduce {vector_producer_to_fuse_0} <sum> ins(%84 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%86 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%87 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
          %88 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 29696)>()[%69, %27]
          %reinterpret_cast_39 = memref.reinterpret_cast %arg10 to offset: [%88], sizes: [16, 64], strides: [29696, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>>
          %subview_40 = memref.subview %62[%arg17, 0, 0] [1, 16, 64] [1, 1, 1] : memref<4x16x64xi1, #hivm.address_space<ub>> to memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>
          %89 = hivm.hir.pointer_cast(%c16864_i64) : memref<16x64xf32, #hivm.address_space<ub>>
          %collapse_shape_41 = memref.collapse_shape %subview_40 [[0, 1]] : memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>> into memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_42 = memref.collapse_shape %86 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
          %collapse_shape_43 = memref.collapse_shape %89 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
          %90 = hivm.hir.pointer_cast(%c110304_i64) : memref<16xf32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vsel {vector_producer_to_fuse_0} ins(%collapse_shape_41, %collapse_shape_42, %cst_0 : memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_43 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%90 : memref<16xf32, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
          %91 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%71, %69]
          %subview_44 = memref.subview %89[0, 0] [%46, %91] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
          %subview_45 = memref.subview %reinterpret_cast_39[0, 0] [%46, %91] [1, 1] : memref<16x64xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>>
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
          scf.if %11 {
            hivm.hir.store ins(%subview_44 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_45 : memref<?x?xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>>) {op_to_tile_0_0}
          } {limit_sub_block_id0}
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        } {hivm.loop_core_type = #hivm.tcore_type<VECTOR>, multibuffer_unroll_factor = 4 : i32}
      }
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  }
  hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 6
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmprw1phv3r/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmprw1phv3r/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmprw1phv3r/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmprw1phv3r/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
