// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_direct_page_group_visible_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c2_i32 = arith.constant 2 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.index_cast %arg15 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg12 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_1 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_1, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_0, %c16384_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_2 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_3 = memref.cast %subview_2 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_3 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_4 = memref.reinterpret_cast %arg11 to offset: [%26], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = memref.load %reinterpret_cast_4[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg16, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg16, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_5 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_5[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.extsi %53 : i32 to i64
      %55 = arith.muli %54, %c192_i64 : i64
      scf.for %arg17 = %47 to %49 step %c1_i32  : i32 {
        %56 = arith.index_cast %arg17 : i32 to index
        %57 = arith.index_cast %47 : i32 to index
        %58 = arith.index_cast %49 : i32 to index
        %59 = arith.index_cast %c1_i32 : i32 to index
        %60 = arith.index_cast %arg16 : i32 to index
        %61 = arith.index_cast %34 : i32 to index
        %62 = arith.index_cast %41 : i32 to index
        %63 = arith.index_cast %c1_i32 : i32 to index
        %64 = arith.index_cast %arg15 : i32 to index
        %65 = arith.index_cast %6 : i32 to index
        %66 = arith.index_cast %c128_i32 : i32 to index
        %67 = arith.index_cast %arg12 : i32 to index
        %68 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%56, %57, %58, %59, %60, %61, %62, %63, %64, %65, %67]
        %69 = arith.index_cast %68 : index to i64
        %70 = arith.index_cast %arg17 : i32 to index
        %71 = arith.index_cast %47 : i32 to index
        %72 = arith.index_cast %49 : i32 to index
        %73 = arith.index_cast %c1_i32 : i32 to index
        %74 = arith.index_cast %arg16 : i32 to index
        %75 = arith.index_cast %34 : i32 to index
        %76 = arith.index_cast %41 : i32 to index
        %77 = arith.index_cast %c1_i32 : i32 to index
        %78 = arith.index_cast %arg15 : i32 to index
        %79 = arith.index_cast %6 : i32 to index
        %80 = arith.index_cast %c128_i32 : i32 to index
        %81 = arith.index_cast %arg12 : i32 to index
        %82 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%70, %71, %72, %73, %74, %75, %76, %77, %78, %79, %81]
        %83 = arith.index_cast %82 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %84 = arith.select %83, %c3_i64, %c4_i64 : i64
        %85 = hivm.hir.pointer_cast(%c8192_i64, %c24576_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %85 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %86 = arith.muli %arg17, %c64_i32 : i32
        %87 = arith.subi %arg17, %46 : i32
        %88 = arith.muli %87, %c64_i32 : i32
        %89 = arith.extsi %88 : i32 to i64
        %90 = arith.addi %55, %89 : i64
        %91 = arith.index_cast %90 : i64 to index
        %92 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%91]
        %reinterpret_cast_6 = memref.reinterpret_cast %arg4 to offset: [%92], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_7 = memref.cast %85 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %93 = arith.index_cast %86 : i32 to index
        %94 = affine.max affine_map<()[s0] -> (8192, s0)>()[%93]
        %95 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%94, %93]
        %96 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%93, %45]
        %97 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%96, %93]
        %98 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%95, %93, %97]
        %99 = arith.cmpi slt, %98, %c64 : index
        %subview_8 = memref.subview %reinterpret_cast_6[0, 0] [%98, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %100 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%98]
        %subview_9 = memref.subview %85[0, 0, 0, 0] [4, %100, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_10 = memref.cast %subview_9 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %99 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %85 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %84]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_8 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_10 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %101 = hivm.hir.pointer_cast(%c0_i64_0) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_11 = memref.cast %101 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_7, %true, %23, %c128, %98 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_11 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %84, %69, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %102 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_11 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%102 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %102 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_direct_page_group_visible_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c145664_i64 = arith.constant 145664 : i64
  %c141568_i64 = arith.constant 141568 : i64
  %c139520_i64 = arith.constant 139520 : i64
  %c139424_i64 = arith.constant 139424 : i64
  %c139296_i64 = arith.constant 139296 : i64
  %c138784_i64 = arith.constant 138784 : i64
  %c134688_i64 = arith.constant 134688 : i64
  %c130592_i64 = arith.constant 130592 : i64
  %c130336_i64 = arith.constant 130336 : i64
  %c113952_i64 = arith.constant 113952 : i64
  %c109856_i64 = arith.constant 109856 : i64
  %c107808_i64 = arith.constant 107808 : i64
  %c107776_i64 = arith.constant 107776 : i64
  %c91392_i64 = arith.constant 91392 : i64
  %c91328_i64 = arith.constant 91328 : i64
  %c74944_i64 = arith.constant 74944 : i64
  %c58560_i64 = arith.constant 58560 : i64
  %c58048_i64 = arith.constant 58048 : i64
  %c40640_i64 = arith.constant 40640 : i64
  %c41664_i64 = arith.constant 41664 : i64
  %c38592_i64 = arith.constant 38592 : i64
  %c22208_i64 = arith.constant 22208 : i64
  %c21952_i64 = arith.constant 21952 : i64
  %c21824_i64 = arith.constant 21824 : i64
  %c21568_i64 = arith.constant 21568 : i64
  %c21504_i64 = arith.constant 21504 : i64
  %c21248_i64 = arith.constant 21248 : i64
  %c21120_i64 = arith.constant 21120 : i64
  %c20864_i64 = arith.constant 20864 : i64
  %c20736_i64 = arith.constant 20736 : i64
  %c20480_i64 = arith.constant 20480 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %cst = arith.constant 0.000000e+00 : f32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c2_i32 = arith.constant 2 : i32
  %c688_i32 = arith.constant 688 : i32
  %c64 = arith.constant 64 : index
  %cst_1 = arith.constant 0.000000e+00 : f16
  %c16 = arith.constant 16 : index
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %c1_i32 = arith.constant 1 : i32
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  %7 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %7 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c16384_i64) : memref<16x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %8 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_2 : memref<1024xf32, #hivm.address_space<ub>>)
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  %9 = hivm.hir.pointer_cast(%c20480_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%9 : memref<64xi32, #hivm.address_space<ub>>)
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  %10 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %10 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>)
  %11 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %11 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<4096xi1, #hivm.address_space<ub>>)
  %12 = hivm.hir.get_sub_block_idx -> i64
  %13 = arith.index_cast %12 : i64 to index
  %14 = arith.cmpi eq, %13, %c0 : index
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c16_i32 : i32
    %19 = arith.muli %15, %c64_i32 : i32
    %20 = arith.index_cast %19 : i32 to index
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%20]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %20]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %20]
    %24 = arith.cmpi slt, %23, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%20], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %25 = hivm.hir.pointer_cast(%c20736_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_5 = memref.collapse_shape %25 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%23] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_6 = memref.subview %collapse_shape_5[0] [%23] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %24 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_5 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_6 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %26 = hivm.hir.pointer_cast(%c20864_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %26 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_5 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_7 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
    %reinterpret_cast_8 = memref.reinterpret_cast %arg7 to offset: [%20], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = hivm.hir.pointer_cast(%c21120_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_9 = memref.collapse_shape %27 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_10 = memref.subview %reinterpret_cast_8[0] [%23] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_11 = memref.subview %collapse_shape_9[0] [%23] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %24 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_9 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
    hivm.hir.load ins(%subview_10 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_11 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %28 = hivm.hir.pointer_cast(%c21248_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_12 = memref.collapse_shape %28 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_9 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_12 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
    %29 = arith.index_cast %18 : i32 to index
    %reinterpret_cast_13 = memref.reinterpret_cast %arg9 to offset: [%29], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %30 = hivm.hir.pointer_cast(%c21504_i64) : memref<16xi32, #hivm.address_space<ub>>
    %31 = affine.max affine_map<()[s0] -> (128, s0)>()[%29]
    %32 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%31, %29]
    %33 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%32, %29]
    %34 = arith.cmpi slt, %33, %c16 : index
    %subview_14 = memref.subview %reinterpret_cast_13[0] [%33] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_15 = memref.subview %30[0] [%33] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %34 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%30 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE2>]
    hivm.hir.load ins(%subview_14 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_15 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    %35 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_16 = memref.reinterpret_cast %arg11 to offset: [%35], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %36 = memref.load %reinterpret_cast_16[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %37 = arith.minsi %36, %c8192_i32 : i32
    %38 = arith.addi %37, %c63_i32 : i32
    %39 = arith.divsi %38, %c64_i32 : i32
    %40 = arith.subi %39, %17 : i32
    %41 = arith.maxsi %40, %c0_i32 : i32
    %42 = arith.minsi %41, %c8_i32 : i32
    %43 = arith.divsi %17, %c3_i32 : i32
    %44 = arith.cmpi sgt, %42, %c0_i32 : i32
    %45 = arith.remsi %17, %c3_i32 : i32
    %46 = arith.addi %45, %42 : i32
    %47 = arith.addi %46, %c2_i32 : i32
    %48 = arith.divsi %47, %c3_i32 : i32
    %49 = arith.select %44, %48, %c0_i32 : i32
    %50 = arith.addi %43, %49 : i32
    %51 = arith.addi %17, %42 : i32
    %52 = arith.muli %15, %c688_i32 : i32
    %53 = arith.index_cast %52 : i32 to index
    %54 = arith.index_cast %36 : i32 to index
    %expand_shape = memref.expand_shape %26 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_17 = memref.expand_shape %28 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_18 = memref.expand_shape %30 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    %55 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%32, %29]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %43 to %50 step %c1_i32  : i32 {
      %56 = arith.muli %arg16, %c3_i32 : i32
      %57 = arith.maxsi %17, %56 : i32
      %58 = arith.addi %56, %c3_i32 : i32
      %59 = arith.minsi %51, %58 : i32
      %60 = arith.minsi %arg16, %c42_i32 : i32
      %61 = arith.index_cast %60 : i32 to index
      %62 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%53, %61]
      %reinterpret_cast_19 = memref.reinterpret_cast %arg8 to offset: [%62], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %63 = memref.load %reinterpret_cast_19[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %64 = arith.extsi %63 : i32 to i64
      %65 = arith.muli %64, %c192_i64 : i64
      scf.for %arg17 = %57 to %59 step %c1_i32  : i32 {
        %66 = arith.muli %arg17, %c64_i32 : i32
        %67 = hivm.hir.pointer_cast(%c21568_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vadd ins(%9, %66 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%67 : memref<64xi32, #hivm.address_space<ub>>)
        %68 = arith.subi %arg17, %56 : i32
        %69 = arith.muli %68, %c64_i32 : i32
        %70 = arith.extsi %69 : i32 to i64
        %71 = arith.addi %65, %70 : i64
        %72 = arith.index_cast %71 : i64 to index
        %73 = arith.index_cast %66 : i32 to index
        %74 = affine.max affine_map<()[s0] -> (8192, s0)>()[%73]
        %75 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%74, %73]
        %76 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%73, %54]
        %77 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%76, %73]
        %78 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%75, %73, %77]
        %79 = arith.cmpi slt, %78, %c64 : index
        %reinterpret_cast_20 = memref.reinterpret_cast %arg6 to offset: [%72], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %80 = hivm.hir.pointer_cast(%c21824_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_21 = memref.subview %reinterpret_cast_20[0] [%78] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_22 = memref.subview %80[0] [%78] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %79 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%80 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_21 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_22 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %81 = hivm.hir.pointer_cast(%c21952_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%80 : memref<64xf16, #hivm.address_space<ub>>) outs(%81 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %82 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %83 = hivm.hir.pointer_cast(%c22208_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_23 = memref.collapse_shape %82 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_24 = memref.collapse_shape %83 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_23 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_24 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        %84 = hivm.hir.pointer_cast(%c22208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %84 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_24 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_25 : memref<4096xf32, #hivm.address_space<ub>>)
        %85 = hivm.hir.pointer_cast(%c22208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %84 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %85 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %86 = hivm.hir.pointer_cast(%c38592_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_26, %collapse_shape_27 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_28 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%86 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %87 = hivm.hir.pointer_cast(%c41664_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %88 = hivm.hir.pointer_cast(%c40640_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_29 = memref.expand_shape %81 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %88 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_29 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_31 = memref.collapse_shape %88 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %87 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_31 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %89 = hivm.hir.pointer_cast(%c41664_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %85 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %87 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %89 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_33, %collapse_shape_34 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %90 = hivm.hir.pointer_cast(%c58048_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_35, %collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_36 : memref<4096xi1, #hivm.address_space<ub>>)
        %91 = hivm.hir.pointer_cast(%c58048_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %91 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_36 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>)
        %92 = hivm.hir.pointer_cast(%c58560_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_35, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_38 : memref<4096xf32, #hivm.address_space<ub>>)
        %93 = hivm.hir.pointer_cast(%c74944_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %93 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %94 = hivm.hir.pointer_cast(%c91328_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_37, %cst, %collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%94 : memref<16xf32, #hivm.address_space<ub>>)
        %95 = hivm.hir.pointer_cast(%c91392_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %95 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %96 = hivm.hir.pointer_cast(%c107776_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_35, %collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%96 : memref<8xf32, #hivm.address_space<ub>>)
        %97 = hivm.hir.pointer_cast(%c91392_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %95 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %expand_shape_17 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %97 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %98 = hivm.hir.pointer_cast(%c107808_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_41, %collapse_shape_42 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_43 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%98 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %99 = hivm.hir.pointer_cast(%c109856_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %100 = hivm.hir.pointer_cast(%c113952_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%97 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%99 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%100 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_44 = memref.expand_shape %67 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c130336_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %101 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%67, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_45 : memref<64xi32, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c130336_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %102 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_45, %67 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_46 : memref<64xi1, #hivm.address_space<ub>>)
        %103 = hivm.hir.pointer_cast(%c130336_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %103 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_46 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c130592_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_44 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%104 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %105 = hivm.hir.pointer_cast(%c134688_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %106 = hivm.hir.pointer_cast(%c138784_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_44, %expand_shape_18 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%105 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%106 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %107 = hivm.hir.pointer_cast(%c134688_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %105 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %104 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %107 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_48, %collapse_shape_49 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_50 : memref<1024xi1, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c134688_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %108 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_50 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>)
        %109 = hivm.hir.pointer_cast(%c139296_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %109 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %110 = hivm.hir.pointer_cast(%c139424_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%110 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %111 = hivm.hir.pointer_cast(%c139520_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%109 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%111 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %112 = hivm.hir.pointer_cast(%c139520_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %111 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %112 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_53, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>)
        %113 = hivm.hir.pointer_cast(%c139520_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %113 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>)
        %114 = hivm.hir.pointer_cast(%c134688_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %114 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_55, %collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %115 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%73, %29]
        %reinterpret_cast_57 = memref.reinterpret_cast %arg10 to offset: [%115], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %116 = hivm.hir.pointer_cast(%c141568_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %99 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_59 = memref.collapse_shape %116 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %117 = hivm.hir.pointer_cast(%c145664_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_56, %collapse_shape_58, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_59 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%117 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %118 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%75, %73]
        %subview_60 = memref.subview %116[0, 0] [%55, %118] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_61 = memref.subview %reinterpret_cast_57[0, 0] [%55, %118] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %14 {
          hivm.hir.store ins(%subview_60 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_61 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %42 to %c8_i32 step %c1_i32  : i32 {
      %56 = arith.addi %17, %arg16 : i32
      %57 = arith.muli %56, %c64_i32 : i32
      %58 = arith.index_cast %57 : i32 to index
      %59 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%58, %29]
      %reinterpret_cast_19 = memref.reinterpret_cast %arg10 to offset: [%59], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %60 = affine.max affine_map<()[s0] -> (8192, s0)>()[%58]
      %61 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%60, %58]
      %62 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%61, %58]
      %subview_20 = memref.subview %8[0, 0] [%55, %62] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_21 = memref.subview %reinterpret_cast_19[0, 0] [%55, %62] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      scf.if %14 {
        hivm.hir.pipe_barrier[<PIPE_MTE3>]
        hivm.hir.store ins(%subview_20 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_21 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
      } {limit_sub_block_id0}
    }
  }
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpl2sq_flw/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpl2sq_flw/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpl2sq_flw/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpl2sq_flw/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
