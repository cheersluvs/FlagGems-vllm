// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_group_visible_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c2_i32 = arith.constant 2 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 3
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.index_cast %arg15 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg12 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_1 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_1, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_0, %c16384_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_2 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_3 = memref.cast %subview_2 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_3 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_4 = memref.reinterpret_cast %arg11 to offset: [%26], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = memref.load %reinterpret_cast_4[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %34 to %41 step %c1_i32  : i32 {
      %44 = arith.muli %arg16, %c3_i32 : i32
      %45 = arith.maxsi %17, %44 : i32
      %46 = arith.addi %44, %c3_i32 : i32
      %47 = arith.minsi %42, %46 : i32
      %48 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
      %49 = memref.load %48[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
      hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 3
      annotation.mark %49 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%49 : i32] : i32
      %50 = arith.extsi %49 : i32 to i64
      %51 = arith.muli %50, %c192_i64 : i64
      scf.for %arg17 = %45 to %47 step %c1_i32  : i32 {
        %52 = arith.index_cast %arg17 : i32 to index
        %53 = arith.index_cast %45 : i32 to index
        %54 = arith.index_cast %47 : i32 to index
        %55 = arith.index_cast %c1_i32 : i32 to index
        %56 = arith.index_cast %arg16 : i32 to index
        %57 = arith.index_cast %34 : i32 to index
        %58 = arith.index_cast %41 : i32 to index
        %59 = arith.index_cast %c1_i32 : i32 to index
        %60 = arith.index_cast %arg15 : i32 to index
        %61 = arith.index_cast %6 : i32 to index
        %62 = arith.index_cast %c128_i32 : i32 to index
        %63 = arith.index_cast %arg12 : i32 to index
        %64 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%52, %53, %54, %55, %56, %57, %58, %59, %60, %61, %63]
        %65 = arith.index_cast %64 : index to i64
        %66 = arith.index_cast %arg17 : i32 to index
        %67 = arith.index_cast %45 : i32 to index
        %68 = arith.index_cast %47 : i32 to index
        %69 = arith.index_cast %c1_i32 : i32 to index
        %70 = arith.index_cast %arg16 : i32 to index
        %71 = arith.index_cast %34 : i32 to index
        %72 = arith.index_cast %41 : i32 to index
        %73 = arith.index_cast %c1_i32 : i32 to index
        %74 = arith.index_cast %arg15 : i32 to index
        %75 = arith.index_cast %6 : i32 to index
        %76 = arith.index_cast %c128_i32 : i32 to index
        %77 = arith.index_cast %arg12 : i32 to index
        %78 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%66, %67, %68, %69, %70, %71, %72, %73, %74, %75, %77]
        %79 = arith.index_cast %78 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %80 = arith.select %79, %c3_i64, %c4_i64 : i64
        %81 = hivm.hir.pointer_cast(%c8192_i64, %c24576_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %81 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %82 = arith.muli %arg17, %c64_i32 : i32
        %83 = arith.subi %arg17, %44 : i32
        %84 = arith.muli %83, %c64_i32 : i32
        %85 = arith.extsi %84 : i32 to i64
        %86 = arith.addi %51, %85 : i64
        %87 = arith.index_cast %86 : i64 to index
        %88 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%87]
        %reinterpret_cast_5 = memref.reinterpret_cast %arg4 to offset: [%88], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_6 = memref.cast %81 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %89 = arith.index_cast %82 : i32 to index
        %90 = affine.max affine_map<()[s0] -> (8192, s0)>()[%89]
        %91 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%90, %89]
        %92 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%89, %43]
        %93 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%92, %89]
        %94 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%91, %89, %93]
        %95 = arith.cmpi slt, %94, %c64 : index
        %subview_7 = memref.subview %reinterpret_cast_5[0, 0] [%94, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %96 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%94]
        %subview_8 = memref.subview %81[0, 0, 0, 0] [4, %96, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_9 = memref.cast %subview_8 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %95 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %81 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %80]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_7 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_9 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %97 = hivm.hir.pointer_cast(%c0_i64_0) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_10 = memref.cast %97 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_6, %true, %23, %c128, %94 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_10 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %80, %65, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %98 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_10 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%98 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %98 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_group_visible_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c145824_i64 = arith.constant 145824 : i64
  %c141728_i64 = arith.constant 141728 : i64
  %c139680_i64 = arith.constant 139680 : i64
  %c139584_i64 = arith.constant 139584 : i64
  %c139456_i64 = arith.constant 139456 : i64
  %c138944_i64 = arith.constant 138944 : i64
  %c134848_i64 = arith.constant 134848 : i64
  %c130752_i64 = arith.constant 130752 : i64
  %c130496_i64 = arith.constant 130496 : i64
  %c114112_i64 = arith.constant 114112 : i64
  %c110016_i64 = arith.constant 110016 : i64
  %c107968_i64 = arith.constant 107968 : i64
  %c107936_i64 = arith.constant 107936 : i64
  %c91552_i64 = arith.constant 91552 : i64
  %c91488_i64 = arith.constant 91488 : i64
  %c75104_i64 = arith.constant 75104 : i64
  %c58720_i64 = arith.constant 58720 : i64
  %c58208_i64 = arith.constant 58208 : i64
  %c40800_i64 = arith.constant 40800 : i64
  %c41824_i64 = arith.constant 41824 : i64
  %c38752_i64 = arith.constant 38752 : i64
  %c22368_i64 = arith.constant 22368 : i64
  %c22112_i64 = arith.constant 22112 : i64
  %c21984_i64 = arith.constant 21984 : i64
  %c21728_i64 = arith.constant 21728 : i64
  %c21664_i64 = arith.constant 21664 : i64
  %c21632_i64 = arith.constant 21632 : i64
  %c21600_i64 = arith.constant 21600 : i64
  %c21568_i64 = arith.constant 21568 : i64
  %c21504_i64 = arith.constant 21504 : i64
  %c21248_i64 = arith.constant 21248 : i64
  %c21120_i64 = arith.constant 21120 : i64
  %c20864_i64 = arith.constant 20864 : i64
  %c20736_i64 = arith.constant 20736 : i64
  %c20480_i64 = arith.constant 20480 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c42_i32 = arith.constant 42 : i32
  %c43_i32 = arith.constant 43 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %cst = arith.constant 0.000000e+00 : f32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c2_i32 = arith.constant 2 : i32
  %c688_i32 = arith.constant 688 : i32
  %c64 = arith.constant 64 : index
  %cst_1 = arith.constant 0.000000e+00 : f16
  %c16 = arith.constant 16 : index
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %c1_i32 = arith.constant 1 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  %7 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %7 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c16384_i64) : memref<16x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %8 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_2 : memref<1024xf32, #hivm.address_space<ub>>)
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  %9 = hivm.hir.pointer_cast(%c20480_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%9 : memref<64xi32, #hivm.address_space<ub>>)
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  %10 = hivm.hir.get_sub_block_idx -> i64
  %11 = arith.index_cast %10 : i64 to index
  %12 = arith.cmpi eq, %11, %c0 : index
  %13 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %13 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>)
  %14 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %14 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<4096xi1, #hivm.address_space<ub>>)
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c16_i32 : i32
    %19 = arith.muli %15, %c64_i32 : i32
    %20 = arith.index_cast %19 : i32 to index
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%20]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %20]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %20]
    %24 = arith.cmpi slt, %23, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%20], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %25 = hivm.hir.pointer_cast(%c20736_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_5 = memref.collapse_shape %25 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%23] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_6 = memref.subview %collapse_shape_5[0] [%23] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %24 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_5 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_6 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %26 = hivm.hir.pointer_cast(%c20864_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %26 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_5 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_7 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
    %reinterpret_cast_8 = memref.reinterpret_cast %arg7 to offset: [%20], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = hivm.hir.pointer_cast(%c21120_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_9 = memref.collapse_shape %27 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_10 = memref.subview %reinterpret_cast_8[0] [%23] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_11 = memref.subview %collapse_shape_9[0] [%23] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %24 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_9 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
    hivm.hir.load ins(%subview_10 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_11 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %28 = hivm.hir.pointer_cast(%c21248_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_12 = memref.collapse_shape %28 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_9 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_12 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
    %29 = arith.index_cast %18 : i32 to index
    %reinterpret_cast_13 = memref.reinterpret_cast %arg9 to offset: [%29], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %30 = hivm.hir.pointer_cast(%c21504_i64) : memref<16xi32, #hivm.address_space<ub>>
    %31 = affine.max affine_map<()[s0] -> (128, s0)>()[%29]
    %32 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%31, %29]
    %33 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%32, %29]
    %34 = arith.cmpi slt, %33, %c16 : index
    %subview_14 = memref.subview %reinterpret_cast_13[0] [%33] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_15 = memref.subview %30[0] [%33] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %34 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%30 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE2>]
    hivm.hir.load ins(%subview_14 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_15 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    %35 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_16 = memref.reinterpret_cast %arg11 to offset: [%35], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %36 = memref.load %reinterpret_cast_16[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %37 = arith.minsi %36, %c8192_i32 : i32
    %38 = arith.addi %37, %c63_i32 : i32
    %39 = arith.divsi %38, %c64_i32 : i32
    %40 = arith.subi %39, %17 : i32
    %41 = arith.maxsi %40, %c0_i32 : i32
    %42 = arith.minsi %41, %c8_i32 : i32
    %43 = arith.divsi %17, %c3_i32 : i32
    %44 = arith.cmpi sgt, %42, %c0_i32 : i32
    %45 = arith.remsi %17, %c3_i32 : i32
    %46 = arith.addi %45, %42 : i32
    %47 = arith.addi %46, %c2_i32 : i32
    %48 = arith.divsi %47, %c3_i32 : i32
    %49 = arith.select %44, %48, %c0_i32 : i32
    %50 = arith.addi %43, %49 : i32
    %51 = arith.addi %17, %42 : i32
    %52 = arith.muli %15, %c688_i32 : i32
    %53 = arith.index_cast %52 : i32 to index
    %54 = arith.index_cast %36 : i32 to index
    %expand_shape = memref.expand_shape %26 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_17 = memref.expand_shape %28 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_18 = memref.expand_shape %30 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    %55 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%32, %29]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %43 to %50 step %c1_i32  : i32 {
      %56 = arith.muli %arg16, %c3_i32 : i32
      %57 = arith.maxsi %17, %56 : i32
      %58 = arith.addi %56, %c3_i32 : i32
      %59 = arith.minsi %51, %58 : i32
      %60 = arith.cmpi slt, %arg16, %c43_i32 : i32
      %61 = arith.cmpi slt, %57, %59 : i32
      %62 = arith.andi %60, %61 : i1
      %63 = arith.minsi %arg16, %c42_i32 : i32
      %64 = arith.index_cast %63 : i32 to index
      %65 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%53, %64]
      %reinterpret_cast_19 = memref.reinterpret_cast %arg8 to offset: [%65], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %66 = memref.load %reinterpret_cast_19[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %67 = hivm.hir.pointer_cast(%c21568_i64) : memref<1xi1, #hivm.address_space<ub>>
      memref.store %62, %67[%c0] : memref<1xi1, #hivm.address_space<ub>>
      %68 = hivm.hir.pointer_cast(%c21600_i64) : memref<1xi32, #hivm.address_space<ub>>
      memref.store %66, %68[%c0] : memref<1xi32, #hivm.address_space<ub>>
      hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
      %69 = hivm.hir.pointer_cast(%c21632_i64) : memref<1xi32, #hivm.address_space<ub>>
      %70 = hivm.hir.pointer_cast(%c21664_i64) : memref<16xi32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.vsel ins(%67, %68, %c0_i32 : memref<1xi1, #hivm.address_space<ub>>, memref<1xi32, #hivm.address_space<ub>>, i32) outs(%69 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%70 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
      %71 = memref.load %69[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
      %72 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 3
      scf.if %12 {
        hivm.hir.store ins(%69 : memref<1xi32, #hivm.address_space<ub>>) outs(%72 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
      }
      hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
      annotation.mark %72 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
      %73 = arith.extsi %71 : i32 to i64
      %74 = arith.muli %73, %c192_i64 : i64
      scf.for %arg17 = %57 to %59 step %c1_i32  : i32 {
        %75 = arith.muli %arg17, %c64_i32 : i32
        %76 = hivm.hir.pointer_cast(%c21728_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vadd ins(%9, %75 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%76 : memref<64xi32, #hivm.address_space<ub>>)
        %77 = arith.subi %arg17, %56 : i32
        %78 = arith.muli %77, %c64_i32 : i32
        %79 = arith.extsi %78 : i32 to i64
        %80 = arith.addi %74, %79 : i64
        %81 = arith.index_cast %80 : i64 to index
        %82 = arith.index_cast %75 : i32 to index
        %83 = affine.max affine_map<()[s0] -> (8192, s0)>()[%82]
        %84 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%83, %82]
        %85 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%82, %54]
        %86 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%85, %82]
        %87 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%84, %82, %86]
        %88 = arith.cmpi slt, %87, %c64 : index
        %reinterpret_cast_20 = memref.reinterpret_cast %arg6 to offset: [%81], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %89 = hivm.hir.pointer_cast(%c21984_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_21 = memref.subview %reinterpret_cast_20[0] [%87] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_22 = memref.subview %89[0] [%87] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %88 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%89 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_21 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_22 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %90 = hivm.hir.pointer_cast(%c22112_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%89 : memref<64xf16, #hivm.address_space<ub>>) outs(%90 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %91 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %92 = hivm.hir.pointer_cast(%c22368_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_23 = memref.collapse_shape %91 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_24 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_23 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_24 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        %93 = hivm.hir.pointer_cast(%c22368_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %93 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_24 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_25 : memref<4096xf32, #hivm.address_space<ub>>)
        %94 = hivm.hir.pointer_cast(%c22368_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %93 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %94 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %95 = hivm.hir.pointer_cast(%c38752_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_26, %collapse_shape_27 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_28 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%95 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %96 = hivm.hir.pointer_cast(%c41824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %97 = hivm.hir.pointer_cast(%c40800_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_29 = memref.expand_shape %90 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %97 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_29 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_31 = memref.collapse_shape %97 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %96 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_31 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %98 = hivm.hir.pointer_cast(%c22368_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_33, %collapse_shape_34 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>)
        %99 = hivm.hir.pointer_cast(%c58208_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %99 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_35, %collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_36 : memref<4096xi1, #hivm.address_space<ub>>)
        %100 = hivm.hir.pointer_cast(%c58208_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_36 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>)
        %101 = hivm.hir.pointer_cast(%c58720_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %101 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_35, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_38 : memref<4096xf32, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c75104_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %103 = hivm.hir.pointer_cast(%c91488_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_37, %cst, %collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%103 : memref<16xf32, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c91552_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c107936_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_35, %collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<8xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %106 = hivm.hir.pointer_cast(%c91552_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %104 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %expand_shape_17 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %106 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c107968_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_41, %collapse_shape_42 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_43 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %108 = hivm.hir.pointer_cast(%c110016_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %109 = hivm.hir.pointer_cast(%c114112_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%106 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%108 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%109 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_44 = memref.expand_shape %76 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %110 = hivm.hir.pointer_cast(%c130496_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %110 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%76, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_45 : memref<64xi32, #hivm.address_space<ub>>)
        %111 = hivm.hir.pointer_cast(%c130496_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %111 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_45, %76 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_46 : memref<64xi1, #hivm.address_space<ub>>)
        %112 = hivm.hir.pointer_cast(%c130496_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %112 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_46 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>)
        %113 = hivm.hir.pointer_cast(%c130752_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_44 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%113 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %114 = hivm.hir.pointer_cast(%c134848_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %115 = hivm.hir.pointer_cast(%c138944_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_44, %expand_shape_18 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%114 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%115 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %116 = hivm.hir.pointer_cast(%c134848_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %114 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %113 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %116 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_48, %collapse_shape_49 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_50 : memref<1024xi1, #hivm.address_space<ub>>)
        %117 = hivm.hir.pointer_cast(%c134848_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %117 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_50 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>)
        %118 = hivm.hir.pointer_cast(%c139456_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %118 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %119 = hivm.hir.pointer_cast(%c139584_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%119 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %120 = hivm.hir.pointer_cast(%c139680_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%118 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%120 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %121 = hivm.hir.pointer_cast(%c139680_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %120 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %121 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_53, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>)
        %122 = hivm.hir.pointer_cast(%c139680_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %122 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>)
        %123 = hivm.hir.pointer_cast(%c134848_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %123 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_55, %collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %124 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%82, %29]
        %reinterpret_cast_57 = memref.reinterpret_cast %arg10 to offset: [%124], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %125 = hivm.hir.pointer_cast(%c141728_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %108 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_59 = memref.collapse_shape %125 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %126 = hivm.hir.pointer_cast(%c145824_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_56, %collapse_shape_58, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_59 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%126 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %127 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%84, %82]
        %subview_60 = memref.subview %125[0, 0] [%55, %127] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_61 = memref.subview %reinterpret_cast_57[0, 0] [%55, %127] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %12 {
          hivm.hir.store ins(%subview_60 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_61 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %42 to %c8_i32 step %c1_i32  : i32 {
      %56 = arith.addi %17, %arg16 : i32
      %57 = arith.muli %56, %c64_i32 : i32
      %58 = arith.index_cast %57 : i32 to index
      %59 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%58, %29]
      %reinterpret_cast_19 = memref.reinterpret_cast %arg10 to offset: [%59], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %60 = affine.max affine_map<()[s0] -> (8192, s0)>()[%58]
      %61 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%60, %58]
      %62 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%61, %58]
      %subview_20 = memref.subview %8[0, 0] [%55, %62] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_21 = memref.subview %reinterpret_cast_19[0, 0] [%55, %62] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      scf.if %12 {
        hivm.hir.pipe_barrier[<PIPE_MTE3>]
        hivm.hir.store ins(%subview_20 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_21 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
      } {limit_sub_block_id0}
    }
  }
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 3
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpyzhfljpo/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpyzhfljpo/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpyzhfljpo/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpyzhfljpo/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
