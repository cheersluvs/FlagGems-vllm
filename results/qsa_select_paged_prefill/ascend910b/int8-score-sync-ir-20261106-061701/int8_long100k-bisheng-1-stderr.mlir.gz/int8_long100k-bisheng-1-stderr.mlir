// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_page_reuse_full_score_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c8_i32 = arith.constant 8 : i32
  %c58_i32 = arith.constant 58 : i32
  %c406_i32 = arith.constant 406 : i32
  %c10_i32 = arith.constant 10 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c4_i32 = arith.constant 4 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 6
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 7
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg14 = %6 to %c406_i32 step %arg11  : i32 {
    %7 = arith.index_cast %arg14 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c406_i32 : i32 to index
    %10 = arith.index_cast %arg11 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_1 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_1, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_0, %c16384_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg14, %c58_i32 : i32
    %16 = arith.remsi %arg14, %c58_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (448, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_2 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_3 = memref.cast %subview_2 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_3 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    %27 = memref.load %26[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 7
    annotation.mark %27 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%27 : i32] : i32
    %28 = arith.divsi %17, %c3_i32 : i32
    %29 = arith.remsi %17, %c3_i32 : i32
    %30 = arith.addi %29, %c10_i32 : i32
    %31 = arith.divsi %30, %c3_i32 : i32
    %32 = arith.addi %28, %31 : i32
    %33 = arith.addi %17, %c8_i32 : i32
    %34 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg15 = %28 to %32 step %c1_i32  : i32 {
      %35 = arith.muli %arg15, %c3_i32 : i32
      %36 = arith.maxsi %17, %35 : i32
      %37 = arith.addi %35, %c3_i32 : i32
      %38 = arith.minsi %33, %37 : i32
      %39 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
      %40 = memref.load %39[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
      hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 6
      annotation.mark %40 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%40 : i32] : i32
      %41 = memref_ext.alloc_workspace() from %arg2 offset = [%c64] : from memref<?xi8, #hivm.address_space<gm>> to memref<4x64x64xi32, #hivm.address_space<gm>>
      %42 = arith.index_cast %38 : i32 to index
      %43 = arith.extsi %40 : i32 to i64
      %44 = arith.muli %43, %c192_i64 : i64
      scf.for %arg16 = %36 to %38 step %c4_i32  : i32 {
        %45 = arith.index_cast %arg16 : i32 to index
        %46 = affine.min affine_map<(d0, d1) -> (4, d0 - d1)>(%42, %45)
        scf.for %arg17 = %c0 to %46 step %c1 {
          %47 = arith.index_cast %arg16 : i32 to index
          %48 = arith.index_cast %36 : i32 to index
          %49 = arith.index_cast %38 : i32 to index
          %50 = arith.index_cast %c4_i32 : i32 to index
          %51 = arith.index_cast %arg15 : i32 to index
          %52 = arith.index_cast %28 : i32 to index
          %53 = arith.index_cast %32 : i32 to index
          %54 = arith.index_cast %c1_i32 : i32 to index
          %55 = arith.index_cast %arg14 : i32 to index
          %56 = arith.index_cast %6 : i32 to index
          %57 = arith.index_cast %c406_i32 : i32 to index
          %58 = arith.index_cast %arg11 : i32 to index
          %59 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12] -> (s0 + ((s2 - s3) floordiv s5) * s1 + ((s6 - s7) floordiv s9) * (s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) + ((s10 - s11) floordiv s12) * ((s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) * ((-s7 + s8 + s9 - 1) floordiv s9)))>()[%arg17, %46, %47, %48, %49, %50, %51, %52, %53, %54, %55, %56, %58]
          %60 = arith.index_cast %59 : index to i64
          %61 = arith.index_cast %arg16 : i32 to index
          %62 = arith.index_cast %36 : i32 to index
          %63 = arith.index_cast %38 : i32 to index
          %64 = arith.index_cast %c4_i32 : i32 to index
          %65 = arith.index_cast %arg15 : i32 to index
          %66 = arith.index_cast %28 : i32 to index
          %67 = arith.index_cast %32 : i32 to index
          %68 = arith.index_cast %c1_i32 : i32 to index
          %69 = arith.index_cast %arg14 : i32 to index
          %70 = arith.index_cast %6 : i32 to index
          %71 = arith.index_cast %c406_i32 : i32 to index
          %72 = arith.index_cast %arg11 : i32 to index
          %73 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12] -> ((s0 + ((s2 - s3) floordiv s5) * s1 + ((s6 - s7) floordiv s9) * (s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) + ((s10 - s11) floordiv s12) * ((s1 * ((-s3 + s4 + s5 - 1) floordiv s5)) * ((-s7 + s8 + s9 - 1) floordiv s9))) mod 2)>()[%arg17, %46, %61, %62, %63, %64, %65, %66, %67, %68, %69, %70, %72]
          %74 = arith.index_cast %73 : index to i1
          %c3_i64 = arith.constant 3 : i64
          %c4_i64 = arith.constant 4 : i64
          %75 = arith.select %74, %c3_i64, %c4_i64 : i64
          %76 = hivm.hir.pointer_cast(%c8192_i64, %c24576_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
          annotation.mark %76 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
          %77 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%arg17]
          %78 = arith.index_cast %77 : index to i64
          %79 = affine.apply affine_map<(d0)[s0] -> (d0 + s0)>(%arg17)[%45]
          %80 = arith.index_cast %79 : index to i32
          %81 = arith.muli %80, %c64_i32 : i32
          %82 = arith.subi %80, %35 : i32
          %83 = arith.muli %82, %c64_i32 : i32
          %84 = arith.extsi %83 : i32 to i64
          %85 = arith.addi %44, %84 : i64
          %86 = arith.index_cast %85 : i64 to index
          %87 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%86]
          %reinterpret_cast_4 = memref.reinterpret_cast %arg4 to offset: [%87], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %cast_5 = memref.cast %76 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
          %88 = arith.index_cast %81 : i32 to index
          %89 = affine.max affine_map<()[s0] -> (29696, s0)>()[%88]
          %90 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%89, %88]
          %91 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%88, %34]
          %92 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%91, %88]
          %93 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%90, %88, %92]
          %94 = arith.cmpi slt, %93, %c64 : index
          %subview_6 = memref.subview %reinterpret_cast_4[0, 0] [%93, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
          %95 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%93]
          %subview_7 = memref.subview %76[0, 0, 0, 0] [4, %95, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
          %cast_8 = memref.cast %subview_7 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
          scf.if %94 {
            hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
            %collapse_shape_11 = memref.collapse_shape %76 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
            hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
            hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape_11 : memref<8192xi8, #hivm.address_space<cbuf>>)
            hivm.hir.pipe_barrier[<PIPE_MTE2>]
          } {hivm.unlikely_condition}
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %75]
          hivm.hir.nd2nz {dst_continuous} ins(%subview_6 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_8 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
          hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
          %96 = hivm.hir.pointer_cast(%c0_i64_0) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
          %cast_9 = memref.cast %96 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
          hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
          %c-1_i64 = arith.constant -1 : i64
          hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_5, %true, %23, %c128, %93 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_9 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %75, %60, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
          hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
          %subview_10 = memref.subview %41[%arg17, 0, 0] [1, 64, 64] [1, 1, 1] : memref<4x64x64xi32, #hivm.address_space<gm>> to memref<1x64x64xi32, strided<[4096, 64, 1], offset: ?>, #hivm.address_space<gm>>
          %collapse_shape = memref.collapse_shape %subview_10 [[0, 1], [2]] : memref<1x64x64xi32, strided<[4096, 64, 1], offset: ?>, #hivm.address_space<gm>> into memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>>
          hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = %78
          hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
          hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_9 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%collapse_shape : memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>>)
          hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
          hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 5
        } {hivm.loop_core_type = #hivm.tcore_type<CUBE>, multibuffer_unroll_factor = 4 : i32}
      }
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 4
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_page_reuse_full_score_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c110304_i64 = arith.constant 110304 : i64
  %c16864_i64 = arith.constant 16864 : i64
  %c138976_i64 = arith.constant 138976 : i64
  %c155872_i64 = arith.constant 155872 : i64
  %c139488_i64 = arith.constant 139488 : i64
  %c123104_i64 = arith.constant 123104 : i64
  %c122592_i64 = arith.constant 122592 : i64
  %c480_i64 = arith.constant 480 : i64
  %c106336_i64 = arith.constant 106336 : i64
  %c114912_i64 = arith.constant 114912 : i64
  %c110816_i64 = arith.constant 110816 : i64
  %c106720_i64 = arith.constant 106720 : i64
  %c106464_i64 = arith.constant 106464 : i64
  %c352_i64 = arith.constant 352 : i64
  %c106208_i64 = arith.constant 106208 : i64
  %c104160_i64 = arith.constant 104160 : i64
  %c38624_i64 = arith.constant 38624 : i64
  %c155968_i64 = arith.constant 155968 : i64
  %c155936_i64 = arith.constant 155936 : i64
  %c38112_i64 = arith.constant 38112 : i64
  %c320_i64 = arith.constant 320 : i64
  %c256_i64 = arith.constant 256 : i64
  %c37856_i64 = arith.constant 37856 : i64
  %c128_i64 = arith.constant 128 : i64
  %c37600_i64 = arith.constant 37600 : i64
  %c0_i64 = arith.constant 0 : i64
  %c37344_i64 = arith.constant 37344 : i64
  %c20960_i64 = arith.constant 20960 : i64
  %c0_i32 = arith.constant 0 : i32
  %c192_i64 = arith.constant 192 : i64
  %c154_i32 = arith.constant 154 : i32
  %c29696_i32 = arith.constant 29696 : i32
  %c64_i32 = arith.constant 64 : i32
  %c155_i32 = arith.constant 155 : i32
  %c3_i32 = arith.constant 3 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8_i32 = arith.constant 8 : i32
  %c58_i32 = arith.constant 58 : i32
  %cst = arith.constant 0.000000e+00 : f32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c406_i32 = arith.constant 406 : i32
  %c10_i32 = arith.constant 10 : i32
  %c2480_i32 = arith.constant 2480 : i32
  %c64 = arith.constant 64 : index
  %cst_1 = arith.constant 0.000000e+00 : f16
  %c16 = arith.constant 16 : index
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %c1_i32 = arith.constant 1 : i32
  %c4_i32 = arith.constant 4 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  %7 = hivm.hir.pointer_cast(%c20960_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %7 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c37344_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%8 : memref<64xi32, #hivm.address_space<ub>>)
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 4
  %9 = hivm.hir.get_sub_block_idx -> i64
  %10 = arith.index_cast %9 : i64 to index
  %11 = arith.cmpi eq, %10, %c0 : index
  %12 = hivm.hir.pointer_cast(%c20960_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %12 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_2 : memref<4096xi1, #hivm.address_space<ub>>)
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  scf.for %arg14 = %6 to %c406_i32 step %arg11  : i32 {
    %13 = arith.divsi %arg14, %c58_i32 : i32
    %14 = arith.remsi %arg14, %c58_i32 : i32
    %15 = arith.muli %14, %c8_i32 : i32
    %16 = arith.muli %13, %c16_i32 : i32
    %17 = arith.muli %13, %c64_i32 : i32
    %18 = arith.index_cast %17 : i32 to index
    %19 = affine.max affine_map<()[s0] -> (448, s0)>()[%18]
    %20 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%19, %18]
    %21 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%20, %18]
    %22 = arith.cmpi slt, %21, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%18], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %23 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_3 = memref.collapse_shape %23 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%21] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_4 = memref.subview %collapse_shape_3[0] [%21] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %22 {
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_3 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_4 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %24 = hivm.hir.pointer_cast(%c37600_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_5 = memref.collapse_shape %24 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_3 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_5 : memref<64xf32, #hivm.address_space<ub>>)
    %reinterpret_cast_6 = memref.reinterpret_cast %arg7 to offset: [%18], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %25 = hivm.hir.pointer_cast(%c128_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %25 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_8 = memref.subview %reinterpret_cast_6[0] [%21] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_9 = memref.subview %collapse_shape_7[0] [%21] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %22 {
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview_8 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_9 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %26 = hivm.hir.pointer_cast(%c37856_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_10 = memref.collapse_shape %26 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_10 : memref<64xf32, #hivm.address_space<ub>>)
    %27 = arith.index_cast %16 : i32 to index
    %reinterpret_cast_11 = memref.reinterpret_cast %arg9 to offset: [%27], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = hivm.hir.pointer_cast(%c256_i64) : memref<16xi32, #hivm.address_space<ub>>
    %29 = affine.max affine_map<()[s0] -> (112, s0)>()[%27]
    %30 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%29, %27]
    %31 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%30, %27]
    %32 = arith.cmpi slt, %31, %c16 : index
    %subview_12 = memref.subview %reinterpret_cast_11[0] [%31] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_13 = memref.subview %28[0] [%31] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %32 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%28 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.load ins(%subview_12 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_13 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %33 = hivm.hir.pointer_cast(%c320_i64) : memref<1xi32, #hivm.address_space<ub>>
    %34 = hivm.hir.pointer_cast(%c38112_i64) : memref<32xi32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vreduce <max> ins(%28 : memref<16xi32, #hivm.address_space<ub>>) outs(%33 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%34 : memref<32xi32, #hivm.address_space<ub>>) reduce_dims = [0]
    hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    %35 = memref.load %33[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
    %36 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 7
    scf.if %11 {
      hivm.hir.store ins(%33 : memref<1xi32, #hivm.address_space<ub>>) outs(%36 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
    }
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    annotation.mark %36 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
    %37 = arith.divsi %15, %c3_i32 : i32
    %38 = arith.remsi %15, %c3_i32 : i32
    %39 = arith.addi %38, %c10_i32 : i32
    %40 = arith.divsi %39, %c3_i32 : i32
    %41 = arith.addi %37, %40 : i32
    %42 = arith.addi %15, %c8_i32 : i32
    %43 = arith.muli %13, %c2480_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %35 : i32 to index
    %expand_shape = memref.expand_shape %28 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    %expand_shape_14 = memref.expand_shape %24 [[0], [1, 2]] output_shape [16, 4, 1] {vector_producer_to_fuse_0} : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_15 = memref.expand_shape %26 [[0], [1, 2]] output_shape [16, 4, 1] {vector_producer_to_fuse_0} : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %46 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%30, %27]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
    scf.for %arg15 = %37 to %41 step %c1_i32  : i32 {
      %47 = arith.muli %arg15, %c3_i32 : i32
      %48 = arith.maxsi %15, %47 : i32
      %49 = arith.addi %47, %c3_i32 : i32
      %50 = arith.minsi %42, %49 : i32
      %51 = arith.cmpi slt, %arg15, %c155_i32 : i32
      %52 = arith.cmpi slt, %48, %50 : i32
      %53 = arith.andi %51, %52 : i1
      %54 = arith.muli %48, %c64_i32 : i32
      %55 = arith.cmpi slt, %54, %c29696_i32 : i32
      %56 = arith.andi %53, %55 : i1
      %57 = arith.cmpi slt, %54, %35 : i32
      %58 = arith.andi %56, %57 : i1
      %59 = arith.minsi %arg15, %c154_i32 : i32
      %60 = arith.index_cast %59 : i32 to index
      %61 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %60]
      %reinterpret_cast_16 = memref.reinterpret_cast %arg8 to offset: [%61], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %62 = memref.load %reinterpret_cast_16[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %63 = hivm.hir.pointer_cast(%c155936_i64) : memref<1xi1, #hivm.address_space<ub>>
      memref.store %58, %63[%c0] : memref<1xi1, #hivm.address_space<ub>>
      %64 = hivm.hir.pointer_cast(%c155968_i64) : memref<1xi32, #hivm.address_space<ub>>
      memref.store %62, %64[%c0] : memref<1xi32, #hivm.address_space<ub>>
      hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
      %65 = hivm.hir.pointer_cast(%c320_i64) : memref<1xi32, #hivm.address_space<ub>>
      %66 = hivm.hir.pointer_cast(%c38112_i64) : memref<16xi32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
      hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vsel ins(%63, %64, %c0_i32 : memref<1xi1, #hivm.address_space<ub>>, memref<1xi32, #hivm.address_space<ub>>, i32) outs(%65 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%66 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
      %67 = memref.load %65[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
      %68 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 6
      scf.if %11 {
        hivm.hir.store ins(%65 : memref<1xi32, #hivm.address_space<ub>>) outs(%68 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
      }
      hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
      annotation.mark %68 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
      %69 = memref_ext.alloc_workspace() from %arg2 offset = [%c64] : from memref<?xi8, #hivm.address_space<gm>> to memref<4x64x64xi32, #hivm.address_space<gm>>
      %70 = arith.index_cast %50 : i32 to index
      %71 = arith.extsi %67 : i32 to i64
      %72 = arith.muli %71, %c192_i64 : i64
      scf.for %arg16 = %48 to %50 step %c4_i32  : i32 {
        %73 = arith.index_cast %arg16 : i32 to index
        %74 = affine.min affine_map<(d0, d1) -> (4, d0 - d1)>(%70, %73)
        %75 = hivm.hir.pointer_cast(%c38112_i64) : memref<4x16x64xi1, #hivm.address_space<ub>>
        %76 = hivm.hir.pointer_cast(%c38624_i64) : memref<4x16x4x64xf32, #hivm.address_space<ub>>
        %77 = hivm.hir.pointer_cast(%c104160_i64) : memref<4x16x4x64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        scf.for %arg17 = %c0 to %74 step %c1 {
          %78 = affine.apply affine_map<(d0)[s0] -> (d0 + s0)>(%arg17)[%73]
          %79 = arith.index_cast %78 : index to i32
          %80 = arith.muli %79, %c64_i32 : i32
          %81 = hivm.hir.pointer_cast(%c106208_i64) : memref<64xi32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vadd ins(%8, %80 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%81 : memref<64xi32, #hivm.address_space<ub>>)
          %82 = arith.subi %79, %47 : i32
          %83 = arith.muli %82, %c64_i32 : i32
          %84 = arith.extsi %83 : i32 to i64
          %85 = arith.addi %72, %84 : i64
          %86 = arith.index_cast %85 : i64 to index
          %87 = arith.index_cast %80 : i32 to index
          %88 = affine.max affine_map<()[s0] -> (29696, s0)>()[%87]
          %89 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%88, %87]
          %90 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%87, %45]
          %91 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%90, %87]
          %92 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%89, %87, %91]
          %93 = arith.cmpi slt, %92, %c64 : index
          %reinterpret_cast_17 = memref.reinterpret_cast %arg6 to offset: [%86], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
          %94 = hivm.hir.pointer_cast(%c352_i64) : memref<64xf16, #hivm.address_space<ub>>
          %subview_18 = memref.subview %reinterpret_cast_17[0] [%92] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
          %subview_19 = memref.subview %94[0] [%92] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
          scf.if %93 {
            hivm.hir.vbrc ins(%cst_1 : f16) outs(%94 : memref<64xf16, #hivm.address_space<ub>>)
            hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
            hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          } {hivm.unlikely_condition}
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.load ins(%subview_18 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_19 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
          hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          %95 = hivm.hir.pointer_cast(%c106464_i64) : memref<64xf32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.vcast ins(%94 : memref<64xf16, #hivm.address_space<ub>>) outs(%95 : memref<64xf32, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          %subview_20 = memref.subview %76[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xf32, #hivm.address_space<ub>> to memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %96 = hivm.hir.pointer_cast(%c106720_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
          %expand_shape_21 = memref.expand_shape %95 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
          %collapse_shape_22 = memref.collapse_shape %96 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vbrc ins(%expand_shape_21 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_22 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
          %collapse_shape_23 = memref.collapse_shape %96 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
          %collapse_shape_24 = memref.collapse_shape %subview_20 [[0], [1, 2]] : memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<16x256xf32, strided<[256, 1], offset: ?>, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vbrc ins(%collapse_shape_23 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_24 : memref<16x256xf32, strided<[256, 1], offset: ?>, #hivm.address_space<ub>>) broadcast_dims = [0]
          %subview_25 = memref.subview %77[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xi1, #hivm.address_space<ub>> to memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_26 = memref.collapse_shape %subview_25 [[0, 1, 2]] : memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          hivm.hir.vnot ins(%collapse_shape_2 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_26 : memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>)
          %expand_shape_27 = memref.expand_shape %81 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
          %97 = hivm.hir.pointer_cast(%c106464_i64) : memref<1x64xi32, #hivm.address_space<ub>>
          %collapse_shape_28 = memref.collapse_shape %97 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
          hivm.hir.vmax ins(%81, %c29696_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_28 : memref<64xi32, #hivm.address_space<ub>>)
          %98 = hivm.hir.pointer_cast(%c106464_i64) : memref<1x64xi1, #hivm.address_space<ub>>
          %collapse_shape_29 = memref.collapse_shape %98 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp ins(%collapse_shape_28, %81 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<64xi1, #hivm.address_space<ub>>)
          %99 = hivm.hir.pointer_cast(%c106464_i64) : memref<1x64xi1, #hivm.address_space<ub>>
          %collapse_shape_30 = memref.collapse_shape %99 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot ins(%collapse_shape_29 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<64xi1, #hivm.address_space<ub>>)
          %100 = hivm.hir.pointer_cast(%c106720_i64) : memref<16x64xi32, #hivm.address_space<ub>>
          hivm.hir.vbrc ins(%expand_shape_27 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%100 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
          %101 = hivm.hir.pointer_cast(%c110816_i64) : memref<16x64xi32, #hivm.address_space<ub>>
          %102 = hivm.hir.pointer_cast(%c114912_i64) : memref<128xi32, #hivm.address_space<ub>>
          hivm.hir.vmax ins(%expand_shape_27, %expand_shape : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%101 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%102 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
          %103 = hivm.hir.pointer_cast(%c110816_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_31 = memref.collapse_shape %101 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
          %collapse_shape_32 = memref.collapse_shape %100 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
          %collapse_shape_33 = memref.collapse_shape %103 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp ins(%collapse_shape_31, %collapse_shape_32 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_33 : memref<1024xi1, #hivm.address_space<ub>>)
          %104 = hivm.hir.pointer_cast(%c110816_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_34 = memref.collapse_shape %104 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot ins(%collapse_shape_33 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<1024xi1, #hivm.address_space<ub>>)
          %105 = hivm.hir.pointer_cast(%c106208_i64) : memref<1x64xf16, #hivm.address_space<ub>>
          %collapse_shape_35 = memref.collapse_shape %105 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
          %106 = hivm.hir.pointer_cast(%c106336_i64) : memref<48xf16, #hivm.address_space<ub>>
          hivm.hir.vcast ins(%collapse_shape_30 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%106 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
          %107 = hivm.hir.pointer_cast(%c106336_i64) : memref<16x64xf16, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vbrc ins(%105 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%107 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
          %108 = hivm.hir.pointer_cast(%c106336_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_36 = memref.collapse_shape %107 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
          %collapse_shape_37 = memref.collapse_shape %108 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp ins(%collapse_shape_36, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_37 : memref<1024xi1, #hivm.address_space<ub>>)
          %109 = hivm.hir.pointer_cast(%c106336_i64) : memref<16x64xi1, #hivm.address_space<ub>>
          %collapse_shape_38 = memref.collapse_shape %109 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot ins(%collapse_shape_37 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<1024xi1, #hivm.address_space<ub>>)
          %subview_39 = memref.subview %75[%arg17, 0, 0] [1, 16, 64] [1, 1, 1] : memref<4x16x64xi1, #hivm.address_space<ub>> to memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_40 = memref.collapse_shape %subview_39 [[0, 1]] : memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>> into memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vand ins(%collapse_shape_38, %collapse_shape_34 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>)
        } {hivm.loop_core_type = #hivm.tcore_type<VECTOR>, multibuffer_unroll_factor = 4 : i32}
        scf.for %arg17 = %c0 to %74 step %c1 {
          %78 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%arg17]
          %79 = arith.index_cast %78 : index to i64
          %80 = affine.apply affine_map<(d0)[s0] -> (d0 + s0)>(%arg17)[%73]
          %81 = arith.index_cast %80 : index to i32
          %82 = arith.muli %81, %c64_i32 : i32
          %83 = arith.index_cast %82 : i32 to index
          %84 = affine.max affine_map<()[s0] -> (29696, s0)>()[%83]
          %85 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%84, %83]
          %subview_17 = memref.subview %69[%arg17, 0, 0] [1, 64, 64] [1, 1, 1] : memref<4x64x64xi32, #hivm.address_space<gm>> to memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>>
          %expand_shape_18 = memref.expand_shape %subview_17 [[0, 1], [2]] output_shape [16, 4, 64] {vector_producer_to_fuse_0} : memref<64x64xi32, strided<[64, 1], offset: ?>, #hivm.address_space<gm>> into memref<16x4x64xi32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<gm>>
          hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 5
          %86 = hivm.hir.pointer_cast(%c480_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
          %collapse_shape_19 = memref.collapse_shape %expand_shape_18 [[0, 1, 2]] : memref<16x4x64xi32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<gm>> into memref<4096xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
          %collapse_shape_20 = memref.collapse_shape %86 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.load ins(%collapse_shape_19 : memref<4096xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%collapse_shape_20 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load", vector_producer_to_fuse_0} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
          hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = %79
          %87 = hivm.hir.pointer_cast(%c480_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_21 = memref.collapse_shape %87 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
          hivm.hir.vcast {vector_producer_to_fuse_0} ins(%collapse_shape_20 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_21 : memref<4096xf32, #hivm.address_space<ub>>)
          %88 = hivm.hir.pointer_cast(%c480_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_22 = memref.collapse_shape %87 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %collapse_shape_23 = memref.collapse_shape %expand_shape_14 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
          %collapse_shape_24 = memref.collapse_shape %88 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %89 = hivm.hir.pointer_cast(%c106208_i64) : memref<512xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vmul {vector_producer_to_fuse_0} ins(%collapse_shape_22, %collapse_shape_23 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_24 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%89 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
          %subview_25 = memref.subview %76[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xf32, #hivm.address_space<ub>> to memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %90 = hivm.hir.pointer_cast(%c106208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_26 = memref.collapse_shape %88 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          %collapse_shape_27 = memref.collapse_shape %subview_25 [[0, 1, 2]] : memref<16x4x64xf32, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<4096xf32, strided<[1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_28 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vmul {vector_producer_to_fuse_0} ins(%collapse_shape_26, %collapse_shape_27 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, strided<[1], offset: ?>, #hivm.address_space<ub>>) outs(%collapse_shape_28 : memref<4096xf32, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
          %91 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
          %collapse_shape_29 = memref.collapse_shape %91 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vcmp {vector_producer_to_fuse_0} ins(%collapse_shape_28, %collapse_shape_28 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<4096xi1, #hivm.address_space<ub>>)
          %92 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
          %collapse_shape_30 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vnot {vector_producer_to_fuse_0} ins(%collapse_shape_29 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<4096xi1, #hivm.address_space<ub>>)
          %93 = hivm.hir.pointer_cast(%c123104_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_31 = memref.collapse_shape %93 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.vmax {vector_producer_to_fuse_0} ins(%collapse_shape_28, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_31 : memref<4096xf32, #hivm.address_space<ub>>)
          %94 = hivm.hir.pointer_cast(%c139488_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_32 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          %95 = hivm.hir.pointer_cast(%c155872_i64) : memref<16xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vsel {vector_producer_to_fuse_0} ins(%collapse_shape_30, %cst, %collapse_shape_31 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%95 : memref<16xf32, #hivm.address_space<ub>>)
          %subview_33 = memref.subview %77[%arg17, 0, 0, 0] [1, 16, 4, 64] [1, 1, 1, 1] : memref<4x16x4x64xi1, #hivm.address_space<ub>> to memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>>
          %96 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_34 = memref.collapse_shape %subview_33 [[0, 1, 2]] : memref<16x4x64xi1, strided<[256, 64, 1], offset: ?>, #hivm.address_space<ub>> into memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_35 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
          %97 = hivm.hir.pointer_cast(%c138976_i64) : memref<8xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vsel {vector_producer_to_fuse_0} ins(%collapse_shape_34, %collapse_shape_28, %collapse_shape_32 : memref<4096xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%97 : memref<8xf32, #hivm.address_space<ub>>)
          %98 = hivm.hir.pointer_cast(%c122592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
          %collapse_shape_36 = memref.collapse_shape %96 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %collapse_shape_37 = memref.collapse_shape %expand_shape_15 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
          %collapse_shape_38 = memref.collapse_shape %98 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
          %99 = hivm.hir.pointer_cast(%c106208_i64) : memref<512xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vmul {vector_producer_to_fuse_0} ins(%collapse_shape_36, %collapse_shape_37 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%99 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
          %100 = hivm.hir.pointer_cast(%c106208_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
          %101 = hivm.hir.pointer_cast(%c138976_i64) : memref<4096xf32, #hivm.address_space<ub>>
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vreduce {vector_producer_to_fuse_0} <sum> ins(%98 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%100 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%101 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
          %102 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 29696)>()[%83, %27]
          %reinterpret_cast_39 = memref.reinterpret_cast %arg10 to offset: [%102], sizes: [16, 64], strides: [29696, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>>
          %subview_40 = memref.subview %75[%arg17, 0, 0] [1, 16, 64] [1, 1, 1] : memref<4x16x64xi1, #hivm.address_space<ub>> to memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>
          %103 = hivm.hir.pointer_cast(%c16864_i64) : memref<16x64xf32, #hivm.address_space<ub>>
          %collapse_shape_41 = memref.collapse_shape %subview_40 [[0, 1]] : memref<16x64xi1, strided<[64, 1], offset: ?>, #hivm.address_space<ub>> into memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>
          %collapse_shape_42 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
          %collapse_shape_43 = memref.collapse_shape %103 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
          %104 = hivm.hir.pointer_cast(%c110304_i64) : memref<16xf32, #hivm.address_space<ub>>
          hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
          hivm.hir.pipe_barrier[<PIPE_V>]
          hivm.hir.vsel {vector_producer_to_fuse_0} ins(%collapse_shape_41, %collapse_shape_42, %cst_0 : memref<1024xi1, strided<[1], offset: ?>, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_43 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%104 : memref<16xf32, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
          %105 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%85, %83]
          %subview_44 = memref.subview %103[0, 0] [%46, %105] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
          %subview_45 = memref.subview %reinterpret_cast_39[0, 0] [%46, %105] [1, 1] : memref<16x64xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>>
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
          scf.if %11 {
            hivm.hir.store ins(%subview_44 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_45 : memref<?x?xf32, strided<[29696, 1], offset: ?>, #hivm.address_space<gm>>) {op_to_tile_0_0}
          } {limit_sub_block_id0}
          hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
        } {hivm.loop_core_type = #hivm.tcore_type<VECTOR>, multibuffer_unroll_factor = 4 : i32}
      }
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  }
  hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 6
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 7
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpqyfj17ef/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpqyfj17ef/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpqyfj17ef/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpqyfj17ef/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
