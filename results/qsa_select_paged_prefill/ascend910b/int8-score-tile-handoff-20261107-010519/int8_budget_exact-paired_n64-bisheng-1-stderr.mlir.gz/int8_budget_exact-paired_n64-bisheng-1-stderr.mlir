// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n64_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c57344_i64 = arith.constant 57344 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c49152_i64 = arith.constant 49152 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c40960_i64 = arith.constant 40960 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c0_i64_2 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c2_i32 = arith.constant 2 : i32
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c16384 = arith.constant 16384 : index
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.index_cast %arg15 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg12 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_3 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_3, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_2, %c32768_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_4 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_5 = memref.cast %subview_4 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_5 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_6 = memref.reinterpret_cast %arg11 to offset: [%26], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = memref.load %reinterpret_cast_6[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg16, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg16, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_7 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_7[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.subi %49, %47 : i32
      %55 = arith.remsi %54, %c2_i32 : i32
      %56 = arith.subi %49, %55 : i32
      %57 = arith.extsi %53 : i32 to i64
      %58 = arith.muli %57, %c192_i64 : i64
      scf.for %arg17 = %47 to %56 step %c2_i32  : i32 {
        %59 = arith.index_cast %arg17 : i32 to index
        %60 = arith.index_cast %47 : i32 to index
        %61 = arith.index_cast %56 : i32 to index
        %62 = arith.index_cast %c2_i32 : i32 to index
        %63 = arith.index_cast %arg16 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg15 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg12 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg17 : i32 to index
        %74 = arith.index_cast %47 : i32 to index
        %75 = arith.index_cast %56 : i32 to index
        %76 = arith.index_cast %c2_i32 : i32 to index
        %77 = arith.index_cast %arg16 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg15 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg12 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c5_i64 = arith.constant 5 : i64
        %c6_i64 = arith.constant 6 : i64
        %87 = arith.select %86, %c5_i64, %c6_i64 : i64
        %88 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %89 = arith.select %88, %c3_i64, %c4_i64 : i64
        %90 = hivm.hir.pointer_cast(%c16384_i64, %c49152_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %90 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %91 = hivm.hir.pointer_cast(%c8192_i64, %c40960_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %91 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %92 = arith.muli %arg17, %c64_i32 : i32
        %93 = arith.subi %arg17, %46 : i32
        %94 = arith.muli %93, %c64_i32 : i32
        %95 = arith.extsi %94 : i32 to i64
        %96 = arith.addi %58, %95 : i64
        %97 = arith.index_cast %96 : i64 to index
        %98 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%97]
        %reinterpret_cast_8 = memref.reinterpret_cast %arg4 to offset: [%98], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_9 = memref.cast %91 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %99 = arith.index_cast %92 : i32 to index
        %100 = affine.max affine_map<()[s0] -> (8192, s0)>()[%99]
        %101 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%100, %99]
        %102 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%99, %45]
        %103 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%102, %99]
        %104 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%101, %99, %103]
        %105 = arith.cmpi slt, %104, %c64 : index
        %subview_10 = memref.subview %reinterpret_cast_8[0, 0] [%104, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %106 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%104]
        %subview_11 = memref.subview %91[0, 0, 0, 0] [4, %106, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_12 = memref.cast %subview_11 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %105 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %91 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %89]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_10 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_12 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %107 = hivm.hir.pointer_cast(%c0_i64_2) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_13 = memref.cast %107 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_9, %true, %23, %c128, %104 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_13 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_1, %c-1_i64, %89, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %108 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_13 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%108 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %108 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %109 = arith.addi %arg17, %c1_i32 : i32
        %110 = arith.muli %109, %c64_i32 : i32
        %111 = arith.subi %109, %46 : i32
        %112 = arith.muli %111, %c64_i32 : i32
        %113 = arith.extsi %112 : i32 to i64
        %114 = arith.addi %58, %113 : i64
        %115 = arith.index_cast %114 : i64 to index
        %116 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%115]
        %reinterpret_cast_14 = memref.reinterpret_cast %arg4 to offset: [%116], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_15 = memref.cast %90 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %117 = arith.index_cast %110 : i32 to index
        %118 = affine.max affine_map<()[s0] -> (8192, s0)>()[%117]
        %119 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%118, %117]
        %120 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%117, %45]
        %121 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%120, %117]
        %122 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%119, %117, %121]
        %123 = arith.cmpi slt, %122, %c64 : index
        %subview_16 = memref.subview %reinterpret_cast_14[0, 0] [%122, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %124 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%122]
        %subview_17 = memref.subview %90[0, 0, 0, 0] [4, %124, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_18 = memref.cast %subview_17 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %123 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %90 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_16 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_18 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %125 = hivm.hir.pointer_cast(%c16384_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_19 = memref.cast %125 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        %c-1_i64_20 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_15, %true, %23, %c128, %122 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_19 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64_20, %c0_i64_0, %c-1_i64_20, %87, %72, %c-1_i64_20, %c-1_i64_20 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %126 = memref_ext.alloc_workspace() from %arg2 offset = [%c16384] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_19 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%126 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        annotation.mark %126 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg17 = %56 to %49 step %c1_i32  : i32 {
        %59 = arith.index_cast %arg17 : i32 to index
        %60 = arith.index_cast %56 : i32 to index
        %61 = arith.index_cast %49 : i32 to index
        %62 = arith.index_cast %c1_i32 : i32 to index
        %63 = arith.index_cast %arg16 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg15 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg12 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg17 : i32 to index
        %74 = arith.index_cast %56 : i32 to index
        %75 = arith.index_cast %49 : i32 to index
        %76 = arith.index_cast %c1_i32 : i32 to index
        %77 = arith.index_cast %arg16 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg15 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg12 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c5_i64 = arith.constant 5 : i64
        %c6_i64 = arith.constant 6 : i64
        %87 = arith.select %86, %c5_i64, %c6_i64 : i64
        %88 = hivm.hir.pointer_cast(%c24576_i64, %c57344_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg17, %c64_i32 : i32
        %90 = arith.subi %arg17, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_8 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_9 = memref.cast %88 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c64 : index
        %subview_10 = memref.subview %reinterpret_cast_8[0, 0] [%101, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_11 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_12 = memref.cast %subview_11 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_10 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_12 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_13 = memref.cast %104 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_9, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_13 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_13 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        annotation.mark %105 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n64_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c62144_i64 = arith.constant 62144 : i64
  %c45760_i64 = arith.constant 45760 : i64
  %c45632_i64 = arith.constant 45632 : i64
  %c41536_i64 = arith.constant 41536 : i64
  %c104640_i64 = arith.constant 104640 : i64
  %c100544_i64 = arith.constant 100544 : i64
  %c117440_i64 = arith.constant 117440 : i64
  %c101056_i64 = arith.constant 101056 : i64
  %c25152_i64 = arith.constant 25152 : i64
  %c25024_i64 = arith.constant 25024 : i64
  %c20928_i64 = arith.constant 20928 : i64
  %c84032_i64 = arith.constant 84032 : i64
  %c96704_i64 = arith.constant 96704 : i64
  %c92608_i64 = arith.constant 92608 : i64
  %c88512_i64 = arith.constant 88512 : i64
  %c88256_i64 = arith.constant 88256 : i64
  %c84672_i64 = arith.constant 84672 : i64
  %c118208_i64 = arith.constant 118208 : i64
  %c101824_i64 = arith.constant 101824 : i64
  %c85440_i64 = arith.constant 85440 : i64
  %c84416_i64 = arith.constant 84416 : i64
  %c4544_i64 = arith.constant 4544 : i64
  %c84160_i64 = arith.constant 84160 : i64
  %c4416_i64 = arith.constant 4416 : i64
  %c83904_i64 = arith.constant 83904 : i64
  %c4352_i64 = arith.constant 4352 : i64
  %c83648_i64 = arith.constant 83648 : i64
  %c4224_i64 = arith.constant 4224 : i64
  %c83392_i64 = arith.constant 83392 : i64
  %c4096_i64 = arith.constant 4096 : i64
  %c82880_i64 = arith.constant 82880 : i64
  %c82624_i64 = arith.constant 82624 : i64
  %c0_i64 = arith.constant 0 : i64
  %c66240_i64 = arith.constant 66240 : i64
  %c192_i64 = arith.constant 192 : i64
  %c2_i32 = arith.constant 2 : i32
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %cst = arith.constant 0.000000e+00 : f32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c64 = arith.constant 64 : index
  %cst_1 = arith.constant 0.000000e+00 : f16
  %c16 = arith.constant 16 : index
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %c1_i32 = arith.constant 1 : i32
  %c16384 = arith.constant 16384 : index
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  %7 = hivm.hir.pointer_cast(%c66240_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %7 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c0_i64) : memref<16x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %8 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_2 : memref<1024xf32, #hivm.address_space<ub>>)
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  %9 = hivm.hir.pointer_cast(%c82624_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%9 : memref<64xi32, #hivm.address_space<ub>>)
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  %10 = hivm.hir.pointer_cast(%c82880_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %10 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>)
  %11 = hivm.hir.pointer_cast(%c82880_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %11 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<4096xi1, #hivm.address_space<ub>>)
  %12 = hivm.hir.get_sub_block_idx -> i64
  %13 = arith.index_cast %12 : i64 to index
  %14 = arith.cmpi eq, %13, %c0 : index
  %15 = hivm.hir.pointer_cast(%c66240_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_5 = memref.collapse_shape %15 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_5 : memref<4096xi1, #hivm.address_space<ub>>)
  %16 = hivm.hir.pointer_cast(%c66240_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_6 = memref.collapse_shape %16 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_5 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_6 : memref<4096xi1, #hivm.address_space<ub>>)
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID7>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %17 = arith.divsi %arg15, %c16_i32 : i32
    %18 = arith.remsi %arg15, %c16_i32 : i32
    %19 = arith.muli %18, %c8_i32 : i32
    %20 = arith.muli %17, %c16_i32 : i32
    %21 = arith.muli %17, %c64_i32 : i32
    %22 = arith.index_cast %21 : i32 to index
    %23 = affine.max affine_map<()[s0] -> (512, s0)>()[%22]
    %24 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%23, %22]
    %25 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%24, %22]
    %26 = arith.cmpi slt, %25, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%22], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = hivm.hir.pointer_cast(%c4096_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %27 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%25] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_8 = memref.subview %collapse_shape_7[0] [%25] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %26 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID6>]
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_8 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %28 = hivm.hir.pointer_cast(%c83392_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_9 = memref.collapse_shape %28 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_9 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID6>]
    %reinterpret_cast_10 = memref.reinterpret_cast %arg7 to offset: [%22], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %29 = hivm.hir.pointer_cast(%c4224_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_11 = memref.collapse_shape %29 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_12 = memref.subview %reinterpret_cast_10[0] [%25] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_13 = memref.subview %collapse_shape_11[0] [%25] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %26 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_11 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID7>]
    hivm.hir.load ins(%subview_12 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_13 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %30 = hivm.hir.pointer_cast(%c83648_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_14 = memref.collapse_shape %30 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_11 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_14 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID7>]
    %31 = arith.index_cast %20 : i32 to index
    %reinterpret_cast_15 = memref.reinterpret_cast %arg9 to offset: [%31], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %32 = hivm.hir.pointer_cast(%c4352_i64) : memref<16xi32, #hivm.address_space<ub>>
    %33 = affine.max affine_map<()[s0] -> (128, s0)>()[%31]
    %34 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%33, %31]
    %35 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%34, %31]
    %36 = arith.cmpi slt, %35, %c16 : index
    %subview_16 = memref.subview %reinterpret_cast_15[0] [%35] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_17 = memref.subview %32[0] [%35] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %36 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%32 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE2>]
    hivm.hir.load ins(%subview_16 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_17 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    %37 = arith.index_cast %17 : i32 to index
    %reinterpret_cast_18 = memref.reinterpret_cast %arg11 to offset: [%37], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %38 = memref.load %reinterpret_cast_18[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %39 = arith.minsi %38, %c8192_i32 : i32
    %40 = arith.addi %39, %c63_i32 : i32
    %41 = arith.divsi %40, %c64_i32 : i32
    %42 = arith.subi %41, %19 : i32
    %43 = arith.maxsi %42, %c0_i32 : i32
    %44 = arith.minsi %43, %c8_i32 : i32
    %45 = arith.divsi %19, %c3_i32 : i32
    %46 = arith.cmpi sgt, %44, %c0_i32 : i32
    %47 = arith.remsi %19, %c3_i32 : i32
    %48 = arith.addi %47, %44 : i32
    %49 = arith.addi %48, %c2_i32 : i32
    %50 = arith.divsi %49, %c3_i32 : i32
    %51 = arith.select %46, %50, %c0_i32 : i32
    %52 = arith.addi %45, %51 : i32
    %53 = arith.addi %19, %44 : i32
    %54 = arith.muli %17, %c688_i32 : i32
    %55 = arith.index_cast %54 : i32 to index
    %56 = arith.index_cast %38 : i32 to index
    %expand_shape = memref.expand_shape %28 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_19 = memref.expand_shape %30 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_20 = memref.expand_shape %32 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    %57 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%34, %31]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %45 to %52 step %c1_i32  : i32 {
      %58 = arith.muli %arg16, %c3_i32 : i32
      %59 = arith.maxsi %19, %58 : i32
      %60 = arith.addi %58, %c3_i32 : i32
      %61 = arith.minsi %53, %60 : i32
      %62 = arith.minsi %arg16, %c42_i32 : i32
      %63 = arith.index_cast %62 : i32 to index
      %64 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%55, %63]
      %reinterpret_cast_21 = memref.reinterpret_cast %arg8 to offset: [%64], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %65 = memref.load %reinterpret_cast_21[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %66 = arith.subi %61, %59 : i32
      %67 = arith.remsi %66, %c2_i32 : i32
      %68 = arith.subi %61, %67 : i32
      %69 = arith.extsi %65 : i32 to i64
      %70 = arith.muli %69, %c192_i64 : i64
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg17 = %59 to %68 step %c2_i32  : i32 {
        %71 = arith.muli %arg17, %c64_i32 : i32
        %72 = hivm.hir.pointer_cast(%c83904_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%9, %71 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%72 : memref<64xi32, #hivm.address_space<ub>>)
        %73 = arith.subi %arg17, %58 : i32
        %74 = arith.muli %73, %c64_i32 : i32
        %75 = arith.extsi %74 : i32 to i64
        %76 = arith.addi %70, %75 : i64
        %77 = arith.index_cast %76 : i64 to index
        %78 = arith.index_cast %71 : i32 to index
        %79 = affine.max affine_map<()[s0] -> (8192, s0)>()[%78]
        %80 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%79, %78]
        %81 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%78, %56]
        %82 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%81, %78]
        %83 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%80, %78, %82]
        %84 = arith.cmpi slt, %83, %c64 : index
        %reinterpret_cast_22 = memref.reinterpret_cast %arg6 to offset: [%77], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %85 = hivm.hir.pointer_cast(%c4416_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_23 = memref.subview %reinterpret_cast_22[0] [%83] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_24 = memref.subview %85[0] [%83] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %84 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%85 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_23 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_24 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %86 = hivm.hir.pointer_cast(%c84160_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%85 : memref<64xf16, #hivm.address_space<ub>>) outs(%86 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %87 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %88 = hivm.hir.pointer_cast(%c4544_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %87 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_26 = memref.collapse_shape %88 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        %89 = hivm.hir.pointer_cast(%c4544_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %89 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_27 : memref<4096xf32, #hivm.address_space<ub>>)
        %90 = hivm.hir.pointer_cast(%c4544_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %89 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %90 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %91 = hivm.hir.pointer_cast(%c84416_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_28, %collapse_shape_29 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%91 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %92 = hivm.hir.pointer_cast(%c85440_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %93 = hivm.hir.pointer_cast(%c84416_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_31 = memref.expand_shape %86 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %93 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_31 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_33 = memref.collapse_shape %93 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %92 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_33 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %94 = hivm.hir.pointer_cast(%c85440_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_35, %collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %95 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %95 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_37, %collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>)
        %96 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>)
        %97 = hivm.hir.pointer_cast(%c101824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_37, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c118208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %99 = hivm.hir.pointer_cast(%c84672_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_39, %cst, %collapse_shape_40 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_41 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%99 : memref<16xf32, #hivm.address_space<ub>>)
        %100 = hivm.hir.pointer_cast(%c101824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c84160_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_37, %collapse_shape_41 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%101 : memref<8xf32, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c101824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %100 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %expand_shape_19 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %102 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %103 = hivm.hir.pointer_cast(%c84160_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_43, %collapse_shape_44 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_45 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%103 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %104 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c118208_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%102 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%104 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_46 = memref.expand_shape %72 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %106 = hivm.hir.pointer_cast(%c88256_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %106 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%72, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_47 : memref<64xi32, #hivm.address_space<ub>>)
        %107 = hivm.hir.pointer_cast(%c88256_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %107 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_47, %72 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c88256_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %108 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>)
        %109 = hivm.hir.pointer_cast(%c88512_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_46 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%109 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %110 = hivm.hir.pointer_cast(%c92608_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %111 = hivm.hir.pointer_cast(%c96704_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_46, %expand_shape_20 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%110 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%111 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %112 = hivm.hir.pointer_cast(%c92608_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %110 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %109 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %112 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_50, %collapse_shape_51 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>)
        %113 = hivm.hir.pointer_cast(%c92608_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %113 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>)
        %114 = hivm.hir.pointer_cast(%c83904_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %114 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %115 = hivm.hir.pointer_cast(%c84032_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%115 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %116 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%114 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%116 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %117 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %116 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %117 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_55, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %118 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>)
        %119 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %119 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_57, %collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_58 : memref<1024xi1, #hivm.address_space<ub>>)
        %120 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%78, %31]
        %reinterpret_cast_59 = memref.reinterpret_cast %arg10 to offset: [%120], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %121 = hivm.hir.pointer_cast(%c20928_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_60 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_61 = memref.collapse_shape %121 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %122 = hivm.hir.pointer_cast(%c83904_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_58, %collapse_shape_60, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_61 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%122 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %123 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%80, %78]
        %subview_62 = memref.subview %121[0, 0] [%57, %123] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_63 = memref.subview %reinterpret_cast_59[0, 0] [%57, %123] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %14 {
          hivm.hir.pipe_barrier[<PIPE_MTE3>]
          hivm.hir.store ins(%subview_62 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_63 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        %124 = arith.addi %arg17, %c1_i32 : i32
        %125 = arith.muli %124, %c64_i32 : i32
        %126 = hivm.hir.pointer_cast(%c83904_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%9, %125 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%126 : memref<64xi32, #hivm.address_space<ub>>)
        %127 = arith.subi %124, %58 : i32
        %128 = arith.muli %127, %c64_i32 : i32
        %129 = arith.extsi %128 : i32 to i64
        %130 = arith.addi %70, %129 : i64
        %131 = arith.index_cast %130 : i64 to index
        %132 = arith.index_cast %125 : i32 to index
        %133 = affine.max affine_map<()[s0] -> (8192, s0)>()[%132]
        %134 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%133, %132]
        %135 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%132, %56]
        %136 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%135, %132]
        %137 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%134, %132, %136]
        %138 = arith.cmpi slt, %137, %c64 : index
        %reinterpret_cast_64 = memref.reinterpret_cast %arg6 to offset: [%131], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %139 = hivm.hir.pointer_cast(%c25024_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_65 = memref.subview %reinterpret_cast_64[0] [%137] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_66 = memref.subview %139[0] [%137] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %138 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%139 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        hivm.hir.load ins(%subview_65 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_66 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %140 = hivm.hir.pointer_cast(%c84160_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%139 : memref<64xf16, #hivm.address_space<ub>>) outs(%140 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        %141 = memref_ext.alloc_workspace() from %arg2 offset = [%c16384] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %142 = hivm.hir.pointer_cast(%c25152_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_67 = memref.collapse_shape %141 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_68 = memref.collapse_shape %142 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        hivm.hir.load ins(%collapse_shape_67 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_68 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        %143 = hivm.hir.pointer_cast(%c25152_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_69 = memref.collapse_shape %143 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_68 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_69 : memref<4096xf32, #hivm.address_space<ub>>)
        %144 = hivm.hir.pointer_cast(%c25152_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_70 = memref.collapse_shape %143 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_71 = memref.collapse_shape %144 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %145 = hivm.hir.pointer_cast(%c84416_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_70, %collapse_shape_29 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_71 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%145 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %146 = hivm.hir.pointer_cast(%c85440_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %147 = hivm.hir.pointer_cast(%c84416_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_72 = memref.expand_shape %140 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_73 = memref.collapse_shape %147 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_72 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_73 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_74 = memref.collapse_shape %147 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_75 = memref.collapse_shape %146 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_74 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_75 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %148 = hivm.hir.pointer_cast(%c25152_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_76 = memref.collapse_shape %144 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_77 = memref.collapse_shape %146 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_78 = memref.collapse_shape %148 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_76, %collapse_shape_77 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_78 : memref<4096xf32, #hivm.address_space<ub>>)
        %149 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_79 = memref.collapse_shape %149 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_78, %collapse_shape_78 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_79 : memref<4096xi1, #hivm.address_space<ub>>)
        %150 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_80 = memref.collapse_shape %150 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_79 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_80 : memref<4096xi1, #hivm.address_space<ub>>)
        %151 = hivm.hir.pointer_cast(%c84672_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_81 = memref.collapse_shape %151 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_78, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_81 : memref<4096xf32, #hivm.address_space<ub>>)
        %152 = hivm.hir.pointer_cast(%c101056_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_82 = memref.collapse_shape %152 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %153 = hivm.hir.pointer_cast(%c117440_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_80, %cst, %collapse_shape_81 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_82 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%153 : memref<16xf32, #hivm.address_space<ub>>)
        %154 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_83 = memref.collapse_shape %154 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %155 = hivm.hir.pointer_cast(%c100544_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_78, %collapse_shape_82 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_83 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%155 : memref<8xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        %156 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_84 = memref.collapse_shape %154 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_85 = memref.collapse_shape %156 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %157 = hivm.hir.pointer_cast(%c100544_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_84, %collapse_shape_44 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_85 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%157 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %158 = hivm.hir.pointer_cast(%c100544_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %159 = hivm.hir.pointer_cast(%c104640_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%156 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%158 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%159 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_86 = memref.expand_shape %126 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %160 = hivm.hir.pointer_cast(%c84160_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_87 = memref.collapse_shape %160 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmax ins(%126, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_87 : memref<64xi32, #hivm.address_space<ub>>)
        %161 = hivm.hir.pointer_cast(%c84160_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_88 = memref.collapse_shape %161 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_87, %126 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_88 : memref<64xi1, #hivm.address_space<ub>>)
        %162 = hivm.hir.pointer_cast(%c84160_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_89 = memref.collapse_shape %162 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_88 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_89 : memref<64xi1, #hivm.address_space<ub>>)
        %163 = hivm.hir.pointer_cast(%c84416_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_86 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%163 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %164 = hivm.hir.pointer_cast(%c88512_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %165 = hivm.hir.pointer_cast(%c92608_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_86, %expand_shape_20 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%164 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%165 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %166 = hivm.hir.pointer_cast(%c88512_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_90 = memref.collapse_shape %164 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_91 = memref.collapse_shape %163 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_92 = memref.collapse_shape %166 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_90, %collapse_shape_91 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_92 : memref<1024xi1, #hivm.address_space<ub>>)
        %167 = hivm.hir.pointer_cast(%c88512_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_93 = memref.collapse_shape %167 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_92 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_93 : memref<1024xi1, #hivm.address_space<ub>>)
        %168 = hivm.hir.pointer_cast(%c83904_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_94 = memref.collapse_shape %168 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %169 = hivm.hir.pointer_cast(%c84032_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_89 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_94 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%169 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %170 = hivm.hir.pointer_cast(%c84032_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%168 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%170 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %171 = hivm.hir.pointer_cast(%c84032_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_95 = memref.collapse_shape %170 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_96 = memref.collapse_shape %171 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_95, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_96 : memref<1024xi1, #hivm.address_space<ub>>)
        %172 = hivm.hir.pointer_cast(%c84032_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_97 = memref.collapse_shape %172 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_96 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_97 : memref<1024xi1, #hivm.address_space<ub>>)
        %173 = hivm.hir.pointer_cast(%c84032_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_98 = memref.collapse_shape %173 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_97, %collapse_shape_93 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_98 : memref<1024xi1, #hivm.address_space<ub>>)
        %174 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%132, %31]
        %reinterpret_cast_99 = memref.reinterpret_cast %arg10 to offset: [%174], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %175 = hivm.hir.pointer_cast(%c41536_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_100 = memref.collapse_shape %158 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_101 = memref.collapse_shape %175 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %176 = hivm.hir.pointer_cast(%c83904_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_98, %collapse_shape_100, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_101 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%176 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %177 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%134, %132]
        %subview_102 = memref.subview %175[0, 0] [%57, %177] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_103 = memref.subview %reinterpret_cast_99[0, 0] [%57, %177] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %14 {
          hivm.hir.pipe_barrier[<PIPE_MTE3>]
          hivm.hir.store ins(%subview_102 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_103 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
      } {fixpipe_for_mmad_result_already_inserted = true}
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg17 = %68 to %61 step %c1_i32  : i32 {
        %71 = arith.muli %arg17, %c64_i32 : i32
        %72 = hivm.hir.pointer_cast(%c83904_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%9, %71 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%72 : memref<64xi32, #hivm.address_space<ub>>)
        %73 = arith.subi %arg17, %58 : i32
        %74 = arith.muli %73, %c64_i32 : i32
        %75 = arith.extsi %74 : i32 to i64
        %76 = arith.addi %70, %75 : i64
        %77 = arith.index_cast %76 : i64 to index
        %78 = arith.index_cast %71 : i32 to index
        %79 = affine.max affine_map<()[s0] -> (8192, s0)>()[%78]
        %80 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%79, %78]
        %81 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%78, %56]
        %82 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%81, %78]
        %83 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%80, %78, %82]
        %84 = arith.cmpi slt, %83, %c64 : index
        %reinterpret_cast_22 = memref.reinterpret_cast %arg6 to offset: [%77], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %85 = hivm.hir.pointer_cast(%c45632_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_23 = memref.subview %reinterpret_cast_22[0] [%83] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_24 = memref.subview %85[0] [%83] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %84 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%85 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        hivm.hir.load ins(%subview_23 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_24 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %86 = hivm.hir.pointer_cast(%c84160_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%85 : memref<64xf16, #hivm.address_space<ub>>) outs(%86 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        %87 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %88 = hivm.hir.pointer_cast(%c45760_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %87 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_26 = memref.collapse_shape %88 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        hivm.hir.load ins(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        %89 = hivm.hir.pointer_cast(%c45760_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %89 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_27 : memref<4096xf32, #hivm.address_space<ub>>)
        %90 = hivm.hir.pointer_cast(%c45760_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %89 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %90 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %91 = hivm.hir.pointer_cast(%c84416_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_28, %collapse_shape_29 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%91 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %92 = hivm.hir.pointer_cast(%c85440_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %93 = hivm.hir.pointer_cast(%c84416_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_31 = memref.expand_shape %86 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %93 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_31 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_33 = memref.collapse_shape %93 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %92 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_33 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %94 = hivm.hir.pointer_cast(%c85440_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_35, %collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        %95 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %95 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_37, %collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>)
        %96 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>)
        %97 = hivm.hir.pointer_cast(%c101824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_37, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c118208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %99 = hivm.hir.pointer_cast(%c84672_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_39, %cst, %collapse_shape_40 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_41 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%99 : memref<16xf32, #hivm.address_space<ub>>)
        %100 = hivm.hir.pointer_cast(%c101824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c84160_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_6, %collapse_shape_37, %collapse_shape_41 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%101 : memref<8xf32, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c101824_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %100 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %expand_shape_19 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %102 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %103 = hivm.hir.pointer_cast(%c84160_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_43, %collapse_shape_44 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_45 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%103 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %104 = hivm.hir.pointer_cast(%c84160_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c118208_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%102 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%104 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_46 = memref.expand_shape %72 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %106 = hivm.hir.pointer_cast(%c88256_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %106 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%72, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_47 : memref<64xi32, #hivm.address_space<ub>>)
        %107 = hivm.hir.pointer_cast(%c88256_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %107 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_47, %72 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c88256_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %108 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>)
        %109 = hivm.hir.pointer_cast(%c88512_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_46 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%109 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %110 = hivm.hir.pointer_cast(%c92608_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %111 = hivm.hir.pointer_cast(%c96704_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_46, %expand_shape_20 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%110 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%111 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %112 = hivm.hir.pointer_cast(%c92608_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %110 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %109 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %112 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_50, %collapse_shape_51 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>)
        %113 = hivm.hir.pointer_cast(%c92608_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %113 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>)
        %114 = hivm.hir.pointer_cast(%c83904_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %114 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %115 = hivm.hir.pointer_cast(%c84032_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%115 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %116 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%114 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%116 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %117 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %116 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %117 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_55, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %118 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>)
        %119 = hivm.hir.pointer_cast(%c88256_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %119 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_57, %collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_58 : memref<1024xi1, #hivm.address_space<ub>>)
        %120 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%78, %31]
        %reinterpret_cast_59 = memref.reinterpret_cast %arg10 to offset: [%120], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %121 = hivm.hir.pointer_cast(%c62144_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_60 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_61 = memref.collapse_shape %121 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %122 = hivm.hir.pointer_cast(%c83904_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_58, %collapse_shape_60, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_61 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%122 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %123 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%80, %78]
        %subview_62 = memref.subview %121[0, 0] [%57, %123] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_63 = memref.subview %reinterpret_cast_59[0, 0] [%57, %123] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %14 {
          hivm.hir.store ins(%subview_62 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_63 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %44 to %c8_i32 step %c1_i32  : i32 {
      %58 = arith.addi %19, %arg16 : i32
      %59 = arith.muli %58, %c64_i32 : i32
      %60 = arith.index_cast %59 : i32 to index
      %61 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%60, %31]
      %reinterpret_cast_21 = memref.reinterpret_cast %arg10 to offset: [%61], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %62 = affine.max affine_map<()[s0] -> (8192, s0)>()[%60]
      %63 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%62, %60]
      %64 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%63, %60]
      %subview_22 = memref.subview %8[0, 0] [%57, %64] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_23 = memref.subview %reinterpret_cast_21[0, 0] [%57, %64] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      scf.if %14 {
        hivm.hir.pipe_barrier[<PIPE_MTE3>]
        hivm.hir.store ins(%subview_22 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_23 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
      } {limit_sub_block_id0}
    }
  }
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID7>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmp2kqiqo_d/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmp2kqiqo_d/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmp2kqiqo_d/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmp2kqiqo_d/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
