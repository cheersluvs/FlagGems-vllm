// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c57344_i64 = arith.constant 57344 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c40960_i64 = arith.constant 40960 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %7 = arith.index_cast %arg15 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg12 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_2 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_2, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_1, %c32768_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg15, %c16_i32 : i32
    %16 = arith.remsi %arg15, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_3 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_4 = memref.cast %subview_3 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_4 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = arith.index_cast %15 : i32 to index
    %reinterpret_cast_5 = memref.reinterpret_cast %arg11 to offset: [%26], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = memref.load %reinterpret_cast_5[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg16 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg16, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg16, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_6 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_6[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.subi %49, %47 : i32
      %55 = arith.remsi %54, %c2_i32 : i32
      %56 = arith.subi %49, %55 : i32
      %57 = arith.extsi %53 : i32 to i64
      %58 = arith.muli %57, %c192_i64 : i64
      scf.for %arg17 = %47 to %56 step %c2_i32  : i32 {
        %59 = arith.index_cast %arg17 : i32 to index
        %60 = arith.index_cast %47 : i32 to index
        %61 = arith.index_cast %56 : i32 to index
        %62 = arith.index_cast %c2_i32 : i32 to index
        %63 = arith.index_cast %arg16 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg15 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg12 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg17 : i32 to index
        %74 = arith.index_cast %47 : i32 to index
        %75 = arith.index_cast %56 : i32 to index
        %76 = arith.index_cast %c2_i32 : i32 to index
        %77 = arith.index_cast %arg16 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg15 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg12 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %87 = arith.select %86, %c3_i64, %c4_i64 : i64
        %88 = hivm.hir.pointer_cast(%c8192_i64, %c40960_i64) : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg17, %c64_i32 : i32
        %90 = arith.subi %arg17, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [128, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %88 : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c128 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> into memref<16384xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<16384xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c0_i64_1) : memref<8x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<8x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_0, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x128xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg17 = %56 to %49 step %c1_i32  : i32 {
        %59 = arith.index_cast %arg17 : i32 to index
        %60 = arith.index_cast %56 : i32 to index
        %61 = arith.index_cast %49 : i32 to index
        %62 = arith.index_cast %c1_i32 : i32 to index
        %63 = arith.index_cast %arg16 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg15 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg12 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg17 : i32 to index
        %74 = arith.index_cast %56 : i32 to index
        %75 = arith.index_cast %49 : i32 to index
        %76 = arith.index_cast %c1_i32 : i32 to index
        %77 = arith.index_cast %arg16 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg15 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg12 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %87 = arith.select %86, %c3_i64, %c4_i64 : i64
        %88 = hivm.hir.pointer_cast(%c24576_i64, %c57344_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg17, %c64_i32 : i32
        %90 = arith.subi %arg17, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %88 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c64 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 0
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<15xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c62144_i64 = arith.constant 62144 : i64
  %c116800_i64 = arith.constant 116800 : i64
  %c129472_i64 = arith.constant 129472 : i64
  %c121280_i64 = arith.constant 121280 : i64
  %c121024_i64 = arith.constant 121024 : i64
  %c117440_i64 = arith.constant 117440 : i64
  %c150976_i64 = arith.constant 150976 : i64
  %c134592_i64 = arith.constant 134592 : i64
  %c45760_i64 = arith.constant 45760 : i64
  %c45632_i64 = arith.constant 45632 : i64
  %c37440_i64 = arith.constant 37440 : i64
  %c116928_i64 = arith.constant 116928 : i64
  %c142272_i64 = arith.constant 142272 : i64
  %c134080_i64 = arith.constant 134080 : i64
  %c125888_i64 = arith.constant 125888 : i64
  %c125376_i64 = arith.constant 125376 : i64
  %c118208_i64 = arith.constant 118208 : i64
  %c152512_i64 = arith.constant 152512 : i64
  %c119744_i64 = arith.constant 119744 : i64
  %c117696_i64 = arith.constant 117696 : i64
  %c4672_i64 = arith.constant 4672 : i64
  %c117184_i64 = arith.constant 117184 : i64
  %c4416_i64 = arith.constant 4416 : i64
  %c116672_i64 = arith.constant 116672 : i64
  %c4352_i64 = arith.constant 4352 : i64
  %c116416_i64 = arith.constant 116416 : i64
  %c4224_i64 = arith.constant 4224 : i64
  %c116160_i64 = arith.constant 116160 : i64
  %c4096_i64 = arith.constant 4096 : i64
  %c115904_i64 = arith.constant 115904 : i64
  %c115392_i64 = arith.constant 115392 : i64
  %c0_i64 = arith.constant 0 : i64
  %c99008_i64 = arith.constant 99008 : i64
  %c66240_i64 = arith.constant 66240 : i64
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %cst = arith.constant 0.000000e+00 : f32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %cst_1 = arith.constant 0.000000e+00 : f16
  %c16 = arith.constant 16 : index
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %c1_i32 = arith.constant 1 : i32
  %c32768 = arith.constant 32768 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg12, %arg13 : i32
  %1 = arith.muli %0, %arg14 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg14, %arg13 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg12 : i32
  %7 = hivm.hir.pointer_cast(%c66240_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %7 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape : memref<8192xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c99008_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %8 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape_2 : memref<4096xf32, #hivm.address_space<ub>>)
  %9 = hivm.hir.pointer_cast(%c0_i64) : memref<16x64xf32, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %9 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_3 : memref<1024xf32, #hivm.address_space<ub>>)
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  %10 = hivm.hir.pointer_cast(%c115392_i64) : memref<128xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%10 : memref<128xi32, #hivm.address_space<ub>>)
  %11 = hivm.hir.pointer_cast(%c115904_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%11 : memref<64xi32, #hivm.address_space<ub>>)
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  %12 = hivm.hir.pointer_cast(%c66240_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %12 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<8192xi1, #hivm.address_space<ub>>)
  %13 = hivm.hir.pointer_cast(%c66240_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
  %collapse_shape_5 = memref.collapse_shape %13 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_4 : memref<8192xi1, #hivm.address_space<ub>>) outs(%collapse_shape_5 : memref<8192xi1, #hivm.address_space<ub>>)
  %14 = hivm.hir.get_sub_block_idx -> i64
  %15 = arith.index_cast %14 : i64 to index
  %16 = arith.cmpi eq, %15, %c0 : index
  %17 = hivm.hir.pointer_cast(%c99008_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_6 = memref.collapse_shape %17 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.vcmp ins(%collapse_shape_2, %collapse_shape_2 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_6 : memref<4096xi1, #hivm.address_space<ub>>)
  %18 = hivm.hir.pointer_cast(%c99008_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_7 = memref.collapse_shape %18 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_6 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_7 : memref<4096xi1, #hivm.address_space<ub>>)
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  scf.for %arg15 = %6 to %c128_i32 step %arg12  : i32 {
    %19 = arith.divsi %arg15, %c16_i32 : i32
    %20 = arith.remsi %arg15, %c16_i32 : i32
    %21 = arith.muli %20, %c8_i32 : i32
    %22 = arith.muli %19, %c16_i32 : i32
    %23 = arith.muli %19, %c64_i32 : i32
    %24 = arith.index_cast %23 : i32 to index
    %25 = affine.max affine_map<()[s0] -> (512, s0)>()[%24]
    %26 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%25, %24]
    %27 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%26, %24]
    %28 = arith.cmpi slt, %27, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%24], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %29 = hivm.hir.pointer_cast(%c4096_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_8 = memref.collapse_shape %29 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%27] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_9 = memref.subview %collapse_shape_8[0] [%27] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %28 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_8 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_9 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %30 = hivm.hir.pointer_cast(%c116160_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_10 = memref.collapse_shape %30 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_8 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_10 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
    %reinterpret_cast_11 = memref.reinterpret_cast %arg7 to offset: [%24], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %31 = hivm.hir.pointer_cast(%c4224_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_12 = memref.collapse_shape %31 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_13 = memref.subview %reinterpret_cast_11[0] [%27] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_14 = memref.subview %collapse_shape_12[0] [%27] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %28 {
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vbrc ins(%cst_1 : f16) outs(%collapse_shape_12 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
    hivm.hir.load ins(%subview_13 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_14 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %32 = hivm.hir.pointer_cast(%c116416_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_15 = memref.collapse_shape %32 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_12 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_15 : memref<64xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
    %33 = arith.index_cast %22 : i32 to index
    %reinterpret_cast_16 = memref.reinterpret_cast %arg9 to offset: [%33], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %34 = hivm.hir.pointer_cast(%c4352_i64) : memref<16xi32, #hivm.address_space<ub>>
    %35 = affine.max affine_map<()[s0] -> (128, s0)>()[%33]
    %36 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%35, %33]
    %37 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%36, %33]
    %38 = arith.cmpi slt, %37, %c16 : index
    %subview_17 = memref.subview %reinterpret_cast_16[0] [%37] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_18 = memref.subview %34[0] [%37] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %38 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%34 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE2>]
    hivm.hir.load ins(%subview_17 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_18 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    %39 = arith.index_cast %19 : i32 to index
    %reinterpret_cast_19 = memref.reinterpret_cast %arg11 to offset: [%39], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %40 = memref.load %reinterpret_cast_19[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %41 = arith.minsi %40, %c8192_i32 : i32
    %42 = arith.addi %41, %c63_i32 : i32
    %43 = arith.divsi %42, %c64_i32 : i32
    %44 = arith.subi %43, %21 : i32
    %45 = arith.maxsi %44, %c0_i32 : i32
    %46 = arith.minsi %45, %c8_i32 : i32
    %47 = arith.divsi %21, %c3_i32 : i32
    %48 = arith.cmpi sgt, %46, %c0_i32 : i32
    %49 = arith.remsi %21, %c3_i32 : i32
    %50 = arith.addi %49, %46 : i32
    %51 = arith.addi %50, %c2_i32 : i32
    %52 = arith.divsi %51, %c3_i32 : i32
    %53 = arith.select %48, %52, %c0_i32 : i32
    %54 = arith.addi %47, %53 : i32
    %55 = arith.addi %21, %46 : i32
    %56 = arith.muli %19, %c688_i32 : i32
    %57 = arith.index_cast %56 : i32 to index
    %58 = arith.index_cast %40 : i32 to index
    %expand_shape = memref.expand_shape %30 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_20 = memref.expand_shape %32 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_21 = memref.expand_shape %34 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    %59 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%36, %33]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %47 to %54 step %c1_i32  : i32 {
      %60 = arith.muli %arg16, %c3_i32 : i32
      %61 = arith.maxsi %21, %60 : i32
      %62 = arith.addi %60, %c3_i32 : i32
      %63 = arith.minsi %55, %62 : i32
      %64 = arith.minsi %arg16, %c42_i32 : i32
      %65 = arith.index_cast %64 : i32 to index
      %66 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%57, %65]
      %reinterpret_cast_22 = memref.reinterpret_cast %arg8 to offset: [%66], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %67 = memref.load %reinterpret_cast_22[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %68 = arith.subi %63, %61 : i32
      %69 = arith.remsi %68, %c2_i32 : i32
      %70 = arith.subi %63, %69 : i32
      %71 = arith.extsi %67 : i32 to i64
      %72 = arith.muli %71, %c192_i64 : i64
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg17 = %61 to %70 step %c2_i32  : i32 {
        %73 = arith.muli %arg17, %c64_i32 : i32
        %74 = hivm.hir.pointer_cast(%c116672_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%10, %73 : memref<128xi32, #hivm.address_space<ub>>, i32) outs(%74 : memref<128xi32, #hivm.address_space<ub>>)
        %75 = arith.subi %arg17, %60 : i32
        %76 = arith.muli %75, %c64_i32 : i32
        %77 = arith.extsi %76 : i32 to i64
        %78 = arith.addi %72, %77 : i64
        %79 = arith.index_cast %78 : i64 to index
        %80 = arith.index_cast %73 : i32 to index
        %81 = affine.max affine_map<()[s0] -> (8192, s0)>()[%80]
        %82 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%81, %80]
        %83 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%80, %58]
        %84 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%83, %80]
        %85 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%82, %80, %84]
        %86 = arith.cmpi slt, %85, %c128 : index
        %reinterpret_cast_23 = memref.reinterpret_cast %arg6 to offset: [%79], sizes: [128], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<128xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %87 = hivm.hir.pointer_cast(%c4416_i64) : memref<128xf16, #hivm.address_space<ub>>
        %subview_24 = memref.subview %reinterpret_cast_23[0] [%85] [1] : memref<128xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_25 = memref.subview %87[0] [%85] [1] : memref<128xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %86 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%87 : memref<128xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%subview_24 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_25 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %88 = hivm.hir.pointer_cast(%c117184_i64) : memref<128xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%87 : memref<128xf16, #hivm.address_space<ub>>) outs(%88 : memref<128xf32, #hivm.address_space<ub>>)
        %89 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %90 = hivm.hir.pointer_cast(%c4672_i64) : memref<16x4x128xi32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %89 [[0, 1]] : memref<64x128xi32, #hivm.address_space<gm>> into memref<8192xi32, #hivm.address_space<gm>>
        %collapse_shape_27 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x128xi32, #hivm.address_space<ub>> into memref<8192xi32, #hivm.address_space<ub>>
        hivm.hir.load ins(%collapse_shape_26 : memref<8192xi32, #hivm.address_space<gm>>) outs(%collapse_shape_27 : memref<8192xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 1
        %91 = hivm.hir.pointer_cast(%c4672_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %91 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_27 : memref<8192xi32, #hivm.address_space<ub>>) outs(%collapse_shape_28 : memref<8192xf32, #hivm.address_space<ub>>)
        %92 = hivm.hir.pointer_cast(%c4672_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %91 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_31 = memref.collapse_shape %92 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %93 = hivm.hir.pointer_cast(%c117696_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_29, %collapse_shape_30 : memref<64x128xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_31 : memref<64x128xf32, #hivm.address_space<ub>>) temp_buffer(%93 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %94 = hivm.hir.pointer_cast(%c119744_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %95 = hivm.hir.pointer_cast(%c117696_i64) : memref<1x4x128xf32, #hivm.address_space<ub>>
        %expand_shape_32 = memref.expand_shape %88 [[0, 1]] output_shape [1, 128] : memref<128xf32, #hivm.address_space<ub>> into memref<1x128xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %95 [[0, 1], [2]] : memref<1x4x128xf32, #hivm.address_space<ub>> into memref<4x128xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_32 : memref<1x128xf32, #hivm.address_space<ub>>) outs(%collapse_shape_33 : memref<4x128xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_34 = memref.collapse_shape %95 [[0], [1, 2]] : memref<1x4x128xf32, #hivm.address_space<ub>> into memref<1x512xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %94 [[0], [1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<16x512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_34 : memref<1x512xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<16x512xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %96 = hivm.hir.pointer_cast(%c119744_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_36, %collapse_shape_37 : memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<8192xf32, #hivm.address_space<ub>>)
        %97 = hivm.hir.pointer_cast(%c117184_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_38, %collapse_shape_38 : memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<8192xi1, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c117184_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_39 : memref<8192xi1, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<8192xi1, #hivm.address_space<ub>>)
        %99 = hivm.hir.pointer_cast(%c152512_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %99 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_38, %cst : memref<8192xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_41 : memref<8192xf32, #hivm.address_space<ub>>)
        %100 = hivm.hir.pointer_cast(%c4416_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c118208_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_40, %cst, %collapse_shape_41 : memref<8192xi1, #hivm.address_space<ub>>, f32, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<8192xf32, #hivm.address_space<ub>>) temp_buffer(%101 : memref<16xf32, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c152512_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %103 = hivm.hir.pointer_cast(%c117184_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_5, %collapse_shape_38, %collapse_shape_42 : memref<8192xi1, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_43 : memref<8192xf32, #hivm.address_space<ub>>) temp_buffer(%103 : memref<8xf32, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c152512_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %102 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %expand_shape_20 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %104 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c117184_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_44, %collapse_shape_45 : memref<64x128xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_46 : memref<64x128xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %106 = hivm.hir.pointer_cast(%c117184_i64) : memref<16x1x128xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c4416_i64) : memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%104 : memref<16x4x128xf32, #hivm.address_space<ub>>) outs(%106 : memref<16x1x128xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<8192xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %expand_shape_47 = memref.expand_shape %74 [[0, 1]] output_shape [1, 128] : memref<128xi32, #hivm.address_space<ub>> into memref<1x128xi32, #hivm.address_space<ub>>
        %108 = hivm.hir.pointer_cast(%c125376_i64) : memref<1x128xi32, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %108 [[0, 1]] : memref<1x128xi32, #hivm.address_space<ub>> into memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%74, %c8192_i32 : memref<128xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_48 : memref<128xi32, #hivm.address_space<ub>>)
        %109 = hivm.hir.pointer_cast(%c125376_i64) : memref<1x128xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %109 [[0, 1]] : memref<1x128xi1, #hivm.address_space<ub>> into memref<128xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_48, %74 : memref<128xi32, #hivm.address_space<ub>>, memref<128xi32, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<128xi1, #hivm.address_space<ub>>)
        %110 = hivm.hir.pointer_cast(%c125376_i64) : memref<1x128xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %110 [[0, 1]] : memref<1x128xi1, #hivm.address_space<ub>> into memref<128xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_49 : memref<128xi1, #hivm.address_space<ub>>) outs(%collapse_shape_50 : memref<128xi1, #hivm.address_space<ub>>)
        %111 = hivm.hir.pointer_cast(%c125888_i64) : memref<16x128xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_47 : memref<1x128xi32, #hivm.address_space<ub>>) outs(%111 : memref<16x128xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %112 = hivm.hir.pointer_cast(%c134080_i64) : memref<16x128xi32, #hivm.address_space<ub>>
        %113 = hivm.hir.pointer_cast(%c142272_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_47, %expand_shape_21 : memref<1x128xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%112 : memref<16x128xi32, #hivm.address_space<ub>>) temp_buffer(%113 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %114 = hivm.hir.pointer_cast(%c125888_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %112 [[0, 1]] : memref<16x128xi32, #hivm.address_space<ub>> into memref<2048xi32, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %111 [[0, 1]] : memref<16x128xi32, #hivm.address_space<ub>> into memref<2048xi32, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %114 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_51, %collapse_shape_52 : memref<2048xi32, #hivm.address_space<ub>>, memref<2048xi32, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<2048xi1, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c125888_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %115 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_53 : memref<2048xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<2048xi1, #hivm.address_space<ub>>)
        %116 = hivm.hir.pointer_cast(%c116672_i64) : memref<1x128xf16, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %116 [[0, 1]] : memref<1x128xf16, #hivm.address_space<ub>> into memref<128xf16, #hivm.address_space<ub>>
        %117 = hivm.hir.pointer_cast(%c116928_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_50 : memref<128xi1, #hivm.address_space<ub>>) outs(%collapse_shape_55 : memref<128xf16, #hivm.address_space<ub>>) temp_buffer(%117 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %118 = hivm.hir.pointer_cast(%c134080_i64) : memref<16x128xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%116 : memref<1x128xf16, #hivm.address_space<ub>>) outs(%118 : memref<16x128xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %119 = hivm.hir.pointer_cast(%c134080_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %118 [[0, 1]] : memref<16x128xf16, #hivm.address_space<ub>> into memref<2048xf16, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %119 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_56, %cst_1 : memref<2048xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_57 : memref<2048xi1, #hivm.address_space<ub>>)
        %120 = hivm.hir.pointer_cast(%c134080_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %120 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_57 : memref<2048xi1, #hivm.address_space<ub>>) outs(%collapse_shape_58 : memref<2048xi1, #hivm.address_space<ub>>)
        %121 = hivm.hir.pointer_cast(%c125888_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_59 = memref.collapse_shape %121 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_58, %collapse_shape_54 : memref<2048xi1, #hivm.address_space<ub>>, memref<2048xi1, #hivm.address_space<ub>>) outs(%collapse_shape_59 : memref<2048xi1, #hivm.address_space<ub>>)
        %122 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%80, %33]
        %reinterpret_cast_60 = memref.reinterpret_cast %arg10 to offset: [%122], sizes: [16, 128], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x128xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %123 = hivm.hir.pointer_cast(%c37440_i64) : memref<16x128xf32, #hivm.address_space<ub>>
        %collapse_shape_61 = memref.collapse_shape %106 [[0, 1, 2]] : memref<16x1x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
        %collapse_shape_62 = memref.collapse_shape %123 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
        %124 = hivm.hir.pointer_cast(%c116672_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_59, %collapse_shape_61, %cst_0 : memref<2048xi1, #hivm.address_space<ub>>, memref<2048xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_62 : memref<2048xf32, #hivm.address_space<ub>>) temp_buffer(%124 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %125 = affine.min affine_map<()[s0, s1] -> (128, s0 - s1)>()[%82, %80]
        %subview_63 = memref.subview %123[0, 0] [%59, %125] [1, 1] : memref<16x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
        %subview_64 = memref.subview %reinterpret_cast_60[0, 0] [%59, %125] [1, 1] : memref<16x128xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %16 {
          hivm.hir.store ins(%subview_63 : memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>) outs(%subview_64 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg17 = %70 to %63 step %c1_i32  : i32 {
        %73 = arith.muli %arg17, %c64_i32 : i32
        %74 = hivm.hir.pointer_cast(%c116672_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%11, %73 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%74 : memref<64xi32, #hivm.address_space<ub>>)
        %75 = arith.subi %arg17, %60 : i32
        %76 = arith.muli %75, %c64_i32 : i32
        %77 = arith.extsi %76 : i32 to i64
        %78 = arith.addi %72, %77 : i64
        %79 = arith.index_cast %78 : i64 to index
        %80 = arith.index_cast %73 : i32 to index
        %81 = affine.max affine_map<()[s0] -> (8192, s0)>()[%80]
        %82 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%81, %80]
        %83 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%80, %58]
        %84 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%83, %80]
        %85 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%82, %80, %84]
        %86 = arith.cmpi slt, %85, %c64 : index
        %reinterpret_cast_23 = memref.reinterpret_cast %arg6 to offset: [%79], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %87 = hivm.hir.pointer_cast(%c45632_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_24 = memref.subview %reinterpret_cast_23[0] [%85] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_25 = memref.subview %87[0] [%85] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %86 {
          hivm.hir.vbrc ins(%cst_1 : f16) outs(%87 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_24 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_25 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst_1 : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %88 = hivm.hir.pointer_cast(%c116928_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%87 : memref<64xf16, #hivm.address_space<ub>>) outs(%88 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %89 = memref_ext.alloc_workspace() from %arg2 offset = [%c32768] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 0
        %90 = hivm.hir.pointer_cast(%c45760_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %89 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_27 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_27 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        %91 = hivm.hir.pointer_cast(%c45760_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %91 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_27 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_28 : memref<4096xf32, #hivm.address_space<ub>>)
        %92 = hivm.hir.pointer_cast(%c45760_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %91 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_31 = memref.collapse_shape %92 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %93 = hivm.hir.pointer_cast(%c117184_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_29, %collapse_shape_30 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_31 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%93 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %94 = hivm.hir.pointer_cast(%c118208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %95 = hivm.hir.pointer_cast(%c117184_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_32 = memref.expand_shape %88 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %95 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_32 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_33 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_34 = memref.collapse_shape %95 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %94 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_34 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %96 = hivm.hir.pointer_cast(%c118208_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %92 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_36, %collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %97 = hivm.hir.pointer_cast(%c116928_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_38, %collapse_shape_38 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c116928_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<4096xi1, #hivm.address_space<ub>>)
        %99 = hivm.hir.pointer_cast(%c134592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %99 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_38, %cst : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_41 : memref<4096xf32, #hivm.address_space<ub>>)
        %100 = hivm.hir.pointer_cast(%c150976_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c117440_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_40, %cst, %collapse_shape_41 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%101 : memref<16xf32, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c134592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %103 = hivm.hir.pointer_cast(%c116928_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_7, %collapse_shape_38, %collapse_shape_42 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_43 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%103 : memref<8xf32, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c134592_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %102 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %expand_shape_20 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %104 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c116928_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_44, %collapse_shape_45 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_46 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %106 = hivm.hir.pointer_cast(%c116928_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c150976_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%104 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%106 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_47 = memref.expand_shape %74 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %108 = hivm.hir.pointer_cast(%c121024_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %108 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%74, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_48 : memref<64xi32, #hivm.address_space<ub>>)
        %109 = hivm.hir.pointer_cast(%c121024_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %109 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_48, %74 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>)
        %110 = hivm.hir.pointer_cast(%c121024_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %110 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_50 : memref<64xi1, #hivm.address_space<ub>>)
        %111 = hivm.hir.pointer_cast(%c121280_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_47 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%111 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %112 = hivm.hir.pointer_cast(%c125376_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %113 = hivm.hir.pointer_cast(%c129472_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_47, %expand_shape_21 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%112 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%113 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %114 = hivm.hir.pointer_cast(%c125376_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %112 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %111 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %114 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_51, %collapse_shape_52 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c125376_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %115 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>)
        %116 = hivm.hir.pointer_cast(%c116672_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %116 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %117 = hivm.hir.pointer_cast(%c116800_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_50 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_55 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%117 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %118 = hivm.hir.pointer_cast(%c121024_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%116 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%118 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %119 = hivm.hir.pointer_cast(%c121024_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %119 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_56, %cst_1 : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>)
        %120 = hivm.hir.pointer_cast(%c121024_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %120 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_58 : memref<1024xi1, #hivm.address_space<ub>>)
        %121 = hivm.hir.pointer_cast(%c121024_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_59 = memref.collapse_shape %121 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_58, %collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_59 : memref<1024xi1, #hivm.address_space<ub>>)
        %122 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%80, %33]
        %reinterpret_cast_60 = memref.reinterpret_cast %arg10 to offset: [%122], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %123 = hivm.hir.pointer_cast(%c62144_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_61 = memref.collapse_shape %106 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_62 = memref.collapse_shape %123 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %124 = hivm.hir.pointer_cast(%c116672_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_59, %collapse_shape_61, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_62 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%124 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %125 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%82, %80]
        %subview_63 = memref.subview %123[0, 0] [%59, %125] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_64 = memref.subview %reinterpret_cast_60[0, 0] [%59, %125] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        scf.if %16 {
          hivm.hir.store ins(%subview_63 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_64 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg16 = %46 to %c8_i32 step %c1_i32  : i32 {
      %60 = arith.addi %21, %arg16 : i32
      %61 = arith.muli %60, %c64_i32 : i32
      %62 = arith.index_cast %61 : i32 to index
      %63 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%62, %33]
      %reinterpret_cast_22 = memref.reinterpret_cast %arg10 to offset: [%63], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %64 = affine.max affine_map<()[s0] -> (8192, s0)>()[%62]
      %65 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%64, %62]
      %66 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%65, %62]
      %subview_23 = memref.subview %9[0, 0] [%59, %66] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_24 = memref.subview %reinterpret_cast_22[0, 0] [%59, %66] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      scf.if %16 {
        hivm.hir.pipe_barrier[<PIPE_MTE3>]
        hivm.hir.store ins(%subview_23 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_24 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
      } {limit_sub_block_id0}
    }
  }
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpve04lhwz/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpve04lhwz/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpve04lhwz/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpve04lhwz/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
