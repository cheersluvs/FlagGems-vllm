// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c57344_i64 = arith.constant 57344 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c40960_i64 = arith.constant 40960 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32 = arith.constant 32 : index
  %c32800 = arith.constant 32800 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 4
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg14 = %6 to %c128_i32 step %arg11  : i32 {
    %7 = arith.index_cast %arg14 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg11 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_2 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_2, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_1, %c32768_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg14, %c16_i32 : i32
    %16 = arith.remsi %arg14, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_3 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_4 = memref.cast %subview_3 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_4 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    %27 = memref.load %26[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 4
    annotation.mark %27 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%27 : i32] : i32
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg15 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg15, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg15, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_5 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_5[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.subi %49, %47 : i32
      %55 = arith.remsi %54, %c2_i32 : i32
      %56 = arith.subi %49, %55 : i32
      %57 = arith.extsi %53 : i32 to i64
      %58 = arith.muli %57, %c192_i64 : i64
      scf.for %arg16 = %47 to %56 step %c2_i32  : i32 {
        %59 = arith.index_cast %arg16 : i32 to index
        %60 = arith.index_cast %47 : i32 to index
        %61 = arith.index_cast %56 : i32 to index
        %62 = arith.index_cast %c2_i32 : i32 to index
        %63 = arith.index_cast %arg15 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg14 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg11 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg16 : i32 to index
        %74 = arith.index_cast %47 : i32 to index
        %75 = arith.index_cast %56 : i32 to index
        %76 = arith.index_cast %c2_i32 : i32 to index
        %77 = arith.index_cast %arg15 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg14 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg11 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %87 = arith.select %86, %c3_i64, %c4_i64 : i64
        %88 = hivm.hir.pointer_cast(%c8192_i64, %c40960_i64) : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x8x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg16, %c64_i32 : i32
        %90 = arith.subi %arg16, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_6 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [128, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_7 = memref.cast %88 : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c128 : index
        %subview_8 = memref.subview %reinterpret_cast_6[0, 0] [%101, 128] [1, 1] : memref<128x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_9 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_10 = memref.cast %subview_9 : memref<4x?x16x32xi8, strided<[4096, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x8x16x32xi8, #hivm.address_space<cbuf>> into memref<16384xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<16384xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_8 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_10 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c0_i64_1) : memref<8x4x16x16xi32, #hivm.address_space<cc>>
        %cast_11 = memref.cast %104 : memref<8x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_7, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_11 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_0, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_11 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x128xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg16 = %56 to %49 step %c1_i32  : i32 {
        %59 = arith.index_cast %arg16 : i32 to index
        %60 = arith.index_cast %56 : i32 to index
        %61 = arith.index_cast %49 : i32 to index
        %62 = arith.index_cast %c1_i32 : i32 to index
        %63 = arith.index_cast %arg15 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg14 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg11 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg16 : i32 to index
        %74 = arith.index_cast %56 : i32 to index
        %75 = arith.index_cast %49 : i32 to index
        %76 = arith.index_cast %c1_i32 : i32 to index
        %77 = arith.index_cast %arg15 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg14 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg11 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %87 = arith.select %86, %c3_i64, %c4_i64 : i64
        %88 = hivm.hir.pointer_cast(%c24576_i64, %c57344_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg16, %c64_i32 : i32
        %90 = arith.subi %arg16, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_6 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_7 = memref.cast %88 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c64 : index
        %subview_8 = memref.subview %reinterpret_cast_6[0, 0] [%101, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_9 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_10 = memref.cast %subview_9 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_8 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_10 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_11 = memref.cast %104 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_7, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_11 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32800] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_11 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %105 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n128_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c60128_i64 = arith.constant 60128 : i64
  %c114784_i64 = arith.constant 114784 : i64
  %c127456_i64 = arith.constant 127456 : i64
  %c123360_i64 = arith.constant 123360 : i64
  %c119264_i64 = arith.constant 119264 : i64
  %c119008_i64 = arith.constant 119008 : i64
  %c115424_i64 = arith.constant 115424 : i64
  %c132576_i64 = arith.constant 132576 : i64
  %c43744_i64 = arith.constant 43744 : i64
  %c43616_i64 = arith.constant 43616 : i64
  %c35424_i64 = arith.constant 35424 : i64
  %c114912_i64 = arith.constant 114912 : i64
  %c132064_i64 = arith.constant 132064 : i64
  %c123872_i64 = arith.constant 123872 : i64
  %c156128_i64 = arith.constant 156128 : i64
  %c147936_i64 = arith.constant 147936 : i64
  %c181728_i64 = arith.constant 181728 : i64
  %c148960_i64 = arith.constant 148960 : i64
  %c116192_i64 = arith.constant 116192 : i64
  %c117728_i64 = arith.constant 117728 : i64
  %c115680_i64 = arith.constant 115680 : i64
  %c2656_i64 = arith.constant 2656 : i64
  %c115168_i64 = arith.constant 115168 : i64
  %c2400_i64 = arith.constant 2400 : i64
  %c114656_i64 = arith.constant 114656 : i64
  %c2368_i64 = arith.constant 2368 : i64
  %c2304_i64 = arith.constant 2304 : i64
  %c114400_i64 = arith.constant 114400 : i64
  %c2176_i64 = arith.constant 2176 : i64
  %c114144_i64 = arith.constant 114144 : i64
  %c2048_i64 = arith.constant 2048 : i64
  %c113888_i64 = arith.constant 113888 : i64
  %c113376_i64 = arith.constant 113376 : i64
  %c0_i64 = arith.constant 0 : i64
  %c96992_i64 = arith.constant 96992 : i64
  %c64224_i64 = arith.constant 64224 : i64
  %c32800 = arith.constant 32800 : index
  %c32 = arith.constant 32 : index
  %c1_i32 = arith.constant 1 : i32
  %c16 = arith.constant 16 : index
  %cst = arith.constant 0.000000e+00 : f16
  %c64 = arith.constant 64 : index
  %c128 = arith.constant 128 : index
  %c688_i32 = arith.constant 688 : i32
  %c63_i32 = arith.constant 63 : i32
  %c128_i32 = arith.constant 128 : i32
  %cst_0 = arith.constant 0xFF800000 : f32
  %cst_1 = arith.constant 0.000000e+00 : f32
  %c192_i64 = arith.constant 192 : i64
  %c2_i32 = arith.constant 2 : i32
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c16_i32 = arith.constant 16 : i32
  %c8_i32 = arith.constant 8 : i32
  %c0_i32 = arith.constant 0 : i32
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = hivm.hir.pointer_cast(%c64224_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %5 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_1 : f32) outs(%collapse_shape : memref<8192xf32, #hivm.address_space<ub>>)
  %6 = hivm.hir.pointer_cast(%c96992_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %6 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_1 : f32) outs(%collapse_shape_2 : memref<4096xf32, #hivm.address_space<ub>>)
  %7 = hivm.hir.pointer_cast(%c0_i64) : memref<8x64xf32, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %7 [[0, 1]] : memref<8x64xf32, #hivm.address_space<ub>> into memref<512xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_3 : memref<512xf32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c113376_i64) : memref<128xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%8 : memref<128xi32, #hivm.address_space<ub>>)
  %9 = hivm.hir.pointer_cast(%c113888_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%9 : memref<64xi32, #hivm.address_space<ub>>)
  %10 = hivm.hir.pointer_cast(%c64224_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %10 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<8192xi1, #hivm.address_space<ub>>)
  %11 = hivm.hir.pointer_cast(%c64224_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
  %collapse_shape_5 = memref.collapse_shape %11 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_4 : memref<8192xi1, #hivm.address_space<ub>>) outs(%collapse_shape_5 : memref<8192xi1, #hivm.address_space<ub>>)
  %12 = hivm.hir.pointer_cast(%c96992_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_6 = memref.collapse_shape %12 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.vcmp ins(%collapse_shape_2, %collapse_shape_2 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_6 : memref<4096xi1, #hivm.address_space<ub>>)
  %13 = hivm.hir.pointer_cast(%c96992_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_7 = memref.collapse_shape %13 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_6 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_7 : memref<4096xi1, #hivm.address_space<ub>>)
  %14 = hivm.hir.get_sub_block_idx -> i64
  %15 = arith.index_cast %14 : i64 to index
  %16 = affine.apply affine_map<()[s0] -> (s0 * 8)>()[%15]
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  annotation.mark %1 {logical_block_num} : i32
  %17 = arith.divsi %3, %4 : i32
  %18 = arith.remsi %17, %arg11 : i32
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  scf.for %arg14 = %18 to %c128_i32 step %arg11  : i32 {
    %19 = arith.divsi %arg14, %c16_i32 : i32
    %20 = arith.remsi %arg14, %c16_i32 : i32
    %21 = arith.muli %20, %c8_i32 : i32
    %22 = arith.muli %19, %c16_i32 : i32
    %23 = arith.muli %19, %c64_i32 : i32
    %24 = arith.index_cast %23 : i32 to index
    %25 = affine.max affine_map<()[s0] -> (512, s0)>()[%24]
    %26 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%25, %24]
    %27 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%26, %24]
    %28 = arith.cmpi slt, %27, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%24], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %29 = hivm.hir.pointer_cast(%c2048_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_8 = memref.collapse_shape %29 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%27] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_9 = memref.subview %collapse_shape_8[0] [%27] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %28 {
      hivm.hir.vbrc ins(%cst : f16) outs(%collapse_shape_8 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_9 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %30 = hivm.hir.pointer_cast(%c114144_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_10 = memref.collapse_shape %30 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_8 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_10 : memref<64xf32, #hivm.address_space<ub>>)
    %reinterpret_cast_11 = memref.reinterpret_cast %arg7 to offset: [%24], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %31 = hivm.hir.pointer_cast(%c2176_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_12 = memref.collapse_shape %31 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_13 = memref.subview %reinterpret_cast_11[0] [%27] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_14 = memref.subview %collapse_shape_12[0] [%27] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %28 {
      hivm.hir.vbrc ins(%cst : f16) outs(%collapse_shape_12 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview_13 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_14 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %32 = hivm.hir.pointer_cast(%c114400_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_15 = memref.collapse_shape %32 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_12 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_15 : memref<64xf32, #hivm.address_space<ub>>)
    %33 = arith.index_cast %22 : i32 to index
    %reinterpret_cast_16 = memref.reinterpret_cast %arg9 to offset: [%33], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %34 = affine.max affine_map<()[s0] -> (128, s0)>()[%33]
    %35 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%34, %33]
    %36 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%35, %33]
    %37 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%35, %33]
    %38 = hivm.hir.pointer_cast(%c2304_i64) : memref<16xi32, #hivm.address_space<ub>>
    %39 = arith.cmpi slt, %36, %c16 : index
    %subview_17 = memref.subview %reinterpret_cast_16[0] [%36] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_18 = memref.subview %38[0] [%36] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %39 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%38 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.load ins(%subview_17 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_18 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %40 = hivm.hir.pointer_cast(%c2368_i64) : memref<1xi32, #hivm.address_space<ub>>
    %41 = hivm.hir.pointer_cast(%c114656_i64) : memref<32xi32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vreduce <max> ins(%38 : memref<16xi32, #hivm.address_space<ub>>) outs(%40 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%41 : memref<32xi32, #hivm.address_space<ub>>) reduce_dims = [0]
    hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    %42 = memref.load %40[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
    hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    %43 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 4
    hivm.hir.store ins(%40 : memref<1xi32, #hivm.address_space<ub>>) outs(%43 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    annotation.mark %43 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
    %44 = arith.minsi %42, %c8192_i32 : i32
    %45 = arith.addi %44, %c63_i32 : i32
    %46 = arith.divsi %45, %c64_i32 : i32
    %47 = arith.subi %46, %21 : i32
    %48 = arith.maxsi %47, %c0_i32 : i32
    %49 = arith.minsi %48, %c8_i32 : i32
    %50 = arith.divsi %21, %c3_i32 : i32
    %51 = arith.cmpi sgt, %49, %c0_i32 : i32
    %52 = arith.remsi %21, %c3_i32 : i32
    %53 = arith.addi %52, %49 : i32
    %54 = arith.addi %53, %c2_i32 : i32
    %55 = arith.divsi %54, %c3_i32 : i32
    %56 = arith.select %51, %55, %c0_i32 : i32
    %57 = arith.addi %50, %56 : i32
    %58 = arith.addi %21, %49 : i32
    %59 = arith.muli %19, %c688_i32 : i32
    %60 = arith.index_cast %59 : i32 to index
    %61 = arith.index_cast %42 : i32 to index
    %expand_shape = memref.expand_shape %30 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_19 = memref.expand_shape %32 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_20 = memref.expand_shape %38 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg15 = %50 to %57 step %c1_i32  : i32 {
      %64 = arith.muli %arg15, %c3_i32 : i32
      %65 = arith.maxsi %21, %64 : i32
      %66 = arith.addi %64, %c3_i32 : i32
      %67 = arith.minsi %58, %66 : i32
      %68 = arith.minsi %arg15, %c42_i32 : i32
      %69 = arith.index_cast %68 : i32 to index
      %70 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%60, %69]
      %reinterpret_cast_21 = memref.reinterpret_cast %arg8 to offset: [%70], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %71 = memref.load %reinterpret_cast_21[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %72 = arith.subi %67, %65 : i32
      %73 = arith.remsi %72, %c2_i32 : i32
      %74 = arith.subi %67, %73 : i32
      %75 = arith.extsi %71 : i32 to i64
      %76 = arith.muli %75, %c192_i64 : i64
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg16 = %65 to %74 step %c2_i32  : i32 {
        %77 = arith.muli %arg16, %c64_i32 : i32
        %78 = hivm.hir.pointer_cast(%c114656_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%8, %77 : memref<128xi32, #hivm.address_space<ub>>, i32) outs(%78 : memref<128xi32, #hivm.address_space<ub>>)
        %79 = arith.subi %arg16, %64 : i32
        %80 = arith.muli %79, %c64_i32 : i32
        %81 = arith.extsi %80 : i32 to i64
        %82 = arith.addi %76, %81 : i64
        %83 = arith.index_cast %82 : i64 to index
        %84 = arith.index_cast %77 : i32 to index
        %85 = affine.max affine_map<()[s0] -> (8192, s0)>()[%84]
        %86 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%85, %84]
        %87 = affine.min affine_map<()[s0, s1] -> (128, s0 - s1)>()[%86, %84]
        %88 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%84, %33]
        %89 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%84, %61]
        %90 = affine.min affine_map<()[s0, s1] -> (s1 + 128, s0)>()[%89, %84]
        %91 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%86, %84, %90]
        %92 = arith.cmpi slt, %91, %c128 : index
        %reinterpret_cast_22 = memref.reinterpret_cast %arg6 to offset: [%83], sizes: [128], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<128xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %93 = hivm.hir.pointer_cast(%c2400_i64) : memref<128xf16, #hivm.address_space<ub>>
        %subview_23 = memref.subview %reinterpret_cast_22[0] [%91] [1] : memref<128xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_24 = memref.subview %93[0] [%91] [1] : memref<128xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %92 {
          hivm.hir.vbrc ins(%cst : f16) outs(%93 : memref<128xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_23 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_24 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %94 = hivm.hir.pointer_cast(%c115168_i64) : memref<128xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%93 : memref<128xf16, #hivm.address_space<ub>>) outs(%94 : memref<128xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %95 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %96 = hivm.hir.pointer_cast(%c2656_i64) : memref<16x4x128xi32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %95 [[0, 1]] : memref<64x128xi32, #hivm.address_space<gm>> into memref<8192xi32, #hivm.address_space<gm>>
        %collapse_shape_26 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x128xi32, #hivm.address_space<ub>> into memref<8192xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_25 : memref<8192xi32, #hivm.address_space<gm>>) outs(%collapse_shape_26 : memref<8192xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        %97 = hivm.hir.pointer_cast(%c2656_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_26 : memref<8192xi32, #hivm.address_space<ub>>) outs(%collapse_shape_27 : memref<8192xf32, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c2656_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %97 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %98 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %99 = hivm.hir.pointer_cast(%c115680_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_28, %collapse_shape_29 : memref<64x128xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<64x128xf32, #hivm.address_space<ub>>) temp_buffer(%99 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %100 = hivm.hir.pointer_cast(%c117728_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c115680_i64) : memref<1x4x128xf32, #hivm.address_space<ub>>
        %expand_shape_31 = memref.expand_shape %94 [[0, 1]] output_shape [1, 128] : memref<128xf32, #hivm.address_space<ub>> into memref<1x128xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %101 [[0, 1], [2]] : memref<1x4x128xf32, #hivm.address_space<ub>> into memref<4x128xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_31 : memref<1x128xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<4x128xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_33 = memref.collapse_shape %101 [[0], [1, 2]] : memref<1x4x128xf32, #hivm.address_space<ub>> into memref<1x512xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %100 [[0], [1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<16x512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_33 : memref<1x512xf32, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<16x512xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %102 = hivm.hir.pointer_cast(%c2656_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_35, %collapse_shape_36 : memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<8192xf32, #hivm.address_space<ub>>)
        %103 = hivm.hir.pointer_cast(%c115168_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %103 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_37, %collapse_shape_37 : memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<8192xi1, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c115168_i64) : memref<16x4x128xi1, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x4x128xi1, #hivm.address_space<ub>> into memref<8192xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_38 : memref<8192xi1, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<8192xi1, #hivm.address_space<ub>>)
        %105 = hivm.hir.pointer_cast(%c116192_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %105 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_37, %cst_1 : memref<8192xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_40 : memref<8192xf32, #hivm.address_space<ub>>)
        %106 = hivm.hir.pointer_cast(%c148960_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %106 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c181728_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_39, %cst_1, %collapse_shape_40 : memref<8192xi1, #hivm.address_space<ub>>, f32, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_41 : memref<8192xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<16xf32, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c115168_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %108 [[0, 1, 2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<8192xf32, #hivm.address_space<ub>>
        %109 = hivm.hir.pointer_cast(%c147936_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_5, %collapse_shape_37, %collapse_shape_41 : memref<8192xi1, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>, memref<8192xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<8192xf32, #hivm.address_space<ub>>) temp_buffer(%109 : memref<8xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %110 = hivm.hir.pointer_cast(%c115168_i64) : memref<16x4x128xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %108 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %expand_shape_19 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %110 [[0, 1], [2]] : memref<16x4x128xf32, #hivm.address_space<ub>> into memref<64x128xf32, #hivm.address_space<ub>>
        %111 = hivm.hir.pointer_cast(%c147936_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_43, %collapse_shape_44 : memref<64x128xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_45 : memref<64x128xf32, #hivm.address_space<ub>>) temp_buffer(%111 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %112 = hivm.hir.pointer_cast(%c147936_i64) : memref<16x1x128xf32, #hivm.address_space<ub>>
        %113 = hivm.hir.pointer_cast(%c156128_i64) : memref<8192xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%110 : memref<16x4x128xf32, #hivm.address_space<ub>>) outs(%112 : memref<16x1x128xf32, #hivm.address_space<ub>>) temp_buffer(%113 : memref<8192xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_46 = memref.expand_shape %78 [[0, 1]] output_shape [1, 128] : memref<128xi32, #hivm.address_space<ub>> into memref<1x128xi32, #hivm.address_space<ub>>
        %114 = hivm.hir.pointer_cast(%c115168_i64) : memref<1x128xi32, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %114 [[0, 1]] : memref<1x128xi32, #hivm.address_space<ub>> into memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmax ins(%78, %c8192_i32 : memref<128xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_47 : memref<128xi32, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c115168_i64) : memref<1x128xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %115 [[0, 1]] : memref<1x128xi1, #hivm.address_space<ub>> into memref<128xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_47, %78 : memref<128xi32, #hivm.address_space<ub>>, memref<128xi32, #hivm.address_space<ub>>) outs(%collapse_shape_48 : memref<128xi1, #hivm.address_space<ub>>)
        %116 = hivm.hir.pointer_cast(%c115168_i64) : memref<1x128xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %116 [[0, 1]] : memref<1x128xi1, #hivm.address_space<ub>> into memref<128xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_48 : memref<128xi1, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<128xi1, #hivm.address_space<ub>>)
        %117 = hivm.hir.pointer_cast(%c115680_i64) : memref<16x128xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_46 : memref<1x128xi32, #hivm.address_space<ub>>) outs(%117 : memref<16x128xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %118 = hivm.hir.pointer_cast(%c123872_i64) : memref<16x128xi32, #hivm.address_space<ub>>
        %119 = hivm.hir.pointer_cast(%c132064_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_46, %expand_shape_20 : memref<1x128xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%118 : memref<16x128xi32, #hivm.address_space<ub>>) temp_buffer(%119 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %120 = hivm.hir.pointer_cast(%c115680_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %118 [[0, 1]] : memref<16x128xi32, #hivm.address_space<ub>> into memref<2048xi32, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %117 [[0, 1]] : memref<16x128xi32, #hivm.address_space<ub>> into memref<2048xi32, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %120 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_50, %collapse_shape_51 : memref<2048xi32, #hivm.address_space<ub>>, memref<2048xi32, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<2048xi1, #hivm.address_space<ub>>)
        %121 = hivm.hir.pointer_cast(%c115680_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %121 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_52 : memref<2048xi1, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<2048xi1, #hivm.address_space<ub>>)
        %122 = hivm.hir.pointer_cast(%c114656_i64) : memref<1x128xf16, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %122 [[0, 1]] : memref<1x128xf16, #hivm.address_space<ub>> into memref<128xf16, #hivm.address_space<ub>>
        %123 = hivm.hir.pointer_cast(%c114912_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_49 : memref<128xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<128xf16, #hivm.address_space<ub>>) temp_buffer(%123 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %124 = hivm.hir.pointer_cast(%c123872_i64) : memref<16x128xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%122 : memref<1x128xf16, #hivm.address_space<ub>>) outs(%124 : memref<16x128xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %125 = hivm.hir.pointer_cast(%c123872_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %124 [[0, 1]] : memref<16x128xf16, #hivm.address_space<ub>> into memref<2048xf16, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %125 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_55, %cst : memref<2048xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_56 : memref<2048xi1, #hivm.address_space<ub>>)
        %126 = hivm.hir.pointer_cast(%c123872_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %126 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_56 : memref<2048xi1, #hivm.address_space<ub>>) outs(%collapse_shape_57 : memref<2048xi1, #hivm.address_space<ub>>)
        %127 = hivm.hir.pointer_cast(%c115680_i64) : memref<16x128xi1, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %127 [[0, 1]] : memref<16x128xi1, #hivm.address_space<ub>> into memref<2048xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_57, %collapse_shape_53 : memref<2048xi1, #hivm.address_space<ub>>, memref<2048xi1, #hivm.address_space<ub>>) outs(%collapse_shape_58 : memref<2048xi1, #hivm.address_space<ub>>)
        %reinterpret_cast_59 = memref.reinterpret_cast %arg10 to offset: [%88], sizes: [16, 128], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x128xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %128 = hivm.hir.pointer_cast(%c35424_i64) : memref<16x128xf32, #hivm.address_space<ub>>
        %collapse_shape_60 = memref.collapse_shape %112 [[0, 1, 2]] : memref<16x1x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
        %collapse_shape_61 = memref.collapse_shape %128 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
        %129 = hivm.hir.pointer_cast(%c114656_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_58, %collapse_shape_60, %cst_0 : memref<2048xi1, #hivm.address_space<ub>>, memref<2048xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_61 : memref<2048xf32, #hivm.address_space<ub>>) temp_buffer(%129 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %subview_62 = memref.subview %128[0, 0] [%37, %87] [1, 1] : memref<16x128xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
        %subview_63 = memref.subview %reinterpret_cast_59[0, 0] [%37, %87] [1, 1] : memref<16x128xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        hivm.hir.store ins(%subview_62 : memref<?x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>) outs(%subview_63 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg16 = %74 to %67 step %c1_i32  : i32 {
        %77 = arith.muli %arg16, %c64_i32 : i32
        %78 = hivm.hir.pointer_cast(%c114656_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%9, %77 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%78 : memref<64xi32, #hivm.address_space<ub>>)
        %79 = arith.subi %arg16, %64 : i32
        %80 = arith.muli %79, %c64_i32 : i32
        %81 = arith.extsi %80 : i32 to i64
        %82 = arith.addi %76, %81 : i64
        %83 = arith.index_cast %82 : i64 to index
        %84 = arith.index_cast %77 : i32 to index
        %85 = affine.max affine_map<()[s0] -> (8192, s0)>()[%84]
        %86 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%85, %84]
        %87 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%86, %84]
        %88 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%84, %33]
        %89 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%84, %61]
        %90 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%89, %84]
        %91 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%86, %84, %90]
        %92 = arith.cmpi slt, %91, %c64 : index
        %reinterpret_cast_22 = memref.reinterpret_cast %arg6 to offset: [%83], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %93 = hivm.hir.pointer_cast(%c43616_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_23 = memref.subview %reinterpret_cast_22[0] [%91] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_24 = memref.subview %93[0] [%91] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %92 {
          hivm.hir.vbrc ins(%cst : f16) outs(%93 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_23 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_24 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %94 = hivm.hir.pointer_cast(%c114912_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%93 : memref<64xf16, #hivm.address_space<ub>>) outs(%94 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %95 = memref_ext.alloc_workspace() from %arg2 offset = [%c32800] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %96 = hivm.hir.pointer_cast(%c43744_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %95 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_26 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        %97 = hivm.hir.pointer_cast(%c43744_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_26 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_27 : memref<4096xf32, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c43744_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %97 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_30 = memref.collapse_shape %98 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %99 = hivm.hir.pointer_cast(%c115168_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_28, %collapse_shape_29 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_30 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%99 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %100 = hivm.hir.pointer_cast(%c116192_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %101 = hivm.hir.pointer_cast(%c115168_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_31 = memref.expand_shape %94 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %101 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_31 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_32 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_33 = memref.collapse_shape %101 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %100 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_33 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %102 = hivm.hir.pointer_cast(%c116192_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_35, %collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %103 = hivm.hir.pointer_cast(%c114912_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %103 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_37, %collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c114912_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>)
        %105 = hivm.hir.pointer_cast(%c132576_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %105 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_37, %cst_1 : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>)
        %106 = hivm.hir.pointer_cast(%c148960_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %106 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c115424_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_39, %cst_1, %collapse_shape_40 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_41 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<16xf32, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c132576_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %108 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %109 = hivm.hir.pointer_cast(%c114912_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_7, %collapse_shape_37, %collapse_shape_41 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%109 : memref<8xf32, #hivm.address_space<ub>>)
        %110 = hivm.hir.pointer_cast(%c132576_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %108 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %expand_shape_19 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %110 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %111 = hivm.hir.pointer_cast(%c114912_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_43, %collapse_shape_44 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_45 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%111 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %112 = hivm.hir.pointer_cast(%c114912_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %113 = hivm.hir.pointer_cast(%c148960_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%110 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%112 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%113 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_46 = memref.expand_shape %78 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %114 = hivm.hir.pointer_cast(%c119008_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %114 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%78, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_47 : memref<64xi32, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c119008_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %115 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_47, %78 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>)
        %116 = hivm.hir.pointer_cast(%c119008_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %116 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>)
        %117 = hivm.hir.pointer_cast(%c119264_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_46 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%117 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %118 = hivm.hir.pointer_cast(%c123360_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %119 = hivm.hir.pointer_cast(%c127456_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_46, %expand_shape_20 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%118 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%119 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %120 = hivm.hir.pointer_cast(%c119264_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %117 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %120 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_50, %collapse_shape_51 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>)
        %121 = hivm.hir.pointer_cast(%c119264_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %121 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>)
        %122 = hivm.hir.pointer_cast(%c114656_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %122 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %123 = hivm.hir.pointer_cast(%c114784_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_49 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%123 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %124 = hivm.hir.pointer_cast(%c123360_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%122 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%124 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %125 = hivm.hir.pointer_cast(%c123360_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %124 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %125 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_55, %cst : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %126 = hivm.hir.pointer_cast(%c123360_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %126 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>)
        %127 = hivm.hir.pointer_cast(%c119264_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %127 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_57, %collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_58 : memref<1024xi1, #hivm.address_space<ub>>)
        %reinterpret_cast_59 = memref.reinterpret_cast %arg10 to offset: [%88], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %128 = hivm.hir.pointer_cast(%c60128_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_60 = memref.collapse_shape %112 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_61 = memref.collapse_shape %128 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %129 = hivm.hir.pointer_cast(%c114656_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_58, %collapse_shape_60, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_61 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%129 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %subview_62 = memref.subview %128[0, 0] [%37, %87] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_63 = memref.subview %reinterpret_cast_59[0, 0] [%37, %87] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        hivm.hir.store ins(%subview_62 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_63 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    %62 = affine.min affine_map<()[s0, s1, s2] -> (16, s1 - s2, s0 * 8)>()[%15, %35, %33]
    %63 = affine.min affine_map<()[s0, s1] -> (8, s0 - s1)>()[%37, %62]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg15 = %49 to %c8_i32 step %c1_i32  : i32 {
      %64 = arith.addi %21, %arg15 : i32
      %65 = arith.muli %64, %c64_i32 : i32
      %66 = arith.index_cast %65 : i32 to index
      %67 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%66, %33]
      %68 = affine.max affine_map<()[s0] -> (8192, s0)>()[%66]
      %69 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%68, %66]
      %70 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%69, %66]
      %reinterpret_cast_21 = memref.reinterpret_cast %arg10 to offset: [%67], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %subview_22 = memref.subview %reinterpret_cast_21[%16, 0] [8, 64] [1, 1] {to_be_bubbled_slice} : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<8x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %subview_23 = memref.subview %7[0, 0] [%63, %70] [1, 1] : memref<8x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_24 = memref.subview %subview_22[0, 0] [%63, %70] [1, 1] : memref<8x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      hivm.hir.store ins(%subview_23 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_24 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>) {tiled_op}
    }
  }
  hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 4
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpg8yvkdh4/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpg8yvkdh4/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmpg8yvkdh4/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmpg8yvkdh4/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
