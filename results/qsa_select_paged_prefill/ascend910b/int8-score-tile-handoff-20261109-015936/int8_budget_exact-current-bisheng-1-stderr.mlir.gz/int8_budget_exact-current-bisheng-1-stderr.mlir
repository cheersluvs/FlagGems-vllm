// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_direct_page_bounded_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c2_i32 = arith.constant 2 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 3
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  scf.for %arg14 = %6 to %c128_i32 step %arg11  : i32 {
    %7 = arith.index_cast %arg14 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg11 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_1 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_1, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_0, %c16384_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg14, %c16_i32 : i32
    %16 = arith.remsi %arg14, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_2 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_3 = memref.cast %subview_2 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_3 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    %27 = memref.load %26[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 3
    annotation.mark %27 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%27 : i32] : i32
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg15 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg15, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg15, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_4 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_4[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.extsi %53 : i32 to i64
      %55 = arith.muli %54, %c192_i64 : i64
      scf.for %arg16 = %47 to %49 step %c1_i32  : i32 {
        %56 = arith.index_cast %arg16 : i32 to index
        %57 = arith.index_cast %47 : i32 to index
        %58 = arith.index_cast %49 : i32 to index
        %59 = arith.index_cast %c1_i32 : i32 to index
        %60 = arith.index_cast %arg15 : i32 to index
        %61 = arith.index_cast %34 : i32 to index
        %62 = arith.index_cast %41 : i32 to index
        %63 = arith.index_cast %c1_i32 : i32 to index
        %64 = arith.index_cast %arg14 : i32 to index
        %65 = arith.index_cast %6 : i32 to index
        %66 = arith.index_cast %c128_i32 : i32 to index
        %67 = arith.index_cast %arg11 : i32 to index
        %68 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%56, %57, %58, %59, %60, %61, %62, %63, %64, %65, %67]
        %69 = arith.index_cast %68 : index to i64
        %70 = arith.index_cast %arg16 : i32 to index
        %71 = arith.index_cast %47 : i32 to index
        %72 = arith.index_cast %49 : i32 to index
        %73 = arith.index_cast %c1_i32 : i32 to index
        %74 = arith.index_cast %arg15 : i32 to index
        %75 = arith.index_cast %34 : i32 to index
        %76 = arith.index_cast %41 : i32 to index
        %77 = arith.index_cast %c1_i32 : i32 to index
        %78 = arith.index_cast %arg14 : i32 to index
        %79 = arith.index_cast %6 : i32 to index
        %80 = arith.index_cast %c128_i32 : i32 to index
        %81 = arith.index_cast %arg11 : i32 to index
        %82 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%70, %71, %72, %73, %74, %75, %76, %77, %78, %79, %81]
        %83 = arith.index_cast %82 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %84 = arith.select %83, %c3_i64, %c4_i64 : i64
        %85 = hivm.hir.pointer_cast(%c8192_i64, %c24576_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %85 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %86 = arith.muli %arg16, %c64_i32 : i32
        %87 = arith.subi %arg16, %46 : i32
        %88 = arith.muli %87, %c64_i32 : i32
        %89 = arith.extsi %88 : i32 to i64
        %90 = arith.addi %55, %89 : i64
        %91 = arith.index_cast %90 : i64 to index
        %92 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%91]
        %reinterpret_cast_5 = memref.reinterpret_cast %arg4 to offset: [%92], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_6 = memref.cast %85 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %93 = arith.index_cast %86 : i32 to index
        %94 = affine.max affine_map<()[s0] -> (8192, s0)>()[%93]
        %95 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%94, %93]
        %96 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%93, %45]
        %97 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%96, %93]
        %98 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%95, %93, %97]
        %99 = arith.cmpi slt, %98, %c64 : index
        %subview_7 = memref.subview %reinterpret_cast_5[0, 0] [%98, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %100 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%98]
        %subview_8 = memref.subview %85[0, 0, 0, 0] [4, %100, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_9 = memref.cast %subview_8 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %99 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %85 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %84]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_7 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_9 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %101 = hivm.hir.pointer_cast(%c0_i64_0) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_10 = memref.cast %101 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_6, %true, %23, %c128, %98 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_10 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %84, %69, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %102 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_10 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%102 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %102 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_direct_page_bounded_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c143776_i64 = arith.constant 143776 : i64
  %c139680_i64 = arith.constant 139680 : i64
  %c137632_i64 = arith.constant 137632 : i64
  %c137536_i64 = arith.constant 137536 : i64
  %c137408_i64 = arith.constant 137408 : i64
  %c136896_i64 = arith.constant 136896 : i64
  %c132800_i64 = arith.constant 132800 : i64
  %c128704_i64 = arith.constant 128704 : i64
  %c128448_i64 = arith.constant 128448 : i64
  %c112064_i64 = arith.constant 112064 : i64
  %c107968_i64 = arith.constant 107968 : i64
  %c105920_i64 = arith.constant 105920 : i64
  %c105888_i64 = arith.constant 105888 : i64
  %c89504_i64 = arith.constant 89504 : i64
  %c89440_i64 = arith.constant 89440 : i64
  %c73056_i64 = arith.constant 73056 : i64
  %c56672_i64 = arith.constant 56672 : i64
  %c56160_i64 = arith.constant 56160 : i64
  %c38752_i64 = arith.constant 38752 : i64
  %c39776_i64 = arith.constant 39776 : i64
  %c36704_i64 = arith.constant 36704 : i64
  %c20320_i64 = arith.constant 20320 : i64
  %c20064_i64 = arith.constant 20064 : i64
  %c19936_i64 = arith.constant 19936 : i64
  %c19680_i64 = arith.constant 19680 : i64
  %c19552_i64 = arith.constant 19552 : i64
  %c19520_i64 = arith.constant 19520 : i64
  %c19456_i64 = arith.constant 19456 : i64
  %c19200_i64 = arith.constant 19200 : i64
  %c19072_i64 = arith.constant 19072 : i64
  %c18816_i64 = arith.constant 18816 : i64
  %c18688_i64 = arith.constant 18688 : i64
  %c18432_i64 = arith.constant 18432 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c0_i64 = arith.constant 0 : i64
  %c32 = arith.constant 32 : index
  %c1_i32 = arith.constant 1 : i32
  %c16 = arith.constant 16 : index
  %cst = arith.constant 0.000000e+00 : f16
  %c64 = arith.constant 64 : index
  %c688_i32 = arith.constant 688 : i32
  %c2_i32 = arith.constant 2 : i32
  %c63_i32 = arith.constant 63 : i32
  %c128_i32 = arith.constant 128 : i32
  %cst_0 = arith.constant 0xFF800000 : f32
  %cst_1 = arith.constant 0.000000e+00 : f32
  %c16_i32 = arith.constant 16 : i32
  %c8_i32 = arith.constant 8 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c192_i64 = arith.constant 192 : i64
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %5 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_1 : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %6 = hivm.hir.pointer_cast(%c16384_i64) : memref<8x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %6 [[0, 1]] : memref<8x64xf32, #hivm.address_space<ub>> into memref<512xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_2 : memref<512xf32, #hivm.address_space<ub>>)
  %7 = hivm.hir.pointer_cast(%c18432_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%7 : memref<64xi32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %8 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>)
  %9 = hivm.hir.pointer_cast(%c0_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %9 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<4096xi1, #hivm.address_space<ub>>)
  %10 = hivm.hir.get_sub_block_idx -> i64
  %11 = arith.index_cast %10 : i64 to index
  %12 = affine.apply affine_map<()[s0] -> (s0 * 8)>()[%11]
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  annotation.mark %1 {logical_block_num} : i32
  %13 = arith.divsi %3, %4 : i32
  %14 = arith.remsi %13, %arg11 : i32
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  scf.for %arg14 = %14 to %c128_i32 step %arg11  : i32 {
    %15 = arith.divsi %arg14, %c16_i32 : i32
    %16 = arith.remsi %arg14, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c16_i32 : i32
    %19 = arith.muli %15, %c64_i32 : i32
    %20 = arith.index_cast %19 : i32 to index
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%20]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %20]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %20]
    %24 = arith.cmpi slt, %23, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%20], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %25 = hivm.hir.pointer_cast(%c18688_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_5 = memref.collapse_shape %25 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%23] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_6 = memref.subview %collapse_shape_5[0] [%23] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %24 {
      hivm.hir.vbrc ins(%cst : f16) outs(%collapse_shape_5 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_6 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %26 = hivm.hir.pointer_cast(%c18816_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %26 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_5 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_7 : memref<64xf32, #hivm.address_space<ub>>)
    %reinterpret_cast_8 = memref.reinterpret_cast %arg7 to offset: [%20], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = hivm.hir.pointer_cast(%c19072_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_9 = memref.collapse_shape %27 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_10 = memref.subview %reinterpret_cast_8[0] [%23] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_11 = memref.subview %collapse_shape_9[0] [%23] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %24 {
      hivm.hir.vbrc ins(%cst : f16) outs(%collapse_shape_9 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview_10 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_11 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %28 = hivm.hir.pointer_cast(%c19200_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_12 = memref.collapse_shape %28 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_9 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_12 : memref<64xf32, #hivm.address_space<ub>>)
    %29 = arith.index_cast %18 : i32 to index
    %reinterpret_cast_13 = memref.reinterpret_cast %arg9 to offset: [%29], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %30 = affine.max affine_map<()[s0] -> (128, s0)>()[%29]
    %31 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%30, %29]
    %32 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%31, %29]
    %33 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%31, %29]
    %34 = hivm.hir.pointer_cast(%c19456_i64) : memref<16xi32, #hivm.address_space<ub>>
    %35 = arith.cmpi slt, %32, %c16 : index
    %subview_14 = memref.subview %reinterpret_cast_13[0] [%32] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_15 = memref.subview %34[0] [%32] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %35 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%34 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.load ins(%subview_14 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_15 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %36 = hivm.hir.pointer_cast(%c19520_i64) : memref<1xi32, #hivm.address_space<ub>>
    %37 = hivm.hir.pointer_cast(%c19552_i64) : memref<32xi32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vreduce <max> ins(%34 : memref<16xi32, #hivm.address_space<ub>>) outs(%36 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%37 : memref<32xi32, #hivm.address_space<ub>>) reduce_dims = [0]
    hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    %38 = memref.load %36[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
    hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    %39 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 3
    hivm.hir.store ins(%36 : memref<1xi32, #hivm.address_space<ub>>) outs(%39 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    annotation.mark %39 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
    %40 = arith.minsi %38, %c8192_i32 : i32
    %41 = arith.addi %40, %c63_i32 : i32
    %42 = arith.divsi %41, %c64_i32 : i32
    %43 = arith.subi %42, %17 : i32
    %44 = arith.maxsi %43, %c0_i32 : i32
    %45 = arith.minsi %44, %c8_i32 : i32
    %46 = arith.divsi %17, %c3_i32 : i32
    %47 = arith.cmpi sgt, %45, %c0_i32 : i32
    %48 = arith.remsi %17, %c3_i32 : i32
    %49 = arith.addi %48, %45 : i32
    %50 = arith.addi %49, %c2_i32 : i32
    %51 = arith.divsi %50, %c3_i32 : i32
    %52 = arith.select %47, %51, %c0_i32 : i32
    %53 = arith.addi %46, %52 : i32
    %54 = arith.addi %17, %45 : i32
    %55 = arith.muli %15, %c688_i32 : i32
    %56 = arith.index_cast %55 : i32 to index
    %57 = arith.index_cast %38 : i32 to index
    %expand_shape = memref.expand_shape %26 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_16 = memref.expand_shape %28 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_17 = memref.expand_shape %34 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg15 = %46 to %53 step %c1_i32  : i32 {
      %60 = arith.muli %arg15, %c3_i32 : i32
      %61 = arith.maxsi %17, %60 : i32
      %62 = arith.addi %60, %c3_i32 : i32
      %63 = arith.minsi %54, %62 : i32
      %64 = arith.minsi %arg15, %c42_i32 : i32
      %65 = arith.index_cast %64 : i32 to index
      %66 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%56, %65]
      %reinterpret_cast_18 = memref.reinterpret_cast %arg8 to offset: [%66], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %67 = memref.load %reinterpret_cast_18[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %68 = arith.extsi %67 : i32 to i64
      %69 = arith.muli %68, %c192_i64 : i64
      scf.for %arg16 = %61 to %63 step %c1_i32  : i32 {
        %70 = arith.muli %arg16, %c64_i32 : i32
        %71 = hivm.hir.pointer_cast(%c19680_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vadd ins(%7, %70 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%71 : memref<64xi32, #hivm.address_space<ub>>)
        %72 = arith.subi %arg16, %60 : i32
        %73 = arith.muli %72, %c64_i32 : i32
        %74 = arith.extsi %73 : i32 to i64
        %75 = arith.addi %69, %74 : i64
        %76 = arith.index_cast %75 : i64 to index
        %77 = arith.index_cast %70 : i32 to index
        %78 = affine.max affine_map<()[s0] -> (8192, s0)>()[%77]
        %79 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%78, %77]
        %80 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%79, %77]
        %81 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%77, %29]
        %82 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%77, %57]
        %83 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%82, %77]
        %84 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%79, %77, %83]
        %85 = arith.cmpi slt, %84, %c64 : index
        %reinterpret_cast_19 = memref.reinterpret_cast %arg6 to offset: [%76], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %86 = hivm.hir.pointer_cast(%c19936_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_20 = memref.subview %reinterpret_cast_19[0] [%84] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_21 = memref.subview %86[0] [%84] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %85 {
          hivm.hir.vbrc ins(%cst : f16) outs(%86 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_20 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_21 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %87 = hivm.hir.pointer_cast(%c20064_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%86 : memref<64xf16, #hivm.address_space<ub>>) outs(%87 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %88 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %89 = hivm.hir.pointer_cast(%c20320_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_22 = memref.collapse_shape %88 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_23 = memref.collapse_shape %89 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_22 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_23 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        %90 = hivm.hir.pointer_cast(%c20320_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_24 = memref.collapse_shape %90 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_23 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_24 : memref<4096xf32, #hivm.address_space<ub>>)
        %91 = hivm.hir.pointer_cast(%c20320_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_25 = memref.collapse_shape %90 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %91 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %92 = hivm.hir.pointer_cast(%c36704_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_25, %collapse_shape_26 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_27 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%92 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %93 = hivm.hir.pointer_cast(%c39776_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %94 = hivm.hir.pointer_cast(%c38752_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_28 = memref.expand_shape %87 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %94 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_28 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_30 = memref.collapse_shape %94 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_31 = memref.collapse_shape %93 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_30 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_31 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %95 = hivm.hir.pointer_cast(%c20320_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_32 = memref.collapse_shape %91 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %93 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %95 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_32, %collapse_shape_33 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_34 : memref<4096xf32, #hivm.address_space<ub>>)
        %96 = hivm.hir.pointer_cast(%c56160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_34, %collapse_shape_34 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_35 : memref<4096xi1, #hivm.address_space<ub>>)
        %97 = hivm.hir.pointer_cast(%c56160_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %97 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_35 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_36 : memref<4096xi1, #hivm.address_space<ub>>)
        %98 = hivm.hir.pointer_cast(%c56672_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_34, %cst_1 : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_37 : memref<4096xf32, #hivm.address_space<ub>>)
        %99 = hivm.hir.pointer_cast(%c73056_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %99 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %100 = hivm.hir.pointer_cast(%c89440_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_36, %cst_1, %collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%100 : memref<16xf32, #hivm.address_space<ub>>)
        %101 = hivm.hir.pointer_cast(%c89504_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %101 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %102 = hivm.hir.pointer_cast(%c105888_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_34, %collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_39 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%102 : memref<8xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %103 = hivm.hir.pointer_cast(%c89504_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %101 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %expand_shape_16 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %103 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %104 = hivm.hir.pointer_cast(%c105920_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_40, %collapse_shape_41 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_42 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%104 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %105 = hivm.hir.pointer_cast(%c107968_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %106 = hivm.hir.pointer_cast(%c112064_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%103 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%105 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%106 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_43 = memref.expand_shape %71 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c128448_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %107 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%71, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_44 : memref<64xi32, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c128448_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_45 = memref.collapse_shape %108 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_44, %71 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_45 : memref<64xi1, #hivm.address_space<ub>>)
        %109 = hivm.hir.pointer_cast(%c128448_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %109 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_45 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_46 : memref<64xi1, #hivm.address_space<ub>>)
        %110 = hivm.hir.pointer_cast(%c128704_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_43 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%110 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %111 = hivm.hir.pointer_cast(%c132800_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %112 = hivm.hir.pointer_cast(%c136896_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_43, %expand_shape_17 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%111 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%112 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %113 = hivm.hir.pointer_cast(%c128704_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %111 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %110 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %113 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_47, %collapse_shape_48 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_49 : memref<1024xi1, #hivm.address_space<ub>>)
        %114 = hivm.hir.pointer_cast(%c128704_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %114 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_49 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_50 : memref<1024xi1, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c137408_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %115 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %116 = hivm.hir.pointer_cast(%c137536_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_46 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_51 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%116 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %117 = hivm.hir.pointer_cast(%c137632_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%115 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%117 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %118 = hivm.hir.pointer_cast(%c137632_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %117 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_52, %cst : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>)
        %119 = hivm.hir.pointer_cast(%c137632_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %119 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_53 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_54 : memref<1024xi1, #hivm.address_space<ub>>)
        %120 = hivm.hir.pointer_cast(%c137632_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %120 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_54, %collapse_shape_50 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>)
        %reinterpret_cast_56 = memref.reinterpret_cast %arg10 to offset: [%81], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %121 = hivm.hir.pointer_cast(%c139680_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %105 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_58 = memref.collapse_shape %121 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %122 = hivm.hir.pointer_cast(%c143776_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_55, %collapse_shape_57, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_58 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%122 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %subview_59 = memref.subview %121[0, 0] [%33, %80] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_60 = memref.subview %reinterpret_cast_56[0, 0] [%33, %80] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        hivm.hir.store ins(%subview_59 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_60 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    %58 = affine.min affine_map<()[s0, s1, s2] -> (16, s1 - s2, s0 * 8)>()[%11, %31, %29]
    %59 = affine.min affine_map<()[s0, s1] -> (8, s0 - s1)>()[%33, %58]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg15 = %45 to %c8_i32 step %c1_i32  : i32 {
      %60 = arith.addi %17, %arg15 : i32
      %61 = arith.muli %60, %c64_i32 : i32
      %62 = arith.index_cast %61 : i32 to index
      %63 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%62, %29]
      %64 = affine.max affine_map<()[s0] -> (8192, s0)>()[%62]
      %65 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%64, %62]
      %66 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%65, %62]
      %reinterpret_cast_18 = memref.reinterpret_cast %arg10 to offset: [%63], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %subview_19 = memref.subview %reinterpret_cast_18[%12, 0] [8, 64] [1, 1] {to_be_bubbled_slice} : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<8x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %subview_20 = memref.subview %6[0, 0] [%59, %66] [1, 1] : memref<8x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_21 = memref.subview %subview_19[0, 0] [%59, %66] [1, 1] : memref<8x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      hivm.hir.store ins(%subview_20 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_21 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>) {tiled_op}
    }
  }
  hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 3
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmp0qrc3fhc/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmp0qrc3fhc/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmp0qrc3fhc/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmp0qrc3fhc/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
