// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n64_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c0_i64 = arith.constant 0 : i64
  %c0_i64_0 = arith.constant 0 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c57344_i64 = arith.constant 57344 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c49152_i64 = arith.constant 49152 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c40960_i64 = arith.constant 40960 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c0_i64_2 = arith.constant 0 : i64
  %c192_i64 = arith.constant 192 : i64
  %c2_i32 = arith.constant 2 : i32
  %c42_i32 = arith.constant 42 : i32
  %c3_i32 = arith.constant 3 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c16_i32 = arith.constant 16 : i32
  %c128_i32 = arith.constant 128 : i32
  %c63_i32 = arith.constant 63 : i32
  %c688_i32 = arith.constant 688 : i32
  %c128 = arith.constant 128 : index
  %c64 = arith.constant 64 : index
  %c0_i8 = arith.constant 0 : i8
  %c0 = arith.constant 0 : index
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c32 = arith.constant 32 : index
  %c16416 = arith.constant 16416 : index
  %c32800 = arith.constant 32800 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg11 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 5
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  scf.for %arg14 = %6 to %c128_i32 step %arg11  : i32 {
    %7 = arith.index_cast %arg14 : i32 to index
    %8 = arith.index_cast %6 : i32 to index
    %9 = arith.index_cast %c128_i32 : i32 to index
    %10 = arith.index_cast %arg11 : i32 to index
    %11 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%7, %8, %10]
    %12 = arith.index_cast %11 : index to i1
    %c0_i64_3 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    %13 = arith.select %12, %c0_i64_3, %c1_i64 : i64
    %14 = hivm.hir.pointer_cast(%c0_i64_2, %c32768_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    annotation.mark %14 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
    %15 = arith.divsi %arg14, %c16_i32 : i32
    %16 = arith.remsi %arg14, %c16_i32 : i32
    %17 = arith.muli %16, %c8_i32 : i32
    %18 = arith.muli %15, %c64_i32 : i32
    %19 = arith.index_cast %18 : i32 to index
    %20 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%19]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%20], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %14 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
    %21 = affine.max affine_map<()[s0] -> (512, s0)>()[%19]
    %22 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%21, %19]
    %23 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%22, %19]
    %24 = arith.cmpi slt, %23, %c64 : index
    %subview = memref.subview %reinterpret_cast[0, 0] [%23, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %25 = affine.apply affine_map<()[s0, s1] -> ((s0 - s1 + 15) floordiv 16)>()[%22, %19]
    %subview_4 = memref.subview %14[0, 0, 0, 0] [4, %25, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
    %cast_5 = memref.cast %subview_4 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
    scf.if %24 {
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      %collapse_shape = memref.collapse_shape %14 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
      hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
    hivm.hir.nd2nz {dst_continuous} ins(%subview : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_5 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %26 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    %27 = memref.load %26[%c0] {"DuplicateTensorExtractForCube::newExtractLabel" = 1 : i32, "DuplicateTensorExtractForCube::visitedLabel" = 1 : i32, "PostCubeReplacement::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_set[<CUBE>, <PIPE_S>, <PIPE_S>] flag = 5
    annotation.mark %27 {"DuplicateTensorExtractForCube::replacementLabel" = 1 : i32} keys = [] values = [%27 : i32] : i32
    %28 = arith.minsi %27, %c8192_i32 : i32
    %29 = arith.addi %28, %c63_i32 : i32
    %30 = arith.divsi %29, %c64_i32 : i32
    %31 = arith.subi %30, %17 : i32
    %32 = arith.maxsi %31, %c0_i32 : i32
    %33 = arith.minsi %32, %c8_i32 : i32
    %34 = arith.divsi %17, %c3_i32 : i32
    %35 = arith.cmpi sgt, %33, %c0_i32 : i32
    %36 = arith.remsi %17, %c3_i32 : i32
    %37 = arith.addi %36, %33 : i32
    %38 = arith.addi %37, %c2_i32 : i32
    %39 = arith.divsi %38, %c3_i32 : i32
    %40 = arith.select %35, %39, %c0_i32 : i32
    %41 = arith.addi %34, %40 : i32
    %42 = arith.addi %17, %33 : i32
    %43 = arith.muli %15, %c688_i32 : i32
    %44 = arith.index_cast %43 : i32 to index
    %45 = arith.index_cast %27 : i32 to index
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    scf.for %arg15 = %34 to %41 step %c1_i32  : i32 {
      %46 = arith.muli %arg15, %c3_i32 : i32
      %47 = arith.maxsi %17, %46 : i32
      %48 = arith.addi %46, %c3_i32 : i32
      %49 = arith.minsi %42, %48 : i32
      %50 = arith.minsi %arg15, %c42_i32 : i32
      %51 = arith.index_cast %50 : i32 to index
      %52 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%44, %51]
      %reinterpret_cast_6 = memref.reinterpret_cast %arg8 to offset: [%52], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %53 = memref.load %reinterpret_cast_6[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = arith.subi %49, %47 : i32
      %55 = arith.remsi %54, %c2_i32 : i32
      %56 = arith.subi %49, %55 : i32
      %57 = arith.extsi %53 : i32 to i64
      %58 = arith.muli %57, %c192_i64 : i64
      scf.for %arg16 = %47 to %56 step %c2_i32  : i32 {
        %59 = arith.index_cast %arg16 : i32 to index
        %60 = arith.index_cast %47 : i32 to index
        %61 = arith.index_cast %56 : i32 to index
        %62 = arith.index_cast %c2_i32 : i32 to index
        %63 = arith.index_cast %arg15 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg14 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg11 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg16 : i32 to index
        %74 = arith.index_cast %47 : i32 to index
        %75 = arith.index_cast %56 : i32 to index
        %76 = arith.index_cast %c2_i32 : i32 to index
        %77 = arith.index_cast %arg15 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg14 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg11 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c5_i64 = arith.constant 5 : i64
        %c6_i64 = arith.constant 6 : i64
        %87 = arith.select %86, %c5_i64, %c6_i64 : i64
        %88 = arith.index_cast %85 : index to i1
        %c3_i64 = arith.constant 3 : i64
        %c4_i64 = arith.constant 4 : i64
        %89 = arith.select %88, %c3_i64, %c4_i64 : i64
        %90 = hivm.hir.pointer_cast(%c16384_i64, %c49152_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %90 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %91 = hivm.hir.pointer_cast(%c8192_i64, %c40960_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %91 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %92 = arith.muli %arg16, %c64_i32 : i32
        %93 = arith.subi %arg16, %46 : i32
        %94 = arith.muli %93, %c64_i32 : i32
        %95 = arith.extsi %94 : i32 to i64
        %96 = arith.addi %58, %95 : i64
        %97 = arith.index_cast %96 : i64 to index
        %98 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%97]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%98], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %91 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %99 = arith.index_cast %92 : i32 to index
        %100 = affine.max affine_map<()[s0] -> (8192, s0)>()[%99]
        %101 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%100, %99]
        %102 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%99, %45]
        %103 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%102, %99]
        %104 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%101, %99, %103]
        %105 = arith.cmpi slt, %104, %c64 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%104, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %106 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%104]
        %subview_10 = memref.subview %91[0, 0, 0, 0] [4, %106, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %105 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %91 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %89]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %107 = hivm.hir.pointer_cast(%c0_i64_2) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %107 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %104 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64_1, %c-1_i64, %89, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %108 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%108 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
        annotation.mark %108 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %109 = arith.addi %arg16, %c1_i32 : i32
        %110 = arith.muli %109, %c64_i32 : i32
        %111 = arith.subi %109, %46 : i32
        %112 = arith.muli %111, %c64_i32 : i32
        %113 = arith.extsi %112 : i32 to i64
        %114 = arith.addi %58, %113 : i64
        %115 = arith.index_cast %114 : i64 to index
        %116 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%115]
        %reinterpret_cast_13 = memref.reinterpret_cast %arg4 to offset: [%116], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_14 = memref.cast %90 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %117 = arith.index_cast %110 : i32 to index
        %118 = affine.max affine_map<()[s0] -> (8192, s0)>()[%117]
        %119 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%118, %117]
        %120 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%117, %45]
        %121 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%120, %117]
        %122 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%119, %117, %121]
        %123 = arith.cmpi slt, %122, %c64 : index
        %subview_15 = memref.subview %reinterpret_cast_13[0, 0] [%122, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %124 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%122]
        %subview_16 = memref.subview %90[0, 0, 0, 0] [4, %124, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_17 = memref.cast %subview_16 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %123 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %90 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_15 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_17 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %125 = hivm.hir.pointer_cast(%c16384_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_18 = memref.cast %125 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        %c-1_i64_19 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_14, %true, %23, %c128, %122 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_18 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64_19, %c0_i64_0, %c-1_i64_19, %87, %72, %c-1_i64_19, %c-1_i64_19 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %126 = memref_ext.alloc_workspace() from %arg2 offset = [%c16416] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_18 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%126 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        annotation.mark %126 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      } {fixpipe_for_mmad_result_already_inserted = true}
      scf.for %arg16 = %56 to %49 step %c1_i32  : i32 {
        %59 = arith.index_cast %arg16 : i32 to index
        %60 = arith.index_cast %56 : i32 to index
        %61 = arith.index_cast %49 : i32 to index
        %62 = arith.index_cast %c1_i32 : i32 to index
        %63 = arith.index_cast %arg15 : i32 to index
        %64 = arith.index_cast %34 : i32 to index
        %65 = arith.index_cast %41 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = arith.index_cast %arg14 : i32 to index
        %68 = arith.index_cast %6 : i32 to index
        %69 = arith.index_cast %c128_i32 : i32 to index
        %70 = arith.index_cast %arg11 : i32 to index
        %71 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%59, %60, %61, %62, %63, %64, %65, %66, %67, %68, %70]
        %72 = arith.index_cast %71 : index to i64
        %73 = arith.index_cast %arg16 : i32 to index
        %74 = arith.index_cast %56 : i32 to index
        %75 = arith.index_cast %49 : i32 to index
        %76 = arith.index_cast %c1_i32 : i32 to index
        %77 = arith.index_cast %arg15 : i32 to index
        %78 = arith.index_cast %34 : i32 to index
        %79 = arith.index_cast %41 : i32 to index
        %80 = arith.index_cast %c1_i32 : i32 to index
        %81 = arith.index_cast %arg14 : i32 to index
        %82 = arith.index_cast %6 : i32 to index
        %83 = arith.index_cast %c128_i32 : i32 to index
        %84 = arith.index_cast %arg11 : i32 to index
        %85 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%73, %74, %75, %76, %77, %78, %79, %80, %81, %82, %84]
        %86 = arith.index_cast %85 : index to i1
        %c5_i64 = arith.constant 5 : i64
        %c6_i64 = arith.constant 6 : i64
        %87 = arith.select %86, %c5_i64, %c6_i64 : i64
        %88 = hivm.hir.pointer_cast(%c24576_i64, %c57344_i64) : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        annotation.mark %88 {hivm.multi_buffer = 2 : i32} : memref<4x4x16x32xi8, #hivm.address_space<cbuf>>
        %89 = arith.muli %arg16, %c64_i32 : i32
        %90 = arith.subi %arg16, %46 : i32
        %91 = arith.muli %90, %c64_i32 : i32
        %92 = arith.extsi %91 : i32 to i64
        %93 = arith.addi %58, %92 : i64
        %94 = arith.index_cast %93 : i64 to index
        %95 = affine.apply affine_map<()[s0] -> (s0 * 128)>()[%94]
        %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [%95], sizes: [64, 128], strides: [128, 1] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_8 = memref.cast %88 : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, #hivm.address_space<cbuf>>
        %96 = arith.index_cast %89 : i32 to index
        %97 = affine.max affine_map<()[s0] -> (8192, s0)>()[%96]
        %98 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%97, %96]
        %99 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%96, %45]
        %100 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%99, %96]
        %101 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%98, %96, %100]
        %102 = arith.cmpi slt, %101, %c64 : index
        %subview_9 = memref.subview %reinterpret_cast_7[0, 0] [%101, 128] [1, 1] : memref<64x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
        %103 = affine.apply affine_map<()[s0] -> ((s0 + 15) floordiv 16)>()[%101]
        %subview_10 = memref.subview %88[0, 0, 0, 0] [4, %103, 16, 32] [1, 1, 1, 1] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> to memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>>
        %cast_11 = memref.cast %subview_10 : memref<4x?x16x32xi8, strided<[2048, 512, 32, 1]>, #hivm.address_space<cbuf>> to memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>
        scf.if %102 {
          hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          %collapse_shape = memref.collapse_shape %88 [[0, 1, 2, 3]] : memref<4x4x16x32xi8, #hivm.address_space<cbuf>> into memref<8192xi8, #hivm.address_space<cbuf>>
          hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
          hivm.hir.vbrc ins(%c0_i8 : i8) outs(%collapse_shape : memref<8192xi8, #hivm.address_space<cbuf>>)
          hivm.hir.pipe_barrier[<PIPE_MTE2>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %87]
        hivm.hir.nd2nz {dst_continuous} ins(%subview_9 : memref<?x128xi8, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xi8, strided<[?, ?, ?, 1], offset: ?>, #hivm.address_space<cbuf>>) init_out_buffer = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
        %104 = hivm.hir.pointer_cast(%c32768_i64) : memref<4x4x16x16xi32, #hivm.address_space<cc>>
        %cast_12 = memref.cast %104 : memref<4x4x16x16xi32, #hivm.address_space<cc>> to memref<?x?x?x?xi32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        %c-1_i64 = arith.constant -1 : i64
        hivm.hir.mmadL1 {b_transpose, fixpipe_for_result_already_inserted = true} ins(%cast, %cast_8, %true, %23, %c128, %101 : memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, memref<?x?x?x?xi8, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c0_i64, %c-1_i64, %87, %72, %c-1_i64, %c-1_i64 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        %105 = memref_ext.alloc_workspace() from %arg2 offset = [%c32800] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 4
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xi32, #hivm.address_space<cc>>) outs(%105 : memref<64x64xi32, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        annotation.mark %105 : memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %13]
  }
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 4
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

// -----// IR Dump After GraphSyncSolver (hivm-graph-sync-solver) //----- //
func.func @_qsa_page64_prefix_paired_n64_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xi8, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg8: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, false, false, false]> : vector<14xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, hivm.storage_aligned, mix_mode = "mix", parallel_mode = "simd"} {
  %c60128_i64 = arith.constant 60128 : i64
  %c43744_i64 = arith.constant 43744 : i64
  %c43616_i64 = arith.constant 43616 : i64
  %c39520_i64 = arith.constant 39520 : i64
  %c23136_i64 = arith.constant 23136 : i64
  %c23008_i64 = arith.constant 23008 : i64
  %c18912_i64 = arith.constant 18912 : i64
  %c82016_i64 = arith.constant 82016 : i64
  %c94688_i64 = arith.constant 94688 : i64
  %c90592_i64 = arith.constant 90592 : i64
  %c86496_i64 = arith.constant 86496 : i64
  %c86240_i64 = arith.constant 86240 : i64
  %c82656_i64 = arith.constant 82656 : i64
  %c116192_i64 = arith.constant 116192 : i64
  %c99808_i64 = arith.constant 99808 : i64
  %c83424_i64 = arith.constant 83424 : i64
  %c82400_i64 = arith.constant 82400 : i64
  %c2528_i64 = arith.constant 2528 : i64
  %c82144_i64 = arith.constant 82144 : i64
  %c2400_i64 = arith.constant 2400 : i64
  %c81888_i64 = arith.constant 81888 : i64
  %c2368_i64 = arith.constant 2368 : i64
  %c2304_i64 = arith.constant 2304 : i64
  %c81632_i64 = arith.constant 81632 : i64
  %c2176_i64 = arith.constant 2176 : i64
  %c81376_i64 = arith.constant 81376 : i64
  %c2048_i64 = arith.constant 2048 : i64
  %c80864_i64 = arith.constant 80864 : i64
  %c80608_i64 = arith.constant 80608 : i64
  %c0_i64 = arith.constant 0 : i64
  %c64224_i64 = arith.constant 64224 : i64
  %c32800 = arith.constant 32800 : index
  %c16416 = arith.constant 16416 : index
  %c32 = arith.constant 32 : index
  %c1_i32 = arith.constant 1 : i32
  %c16 = arith.constant 16 : index
  %cst = arith.constant 0.000000e+00 : f16
  %c64 = arith.constant 64 : index
  %c688_i32 = arith.constant 688 : i32
  %c63_i32 = arith.constant 63 : i32
  %c128_i32 = arith.constant 128 : i32
  %cst_0 = arith.constant 0xFF800000 : f32
  %cst_1 = arith.constant 0.000000e+00 : f32
  %c16_i32 = arith.constant 16 : i32
  %c8_i32 = arith.constant 8 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8192_i32 = arith.constant 8192 : i32
  %c64_i32 = arith.constant 64 : i32
  %c3_i32 = arith.constant 3 : i32
  %c42_i32 = arith.constant 42 : i32
  %c2_i32 = arith.constant 2 : i32
  %c192_i64 = arith.constant 192 : i64
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %0 = arith.muli %arg11, %arg12 : i32
  %1 = arith.muli %0, %arg13 : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg13, %arg12 : i32
  %5 = hivm.hir.pointer_cast(%c64224_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
  %collapse_shape = memref.collapse_shape %5 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_1 : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
  %6 = hivm.hir.pointer_cast(%c0_i64) : memref<8x64xf32, #hivm.address_space<ub>>
  %collapse_shape_2 = memref.collapse_shape %6 [[0, 1]] : memref<8x64xf32, #hivm.address_space<ub>> into memref<512xf32, #hivm.address_space<ub>>
  hivm.hir.vbrc ins(%cst_0 : f32) outs(%collapse_shape_2 : memref<512xf32, #hivm.address_space<ub>>)
  %7 = hivm.hir.pointer_cast(%c80608_i64) : memref<64xi32, #hivm.address_space<ub>>
  hivm.hir.varange offset[%c0] strides[%c1] outs(%7 : memref<64xi32, #hivm.address_space<ub>>)
  %8 = hivm.hir.pointer_cast(%c80864_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_3 = memref.collapse_shape %8 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>)
  %9 = hivm.hir.pointer_cast(%c80864_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_4 = memref.collapse_shape %9 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_3 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_4 : memref<4096xi1, #hivm.address_space<ub>>)
  %10 = hivm.hir.pointer_cast(%c64224_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_5 = memref.collapse_shape %10 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.vcmp ins(%collapse_shape, %collapse_shape : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_5 : memref<4096xi1, #hivm.address_space<ub>>)
  %11 = hivm.hir.pointer_cast(%c64224_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
  %collapse_shape_6 = memref.collapse_shape %11 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
  hivm.hir.pipe_barrier[<PIPE_V>]
  hivm.hir.vnot ins(%collapse_shape_5 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_6 : memref<4096xi1, #hivm.address_space<ub>>)
  %12 = hivm.hir.get_sub_block_idx -> i64
  %13 = arith.index_cast %12 : i64 to index
  %14 = affine.apply affine_map<()[s0] -> (s0 * 8)>()[%13]
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  annotation.mark %1 {logical_block_num} : i32
  %15 = arith.divsi %3, %4 : i32
  %16 = arith.remsi %15, %arg11 : i32
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 4
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  scf.for %arg14 = %16 to %c128_i32 step %arg11  : i32 {
    %17 = arith.divsi %arg14, %c16_i32 : i32
    %18 = arith.remsi %arg14, %c16_i32 : i32
    %19 = arith.muli %18, %c8_i32 : i32
    %20 = arith.muli %17, %c16_i32 : i32
    %21 = arith.muli %17, %c64_i32 : i32
    %22 = arith.index_cast %21 : i32 to index
    %23 = affine.max affine_map<()[s0] -> (512, s0)>()[%22]
    %24 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%23, %22]
    %25 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%24, %22]
    %26 = arith.cmpi slt, %25, %c64 : index
    %reinterpret_cast = memref.reinterpret_cast %arg5 to offset: [%22], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %27 = hivm.hir.pointer_cast(%c2048_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_7 = memref.collapse_shape %27 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview = memref.subview %reinterpret_cast[0] [%25] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_8 = memref.subview %collapse_shape_7[0] [%25] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %26 {
      hivm.hir.vbrc ins(%cst : f16) outs(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_8 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %28 = hivm.hir.pointer_cast(%c81376_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_9 = memref.collapse_shape %28 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_7 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_9 : memref<64xf32, #hivm.address_space<ub>>)
    %reinterpret_cast_10 = memref.reinterpret_cast %arg7 to offset: [%22], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %29 = hivm.hir.pointer_cast(%c2176_i64) : memref<16x4xf16, #hivm.address_space<ub>>
    %collapse_shape_11 = memref.collapse_shape %29 [[0, 1]] : memref<16x4xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
    %subview_12 = memref.subview %reinterpret_cast_10[0] [%25] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_13 = memref.subview %collapse_shape_11[0] [%25] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
    scf.if %26 {
      hivm.hir.vbrc ins(%cst : f16) outs(%collapse_shape_11 : memref<64xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.load ins(%subview_12 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_13 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %30 = hivm.hir.pointer_cast(%c81632_i64) : memref<16x4xf32, #hivm.address_space<ub>>
    %collapse_shape_14 = memref.collapse_shape %30 [[0, 1]] : memref<16x4xf32, #hivm.address_space<ub>> into memref<64xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vcast ins(%collapse_shape_11 : memref<64xf16, #hivm.address_space<ub>>) outs(%collapse_shape_14 : memref<64xf32, #hivm.address_space<ub>>)
    %31 = arith.index_cast %20 : i32 to index
    %reinterpret_cast_15 = memref.reinterpret_cast %arg9 to offset: [%31], sizes: [16], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %32 = affine.max affine_map<()[s0] -> (128, s0)>()[%31]
    %33 = affine.min affine_map<()[s0, s1] -> (s1 + 16, s0)>()[%32, %31]
    %34 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%33, %31]
    %35 = affine.min affine_map<()[s0, s1] -> (16, s0 - s1)>()[%33, %31]
    %36 = hivm.hir.pointer_cast(%c2304_i64) : memref<16xi32, #hivm.address_space<ub>>
    %37 = arith.cmpi slt, %34, %c16 : index
    %subview_16 = memref.subview %reinterpret_cast_15[0] [%34] [1] : memref<16xi32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview_17 = memref.subview %36[0] [%34] [1] : memref<16xi32, #hivm.address_space<ub>> to memref<?xi32, strided<[1]>, #hivm.address_space<ub>>
    scf.if %37 {
      hivm.hir.vbrc ins(%c0_i32 : i32) outs(%36 : memref<16xi32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
    } {hivm.unlikely_condition}
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    hivm.hir.load ins(%subview_16 : memref<?xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_17 : memref<?xi32, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %c0_i32 : i32 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    %38 = hivm.hir.pointer_cast(%c2368_i64) : memref<1xi32, #hivm.address_space<ub>>
    %39 = hivm.hir.pointer_cast(%c81888_i64) : memref<32xi32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
    hivm.hir.vreduce <max> ins(%36 : memref<16xi32, #hivm.address_space<ub>>) outs(%38 : memref<1xi32, #hivm.address_space<ub>>) temp_buffer(%39 : memref<32xi32, #hivm.address_space<ub>>) reduce_dims = [0]
    hivm.hir.set_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_S>, <EVENT_ID0>]
    %40 = memref.load %38[%c0] {"DuplicateTensorExtractForCube::visitedLabel" = 1 : i32} : memref<1xi32, #hivm.address_space<ub>>
    hivm.hir.set_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
    %41 = memref_ext.alloc_workspace() from %arg2 offset = [%c0] : from memref<?xi8, #hivm.address_space<gm>> to memref<1xi32, #hivm.address_space<gm>>
    hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 5
    hivm.hir.store ins(%38 : memref<1xi32, #hivm.address_space<ub>>) outs(%41 : memref<1xi32, #hivm.address_space<gm>>) {"inserted-store"}
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
    hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 0
    annotation.mark %41 {hivm.tcore_type = #hivm.tcore_type<VECTOR>} : memref<1xi32, #hivm.address_space<gm>>
    %42 = arith.minsi %40, %c8192_i32 : i32
    %43 = arith.addi %42, %c63_i32 : i32
    %44 = arith.divsi %43, %c64_i32 : i32
    %45 = arith.subi %44, %19 : i32
    %46 = arith.maxsi %45, %c0_i32 : i32
    %47 = arith.minsi %46, %c8_i32 : i32
    %48 = arith.divsi %19, %c3_i32 : i32
    %49 = arith.cmpi sgt, %47, %c0_i32 : i32
    %50 = arith.remsi %19, %c3_i32 : i32
    %51 = arith.addi %50, %47 : i32
    %52 = arith.addi %51, %c2_i32 : i32
    %53 = arith.divsi %52, %c3_i32 : i32
    %54 = arith.select %49, %53, %c0_i32 : i32
    %55 = arith.addi %48, %54 : i32
    %56 = arith.addi %19, %47 : i32
    %57 = arith.muli %17, %c688_i32 : i32
    %58 = arith.index_cast %57 : i32 to index
    %59 = arith.index_cast %40 : i32 to index
    %expand_shape = memref.expand_shape %28 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_18 = memref.expand_shape %30 [[0], [1, 2]] output_shape [16, 4, 1] : memref<16x4xf32, #hivm.address_space<ub>> into memref<16x4x1xf32, #hivm.address_space<ub>>
    %expand_shape_19 = memref.expand_shape %36 [[0, 1]] output_shape [16, 1] : memref<16xi32, #hivm.address_space<ub>> into memref<16x1xi32, #hivm.address_space<ub>>
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg15 = %48 to %55 step %c1_i32  : i32 {
      %62 = arith.muli %arg15, %c3_i32 : i32
      %63 = arith.maxsi %19, %62 : i32
      %64 = arith.addi %62, %c3_i32 : i32
      %65 = arith.minsi %56, %64 : i32
      %66 = arith.minsi %arg15, %c42_i32 : i32
      %67 = arith.index_cast %66 : i32 to index
      %68 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%58, %67]
      %reinterpret_cast_20 = memref.reinterpret_cast %arg8 to offset: [%68], sizes: [1], strides: [1] : memref<?xi32, #hivm.address_space<gm>> to memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %69 = memref.load %reinterpret_cast_20[%c0] : memref<1xi32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %70 = arith.subi %65, %63 : i32
      %71 = arith.remsi %70, %c2_i32 : i32
      %72 = arith.subi %65, %71 : i32
      %73 = arith.extsi %69 : i32 to i64
      %74 = arith.muli %73, %c192_i64 : i64
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg16 = %63 to %72 step %c2_i32  : i32 {
        %75 = arith.muli %arg16, %c64_i32 : i32
        %76 = hivm.hir.pointer_cast(%c81888_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%7, %75 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%76 : memref<64xi32, #hivm.address_space<ub>>)
        %77 = arith.subi %arg16, %62 : i32
        %78 = arith.muli %77, %c64_i32 : i32
        %79 = arith.extsi %78 : i32 to i64
        %80 = arith.addi %74, %79 : i64
        %81 = arith.index_cast %80 : i64 to index
        %82 = arith.index_cast %75 : i32 to index
        %83 = affine.max affine_map<()[s0] -> (8192, s0)>()[%82]
        %84 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%83, %82]
        %85 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%84, %82]
        %86 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%82, %31]
        %87 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%82, %59]
        %88 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%87, %82]
        %89 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%84, %82, %88]
        %90 = arith.cmpi slt, %89, %c64 : index
        %reinterpret_cast_21 = memref.reinterpret_cast %arg6 to offset: [%81], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %91 = hivm.hir.pointer_cast(%c2400_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_22 = memref.subview %reinterpret_cast_21[0] [%89] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_23 = memref.subview %91[0] [%89] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %90 {
          hivm.hir.vbrc ins(%cst : f16) outs(%91 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        hivm.hir.load ins(%subview_22 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_23 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %92 = hivm.hir.pointer_cast(%c82144_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%91 : memref<64xf16, #hivm.address_space<ub>>) outs(%92 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
        %93 = memref_ext.alloc_workspace() from %arg2 offset = [%c32] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %94 = hivm.hir.pointer_cast(%c2528_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_24 = memref.collapse_shape %93 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_25 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        hivm.hir.load ins(%collapse_shape_24 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
        %95 = hivm.hir.pointer_cast(%c2528_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %95 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_26 : memref<4096xf32, #hivm.address_space<ub>>)
        %96 = hivm.hir.pointer_cast(%c2528_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %95 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %96 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %97 = hivm.hir.pointer_cast(%c82400_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_27, %collapse_shape_28 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%97 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %98 = hivm.hir.pointer_cast(%c83424_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %99 = hivm.hir.pointer_cast(%c82400_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_30 = memref.expand_shape %92 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_31 = memref.collapse_shape %99 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_30 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_31 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_32 = memref.collapse_shape %99 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %98 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_32 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_33 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %100 = hivm.hir.pointer_cast(%c83424_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_34, %collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
        %101 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %101 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_36, %collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>)
        %103 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %103 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_36, %cst_1 : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_39 : memref<4096xf32, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c116192_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c82656_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_38, %cst_1, %collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<16xf32, #hivm.address_space<ub>>)
        %106 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %106 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c82144_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_36, %collapse_shape_40 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_41 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<8xf32, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %106 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %expand_shape_18 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %108 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %109 = hivm.hir.pointer_cast(%c82144_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_42, %collapse_shape_43 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_44 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%109 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %110 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %111 = hivm.hir.pointer_cast(%c116192_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%108 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%110 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%111 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_45 = memref.expand_shape %76 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %112 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %112 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%76, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_46 : memref<64xi32, #hivm.address_space<ub>>)
        %113 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %113 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_46, %76 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>)
        %114 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %114 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c86496_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_45 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%115 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %116 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %117 = hivm.hir.pointer_cast(%c94688_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_45, %expand_shape_19 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%116 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%117 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %118 = hivm.hir.pointer_cast(%c86496_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %116 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %115 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_49, %collapse_shape_50 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>)
        %119 = hivm.hir.pointer_cast(%c86496_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %119 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>)
        %120 = hivm.hir.pointer_cast(%c81888_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %120 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %121 = hivm.hir.pointer_cast(%c82016_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%121 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %122 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%120 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%122 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %123 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %122 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %123 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_54, %cst : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>)
        %124 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %124 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %125 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %125 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_56, %collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>)
        %reinterpret_cast_58 = memref.reinterpret_cast %arg10 to offset: [%86], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %126 = hivm.hir.pointer_cast(%c18912_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_59 = memref.collapse_shape %110 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_60 = memref.collapse_shape %126 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %127 = hivm.hir.pointer_cast(%c81888_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_57, %collapse_shape_59, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_60 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%127 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %subview_61 = memref.subview %126[0, 0] [%35, %85] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_62 = memref.subview %reinterpret_cast_58[0, 0] [%35, %85] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_MTE3>]
        hivm.hir.store ins(%subview_61 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_62 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
        %128 = arith.addi %arg16, %c1_i32 : i32
        %129 = arith.muli %128, %c64_i32 : i32
        %130 = hivm.hir.pointer_cast(%c81888_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%7, %129 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%130 : memref<64xi32, #hivm.address_space<ub>>)
        %131 = arith.subi %128, %62 : i32
        %132 = arith.muli %131, %c64_i32 : i32
        %133 = arith.extsi %132 : i32 to i64
        %134 = arith.addi %74, %133 : i64
        %135 = arith.index_cast %134 : i64 to index
        %136 = arith.index_cast %129 : i32 to index
        %137 = affine.max affine_map<()[s0] -> (8192, s0)>()[%136]
        %138 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%137, %136]
        %139 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%138, %136]
        %140 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%136, %59]
        %141 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%140, %136]
        %142 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%138, %136, %141]
        %143 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%136, %31]
        %144 = arith.cmpi slt, %142, %c64 : index
        %reinterpret_cast_63 = memref.reinterpret_cast %arg6 to offset: [%135], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %145 = hivm.hir.pointer_cast(%c23008_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_64 = memref.subview %reinterpret_cast_63[0] [%142] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_65 = memref.subview %145[0] [%142] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %144 {
          hivm.hir.vbrc ins(%cst : f16) outs(%145 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        hivm.hir.load ins(%subview_64 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_65 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %146 = hivm.hir.pointer_cast(%c82144_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%145 : memref<64xf16, #hivm.address_space<ub>>) outs(%146 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        %147 = memref_ext.alloc_workspace() from %arg2 offset = [%c16416] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %148 = hivm.hir.pointer_cast(%c23136_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_66 = memref.collapse_shape %147 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_67 = memref.collapse_shape %148 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        hivm.hir.load ins(%collapse_shape_66 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_67 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        %149 = hivm.hir.pointer_cast(%c23136_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_68 = memref.collapse_shape %149 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_67 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_68 : memref<4096xf32, #hivm.address_space<ub>>)
        %150 = hivm.hir.pointer_cast(%c23136_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_69 = memref.collapse_shape %149 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_70 = memref.collapse_shape %150 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %151 = hivm.hir.pointer_cast(%c82400_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_69, %collapse_shape_28 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_70 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%151 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %152 = hivm.hir.pointer_cast(%c83424_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %153 = hivm.hir.pointer_cast(%c82400_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_71 = memref.expand_shape %146 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_72 = memref.collapse_shape %153 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_71 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_72 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_73 = memref.collapse_shape %153 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_74 = memref.collapse_shape %152 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_73 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_74 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %154 = hivm.hir.pointer_cast(%c83424_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_75 = memref.collapse_shape %150 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_76 = memref.collapse_shape %152 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_77 = memref.collapse_shape %154 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_75, %collapse_shape_76 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_77 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        %155 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_78 = memref.collapse_shape %155 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_77, %collapse_shape_77 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_78 : memref<4096xi1, #hivm.address_space<ub>>)
        %156 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_79 = memref.collapse_shape %156 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_78 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_79 : memref<4096xi1, #hivm.address_space<ub>>)
        %157 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_80 = memref.collapse_shape %157 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_77, %cst_1 : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_80 : memref<4096xf32, #hivm.address_space<ub>>)
        %158 = hivm.hir.pointer_cast(%c116192_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_81 = memref.collapse_shape %158 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %159 = hivm.hir.pointer_cast(%c82656_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_79, %cst_1, %collapse_shape_80 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_81 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%159 : memref<16xf32, #hivm.address_space<ub>>)
        %160 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_82 = memref.collapse_shape %160 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %161 = hivm.hir.pointer_cast(%c82144_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_4, %collapse_shape_77, %collapse_shape_81 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_82 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%161 : memref<8xf32, #hivm.address_space<ub>>)
        %162 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_83 = memref.collapse_shape %160 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_84 = memref.collapse_shape %162 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %163 = hivm.hir.pointer_cast(%c82144_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_83, %collapse_shape_43 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_84 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%163 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %164 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %165 = hivm.hir.pointer_cast(%c116192_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%162 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%164 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%165 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_85 = memref.expand_shape %130 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %166 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_86 = memref.collapse_shape %166 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%130, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_86 : memref<64xi32, #hivm.address_space<ub>>)
        %167 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_87 = memref.collapse_shape %167 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_86, %130 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_87 : memref<64xi1, #hivm.address_space<ub>>)
        %168 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_88 = memref.collapse_shape %168 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_87 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_88 : memref<64xi1, #hivm.address_space<ub>>)
        %169 = hivm.hir.pointer_cast(%c86496_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_85 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%169 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %170 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %171 = hivm.hir.pointer_cast(%c94688_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_85, %expand_shape_19 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%170 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%171 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %172 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_89 = memref.collapse_shape %170 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_90 = memref.collapse_shape %169 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_91 = memref.collapse_shape %172 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_89, %collapse_shape_90 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_91 : memref<1024xi1, #hivm.address_space<ub>>)
        %173 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_92 = memref.collapse_shape %173 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_91 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_92 : memref<1024xi1, #hivm.address_space<ub>>)
        %174 = hivm.hir.pointer_cast(%c81888_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_93 = memref.collapse_shape %174 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %175 = hivm.hir.pointer_cast(%c82016_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_88 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_93 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%175 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %176 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%174 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%176 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %177 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_94 = memref.collapse_shape %176 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_95 = memref.collapse_shape %177 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_94, %cst : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_95 : memref<1024xi1, #hivm.address_space<ub>>)
        %178 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_96 = memref.collapse_shape %178 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_95 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_96 : memref<1024xi1, #hivm.address_space<ub>>)
        %179 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_97 = memref.collapse_shape %179 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_96, %collapse_shape_92 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_97 : memref<1024xi1, #hivm.address_space<ub>>)
        %reinterpret_cast_98 = memref.reinterpret_cast %arg10 to offset: [%143], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %180 = hivm.hir.pointer_cast(%c39520_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_99 = memref.collapse_shape %164 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_100 = memref.collapse_shape %180 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %181 = hivm.hir.pointer_cast(%c81888_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_97, %collapse_shape_99, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_100 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%181 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %subview_101 = memref.subview %180[0, 0] [%35, %139] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_102 = memref.subview %reinterpret_cast_98[0, 0] [%35, %139] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        hivm.hir.pipe_barrier[<PIPE_MTE3>]
        hivm.hir.store ins(%subview_101 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_102 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
      } {fixpipe_for_mmad_result_already_inserted = true}
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      scf.for %arg16 = %72 to %65 step %c1_i32  : i32 {
        %75 = arith.muli %arg16, %c64_i32 : i32
        %76 = hivm.hir.pointer_cast(%c81888_i64) : memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%7, %75 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%76 : memref<64xi32, #hivm.address_space<ub>>)
        %77 = arith.subi %arg16, %62 : i32
        %78 = arith.muli %77, %c64_i32 : i32
        %79 = arith.extsi %78 : i32 to i64
        %80 = arith.addi %74, %79 : i64
        %81 = arith.index_cast %80 : i64 to index
        %82 = arith.index_cast %75 : i32 to index
        %83 = affine.max affine_map<()[s0] -> (8192, s0)>()[%82]
        %84 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%83, %82]
        %85 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%84, %82]
        %86 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%82, %31]
        %87 = affine.max affine_map<()[s0, s1] -> (s1, s0)>()[%82, %59]
        %88 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%87, %82]
        %89 = affine.min affine_map<()[s0, s1, s2] -> (-s1 + s2, s0 - s1)>()[%84, %82, %88]
        %90 = arith.cmpi slt, %89, %c64 : index
        %reinterpret_cast_21 = memref.reinterpret_cast %arg6 to offset: [%81], sizes: [64], strides: [1] : memref<?xf16, #hivm.address_space<gm>> to memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %91 = hivm.hir.pointer_cast(%c43616_i64) : memref<64xf16, #hivm.address_space<ub>>
        %subview_22 = memref.subview %reinterpret_cast_21[0] [%89] [1] : memref<64xf16, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
        %subview_23 = memref.subview %91[0] [%89] [1] : memref<64xf16, #hivm.address_space<ub>> to memref<?xf16, strided<[1]>, #hivm.address_space<ub>>
        scf.if %90 {
          hivm.hir.vbrc ins(%cst : f16) outs(%91 : memref<64xf16, #hivm.address_space<ub>>)
          hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
          hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
        } {hivm.unlikely_condition}
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        hivm.hir.load ins(%subview_22 : memref<?xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%subview_23 : memref<?xf16, strided<[1]>, #hivm.address_space<ub>>) pad_mode = <PadValue> pad_value = %cst : f16 left_padding_num = %c0 : index init_out_buffer = false may_implicit_transpose_with_last_axis = false
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        %92 = hivm.hir.pointer_cast(%c82144_i64) : memref<64xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%91 : memref<64xf16, #hivm.address_space<ub>>) outs(%92 : memref<64xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
        %93 = memref_ext.alloc_workspace() from %arg2 offset = [%c32800] : from memref<?xi8, #hivm.address_space<gm>> to memref<64x64xi32, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        %94 = hivm.hir.pointer_cast(%c43744_i64) : memref<16x4x64xi32, #hivm.address_space<ub>>
        %collapse_shape_24 = memref.collapse_shape %93 [[0, 1]] : memref<64x64xi32, #hivm.address_space<gm>> into memref<4096xi32, #hivm.address_space<gm>>
        %collapse_shape_25 = memref.collapse_shape %94 [[0, 1, 2]] : memref<16x4x64xi32, #hivm.address_space<ub>> into memref<4096xi32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        hivm.hir.load ins(%collapse_shape_24 : memref<4096xi32, #hivm.address_space<gm>>) outs(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<ub>>) {"inserted-load"} init_out_buffer = false may_implicit_transpose_with_last_axis = false core_type = <VECTOR>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 4
        %95 = hivm.hir.pointer_cast(%c43744_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_26 = memref.collapse_shape %95 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
        hivm.hir.vcast ins(%collapse_shape_25 : memref<4096xi32, #hivm.address_space<ub>>) outs(%collapse_shape_26 : memref<4096xf32, #hivm.address_space<ub>>)
        %96 = hivm.hir.pointer_cast(%c43744_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_27 = memref.collapse_shape %95 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_28 = memref.collapse_shape %expand_shape [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_29 = memref.collapse_shape %96 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %97 = hivm.hir.pointer_cast(%c82400_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_27, %collapse_shape_28 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_29 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%97 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %98 = hivm.hir.pointer_cast(%c83424_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %99 = hivm.hir.pointer_cast(%c82400_i64) : memref<1x4x64xf32, #hivm.address_space<ub>>
        %expand_shape_30 = memref.expand_shape %92 [[0, 1]] output_shape [1, 64] : memref<64xf32, #hivm.address_space<ub>> into memref<1x64xf32, #hivm.address_space<ub>>
        %collapse_shape_31 = memref.collapse_shape %99 [[0, 1], [2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<4x64xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%expand_shape_30 : memref<1x64xf32, #hivm.address_space<ub>>) outs(%collapse_shape_31 : memref<4x64xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %collapse_shape_32 = memref.collapse_shape %99 [[0], [1, 2]] : memref<1x4x64xf32, #hivm.address_space<ub>> into memref<1x256xf32, #hivm.address_space<ub>>
        %collapse_shape_33 = memref.collapse_shape %98 [[0], [1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%collapse_shape_32 : memref<1x256xf32, #hivm.address_space<ub>>) outs(%collapse_shape_33 : memref<16x256xf32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %100 = hivm.hir.pointer_cast(%c83424_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_34 = memref.collapse_shape %96 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_35 = memref.collapse_shape %98 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_36 = memref.collapse_shape %100 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_34, %collapse_shape_35 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
        %101 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_37 = memref.collapse_shape %101 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_36, %collapse_shape_36 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>)
        %102 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x4x64xi1, #hivm.address_space<ub>>
        %collapse_shape_38 = memref.collapse_shape %102 [[0, 1, 2]] : memref<16x4x64xi1, #hivm.address_space<ub>> into memref<4096xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_37 : memref<4096xi1, #hivm.address_space<ub>>) outs(%collapse_shape_38 : memref<4096xi1, #hivm.address_space<ub>>)
        %103 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_39 = memref.collapse_shape %103 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%collapse_shape_36, %cst_1 : memref<4096xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_39 : memref<4096xf32, #hivm.address_space<ub>>)
        %104 = hivm.hir.pointer_cast(%c116192_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_40 = memref.collapse_shape %104 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %105 = hivm.hir.pointer_cast(%c82656_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_38, %cst_1, %collapse_shape_39 : memref<4096xi1, #hivm.address_space<ub>>, f32, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_40 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%105 : memref<16xf32, #hivm.address_space<ub>>)
        %106 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_41 = memref.collapse_shape %106 [[0, 1, 2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %107 = hivm.hir.pointer_cast(%c82144_i64) : memref<8xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_6, %collapse_shape_36, %collapse_shape_40 : memref<4096xi1, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_41 : memref<4096xf32, #hivm.address_space<ub>>) temp_buffer(%107 : memref<8xf32, #hivm.address_space<ub>>)
        %108 = hivm.hir.pointer_cast(%c99808_i64) : memref<16x4x64xf32, #hivm.address_space<ub>>
        %collapse_shape_42 = memref.collapse_shape %106 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %collapse_shape_43 = memref.collapse_shape %expand_shape_18 [[0, 1], [2]] : memref<16x4x1xf32, #hivm.address_space<ub>> into memref<64x1xf32, #hivm.address_space<ub>>
        %collapse_shape_44 = memref.collapse_shape %108 [[0, 1], [2]] : memref<16x4x64xf32, #hivm.address_space<ub>> into memref<64x64xf32, #hivm.address_space<ub>>
        %109 = hivm.hir.pointer_cast(%c82144_i64) : memref<512xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%collapse_shape_42, %collapse_shape_43 : memref<64x64xf32, #hivm.address_space<ub>>, memref<64x1xf32, #hivm.address_space<ub>>) outs(%collapse_shape_44 : memref<64x64xf32, #hivm.address_space<ub>>) temp_buffer(%109 : memref<512xf32, #hivm.address_space<ub>>) broadcast = [1]
        %110 = hivm.hir.pointer_cast(%c82144_i64) : memref<16x1x64xf32, #hivm.address_space<ub>>
        %111 = hivm.hir.pointer_cast(%c116192_i64) : memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vreduce <sum> ins(%108 : memref<16x4x64xf32, #hivm.address_space<ub>>) outs(%110 : memref<16x1x64xf32, #hivm.address_space<ub>>) temp_buffer(%111 : memref<4096xf32, #hivm.address_space<ub>>) reduce_dims = [1]
        %expand_shape_45 = memref.expand_shape %76 [[0, 1]] output_shape [1, 64] : memref<64xi32, #hivm.address_space<ub>> into memref<1x64xi32, #hivm.address_space<ub>>
        %112 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi32, #hivm.address_space<ub>>
        %collapse_shape_46 = memref.collapse_shape %112 [[0, 1]] : memref<1x64xi32, #hivm.address_space<ub>> into memref<64xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%76, %c8192_i32 : memref<64xi32, #hivm.address_space<ub>>, i32) outs(%collapse_shape_46 : memref<64xi32, #hivm.address_space<ub>>)
        %113 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_47 = memref.collapse_shape %113 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_46, %76 : memref<64xi32, #hivm.address_space<ub>>, memref<64xi32, #hivm.address_space<ub>>) outs(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>)
        %114 = hivm.hir.pointer_cast(%c86240_i64) : memref<1x64xi1, #hivm.address_space<ub>>
        %collapse_shape_48 = memref.collapse_shape %114 [[0, 1]] : memref<1x64xi1, #hivm.address_space<ub>> into memref<64xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_47 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>)
        %115 = hivm.hir.pointer_cast(%c86496_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        hivm.hir.vbrc ins(%expand_shape_45 : memref<1x64xi32, #hivm.address_space<ub>>) outs(%115 : memref<16x64xi32, #hivm.address_space<ub>>) broadcast_dims = [0]
        %116 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi32, #hivm.address_space<ub>>
        %117 = hivm.hir.pointer_cast(%c94688_i64) : memref<128xi32, #hivm.address_space<ub>>
        hivm.hir.vmax ins(%expand_shape_45, %expand_shape_19 : memref<1x64xi32, #hivm.address_space<ub>>, memref<16x1xi32, #hivm.address_space<ub>>) outs(%116 : memref<16x64xi32, #hivm.address_space<ub>>) temp_buffer(%117 : memref<128xi32, #hivm.address_space<ub>>) broadcast = [0, 1]
        %118 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_49 = memref.collapse_shape %116 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_50 = memref.collapse_shape %115 [[0, 1]] : memref<16x64xi32, #hivm.address_space<ub>> into memref<1024xi32, #hivm.address_space<ub>>
        %collapse_shape_51 = memref.collapse_shape %118 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_49, %collapse_shape_50 : memref<1024xi32, #hivm.address_space<ub>>, memref<1024xi32, #hivm.address_space<ub>>) outs(%collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>)
        %119 = hivm.hir.pointer_cast(%c90592_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_52 = memref.collapse_shape %119 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_51 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>)
        %120 = hivm.hir.pointer_cast(%c81888_i64) : memref<1x64xf16, #hivm.address_space<ub>>
        %collapse_shape_53 = memref.collapse_shape %120 [[0, 1]] : memref<1x64xf16, #hivm.address_space<ub>> into memref<64xf16, #hivm.address_space<ub>>
        %121 = hivm.hir.pointer_cast(%c82016_i64) : memref<48xf16, #hivm.address_space<ub>>
        hivm.hir.vcast ins(%collapse_shape_48 : memref<64xi1, #hivm.address_space<ub>>) outs(%collapse_shape_53 : memref<64xf16, #hivm.address_space<ub>>) temp_buffer(%121 : memref<48xf16, #hivm.address_space<ub>>) round_mode = <trunc>
        %122 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xf16, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vbrc ins(%120 : memref<1x64xf16, #hivm.address_space<ub>>) outs(%122 : memref<16x64xf16, #hivm.address_space<ub>>) broadcast_dims = [0]
        %123 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_54 = memref.collapse_shape %122 [[0, 1]] : memref<16x64xf16, #hivm.address_space<ub>> into memref<1024xf16, #hivm.address_space<ub>>
        %collapse_shape_55 = memref.collapse_shape %123 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vcmp ins(%collapse_shape_54, %cst : memref<1024xf16, #hivm.address_space<ub>>, f16) outs(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>)
        %124 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_56 = memref.collapse_shape %124 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vnot ins(%collapse_shape_55 : memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_56 : memref<1024xi1, #hivm.address_space<ub>>)
        %125 = hivm.hir.pointer_cast(%c86240_i64) : memref<16x64xi1, #hivm.address_space<ub>>
        %collapse_shape_57 = memref.collapse_shape %125 [[0, 1]] : memref<16x64xi1, #hivm.address_space<ub>> into memref<1024xi1, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vand ins(%collapse_shape_56, %collapse_shape_52 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xi1, #hivm.address_space<ub>>) outs(%collapse_shape_57 : memref<1024xi1, #hivm.address_space<ub>>)
        %reinterpret_cast_58 = memref.reinterpret_cast %arg10 to offset: [%86], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        %126 = hivm.hir.pointer_cast(%c60128_i64) : memref<16x64xf32, #hivm.address_space<ub>>
        %collapse_shape_59 = memref.collapse_shape %110 [[0, 1, 2]] : memref<16x1x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %collapse_shape_60 = memref.collapse_shape %126 [[0, 1]] : memref<16x64xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
        %127 = hivm.hir.pointer_cast(%c81888_i64) : memref<16xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vsel ins(%collapse_shape_57, %collapse_shape_59, %cst_0 : memref<1024xi1, #hivm.address_space<ub>>, memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_60 : memref<1024xf32, #hivm.address_space<ub>>) temp_buffer(%127 : memref<16xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        %subview_61 = memref.subview %126[0, 0] [%35, %85] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
        %subview_62 = memref.subview %reinterpret_cast_58[0, 0] [%35, %85] [1, 1] : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
        hivm.hir.store ins(%subview_61 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_62 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
      } {fixpipe_for_mmad_result_already_inserted = true}
    }
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
    %60 = affine.min affine_map<()[s0, s1, s2] -> (16, s1 - s2, s0 * 8)>()[%13, %33, %31]
    %61 = affine.min affine_map<()[s0, s1] -> (8, s0 - s1)>()[%35, %60]
    hivm.hir.pipe_barrier[<PIPE_MTE3>]
    scf.for %arg15 = %47 to %c8_i32 step %c1_i32  : i32 {
      %62 = arith.addi %19, %arg15 : i32
      %63 = arith.muli %62, %c64_i32 : i32
      %64 = arith.index_cast %63 : i32 to index
      %65 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 8192)>()[%64, %31]
      %66 = affine.max affine_map<()[s0] -> (8192, s0)>()[%64]
      %67 = affine.min affine_map<()[s0, s1] -> (s1 + 64, s0)>()[%66, %64]
      %68 = affine.min affine_map<()[s0, s1] -> (64, s0 - s1)>()[%67, %64]
      %reinterpret_cast_20 = memref.reinterpret_cast %arg10 to offset: [%65], sizes: [16, 64], strides: [8192, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %subview_21 = memref.subview %reinterpret_cast_20[%14, 0] [8, 64] [1, 1] {to_be_bubbled_slice} : memref<16x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<8x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      %subview_22 = memref.subview %6[0, 0] [%61, %68] [1, 1] : memref<8x64xf32, #hivm.address_space<ub>> to memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>
      %subview_23 = memref.subview %subview_21[0, 0] [%61, %68] [1, 1] : memref<8x64xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>> to memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>
      hivm.hir.pipe_barrier[<PIPE_MTE3>]
      hivm.hir.store ins(%subview_22 : memref<?x?xf32, strided<[64, 1]>, #hivm.address_space<ub>>) outs(%subview_23 : memref<?x?xf32, strided<[8192, 1], offset: ?>, #hivm.address_space<gm>>) {tiled_op}
    }
  }
  hivm.hir.wait_flag[<PIPE_S>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_S>, <PIPE_S>] flag = 5
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  return
}

bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmp1pxt6grn/kernel.mix_aic.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmp1pxt6grn/kernel.mix_aic.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
bisheng: warning: the flag '--cce-aicore-input-parameter-size=1536' has been deprecated and will be ignored [-Wunused-command-line-argument]
warning: linking module '/tmp/tmp1pxt6grn/kernel.mix_aiv.ll': Linking two modules of different data layouts: '/opt/qsa-topk-env.ojEsoQz5/flagtree/triton/backends/ascend/lib/libdevice.10.bc' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64' whereas '/tmp/tmp1pxt6grn/kernel.mix_aiv.ll' is 'e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n64-S64'
 [-Wlinker-warnings]
1 warning generated.
ld.lld: warning: -z separate-code and -z separate-loadable-segments will be ignored
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
warning: overriding the module target triple with aarch64-unknown-linux-gnu [-Woverride-module]
1 warning generated.
